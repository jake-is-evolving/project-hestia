# Ein queeres Wohnprojekt

**Stand:** 26.08.2026 · **Status:** Entwurf. Nichts davon ist beschlossen.

## Worum es geht

Ein Haus, in dem zwischen 20 und 40 Erwachsene zusammenleben. Eine große Küche, ein gemeinsamer Essbereich, Gemeinschaftsräume, die als solche aktiv genutzt werden. Gästezimmer, in denen Menschen von außerhalb übernachten können. Seminarräume für Workshops und Community-Veranstaltungen. Und ringsum ein größerer Kreis von Menschen, die selbstverständlich dazugehören, ohne dort zu schlafen.

Queerness als Selbstverständlichkeit, offene Kommunikation und gegenseitige Wertschätzung als soziales Fundament. Eine Gemeinschaft, die sich gegenseitig zur Verantwortung zieht, voneinander lernt, aufeinander aufpasst, und zusammen über sich hinaus wächst. Überlappende Poly-Beziehungen als Normalfall, kink als etwas, das selbstverständlich offen ausgelebt wird, während gleichzeitig verlässliche Rückzugsorte geschaffen werden.

Das Ganze so gebaut, dass es in dreißig Jahren noch besteht. Nicht verkauft, weil jemand den pro-Kopf-Preis ausgerechnet hat, nicht eingeschlafen, weil alle gleichzeitig alt geworden sind, nicht zerbrochen an der ersten Trennung, für die niemand ein Verfahren hatte.

Das ist der Kern. Der Rest dieses Dokuments ist die Frage, wie man so etwas baut, ohne an den Stellen zu scheitern, an denen solche Projekte fast immer scheitern.

> **Was dieses Dokument ist:** Ausgangspunkt für die eigene Recherche und Gesprächsgrundlage für Menschen, die in eine ähnliche Richtung denken. Es ist absichtlich unbequem an den Stellen, an denen Begeisterung allein nicht trägt.
>
> **Was es nicht ist:** kein Rechts-, Steuer- oder Finanzberatungsdokument. Alle Zahlen sind Größenordnungen zum Nachrechnen, keine Angebote. Alle rechtlichen Aussagen sind Rechercheanstöße und gehören vor jeder Entscheidung anwaltlich geprüft.

**Drei Lesewege:**

| Wenn du …                               | dann lies                                                                           |
| --------------------------------------- | ----------------------------------------------------------------------------------- |
| wissen willst, ob dich das anspricht    | Teil I (Abschnitt 0 bis 2). Zwanzig Minuten.                                        |
| wissen willst, ob es funktionieren kann | zusätzlich Teil III (Abschnitt 7 bis 9). Die unbequemen Teile, und die wichtigsten. |
| mitbauen willst                         | alles, und danach Abschnitt 12 und 13.                                              |

---

## Inhalt

| #   | Abschnitt                                                                 | Teil |
| --- | ------------------------------------------------------------------------- | ---- |
| 0   | [Kurzfassung](#0-kurzfassung)                                             | I    |
| 1   | [Vision und Grundentscheidungen](#1-vision-und-grundentscheidungen)       | I    |
| 2   | [Die Form: drei Kreise, drei Ebenen](#2-die-form-drei-kreise-drei-ebenen) | I    |
| 3   | [Rechts- und Eigentumsform](#3-rechts-und-eigentumsform)                  | II   |
| 4   | [Finanzierung](#4-finanzierung)                                           | II   |
| 5   | [Der Weg dorthin](#5-der-weg-dorthin-track-a-und-track-b)                 | II   |
| 6   | [Governance](#6-governance)                                               | II   |
| 7   | [Beziehungen, Sexualität, Kink](#7-beziehungen-sexualität-kink)           | III  |
| 8   | [Kinder und Schutzkonzept](#8-kinder-und-schutzkonzept)                   | III  |
| 9   | [Generationenfestigkeit](#9-generationenfestigkeit)                       | III  |
| 10  | [Ort und Objekt](#10-ort-und-objekt)                                      | IV   |
| 11  | [Risikoregister](#11-risikoregister)                                      | IV   |
| 12  | [Offene Fragen](#12-offene-fragen-priorisiert)                            | IV   |
| 13  | [Nächste Schritte](#13-nächste-schritte-die-ersten-90-tage)               | IV   |
| 14  | [Quellen und Anlaufstellen](#14-quellen-und-anlaufstellen)                | IV   |
| A   | [Anhang: Ideen und Werkzeuge](#anhang-a-ideen-und-werkzeuge)              | IV   |
|     | [Glossar](#glossar)                                                       |      |

---

# Teil I: Die Idee

---

## 0 Kurzfassung

Ein **explizit queeres Wohnprojekt**, bevorzugt im Raum Köln, denkbar auch im Raum Bonn. Es besteht aus drei Kreisen: **20 bis 40 Menschen im Haupthaus, geplant und gerechnet wird mit 20**, ein **Einzugsgebiet** angebundener Wohnungen in Geh- oder Radweite, und ein **Trägerkreis** von Menschen, die dazugehören und das Haus nutzen, ohne dort zu wohnen.

Große Gemeinschaftsküche mit eigenem Essraum, mehrere Sozial- und Rückzugsräume, ein Workshopraum, Gästezimmer, Veranstaltungsraum. Basisdemokratisch organisiert. Poly-affirmativ und kink-offen, mit überlappenden Beziehungen und offen gelebten Kink-Dynamiken als selbstverständlichem Teil der Kultur.

**Fünf Grundentscheidungen prägen alles Weitere:**

1. **Kein Vermögensaufbau für Einzelne.** Einlagen kommen zum Nennwert zurück. Das Objekt wird dauerhaft dem Markt entzogen.
2. **Es soll Generationen überdauern.** Wunsch und Konstruktionsvorgabe zugleich, und es schließt bestimmte Rechtsformen aus.
3. **Queer ist der Zweck, nicht der Ausweis.** Das Haus ist als queeres Projekt gegründet, und das steht in der Satzung. Geprüft wird nicht Identität, sondern Haltung. Poly und Kink sind Kultur, nicht Bedingung. Eine Beziehung ist niemals alleiniger Zugangsweg.
4. **Zwei parallele Stränge.** Ein kleiner gemieteter Zwischenschritt als echter Alltagstest, und gleichzeitig, nicht danach, der Aufbau von Struktur und Kapital.
5. **Das Haus ist nicht das alleinige Projekt.** Zugehörigkeit hängt nicht daran, im Objekt zu schlafen. Die soziale Dichte entsteht über drei Kreise, nicht über die Kopfzahl unter einem Dach.

Bevorzugtes Modell für die Eigentumsebene: **Mietshäuser Syndikat**, möglichst kombiniert mit **Erbbaurecht über eine Stiftung**. Begründung in Abschnitt 3.

---

## 1 Vision und Grundentscheidungen

### 1.1 Was entstehen soll

Ein Zuhause für **20 bis 40 Erwachsene im Haupthaus, geplant mit 20**, in dem Gemeinschaft nicht Programm ist, sondern Infrastruktur. Eingebettet in einen deutlich größeren Kreis, der mitlebt, ohne dort zu schlafen.

Konkret gewünscht:

- eine große gemeinsame Küche mit eigenem Essraum als sozialer Mittelpunkt, nicht als Nebenraum. **Ob daneben private Küchen stehen, ist bewusst offen** (→ 12.2)
- mindestens ein Raum für Workshops, Gruppen und offene Formate
- mehrere Gemeinschafts- und Rückzugsräume unterschiedlichen Charakters: Chillen, Spielen, Sauna, Werkstatt, Ruhe
- Räume, die konzipiert sind um Kink-Dynamiken im Alltag offen stattfinden zu lassen
- Gästezimmer, damit Menschen von außerhalb regelmäßig und unkompliziert da sein können
- private Rückzugsräume, individuell gestaltbar
- gute Erreichbarkeit, urbanes Umfeld oder zumindest ordentlich angebunden
- direkte Anbindung weiterer Wohnungen, auf dem Grundstück oder in der Nachbarschaft

### 1.2 Die Kultur, die gemeint ist

Drei Dinge ergeben zusammen das Profil, und sie sprechen bewusst eine sehr bestimmte Gruppe an. **Das ist gesetzt.** Der Rest des Dokuments begründet nicht, _ob_ das Haus so sein soll, sondern klärt, _wie_ es im Alltag funktioniert.

**Queer.** Nicht als Etikett oder als Programmpunkt, sondern als Normalität im Haus.

**Poly-affirmativ.** Überlappende Beziehungen sind normal und sichtbar. Poly zu leben ist keine Erwartung; poly gelebte Beziehungen als etwas zu behandeln, das man aushält, funktioniert allerdings auch nicht. Der Filter ist Affirmation, nicht zwingend Praxis.

**Kink-offen.** Kink findet im Haus statt und nicht nur hinter verschlossenen Türen. D/s-Dynamiken, die im Alltag sichtbar sind, weil sie zum Alltag gehören. Menschliche Pets, die aus dem Napf gefüttert werden, Gear, Käfige und Bondage-Ausstattung, die benutzt und nicht versteckt werden. Auch hier gilt: niemand muss aktiv mitmachen, aber alle müssen damit umgehen können.

> **Was das kostet, klar benannt:** Diese drei Punkte zusammen verkleinern den Kreis möglicher Interessierter drastisch. Praktisch heißt es: längere Suche, kleinere Auswahl, vorsichtigere Annahmen bei der Schwundquote (→ 5.1), und eine Selbstbeschreibung nach außen, die ehrlich sein muss, weil sie der wirksamste Filter ist, den dieses Projekt hat (→ 3.6).

### 1.3 Die fünf Grundentscheidungen und warum sie so getroffen sind

**Nennwert statt Wertsteigerung.** Wer auszieht, bekommt die Einlage zurück, nicht mehr. Sobald Anteile im Wert steigen, wird jeder Auszug zur Finanzierungsfrage für die Verbleibenden, das Wohnen wird für Nachrückende immer teurer, und Kapital entscheidet informell mit, auch wenn die Satzung eine Stimme pro Kopf vorsieht. Wertstabile Anteile halten Ein- und Austritt leicht, und das ist die Voraussetzung dafür, dass sich die Gruppe über Jahrzehnte erneuern kann.

**Es soll überdauern.** Daraus folgt eine unangenehme Konsequenz: _Die größte Gefahr für das Projekt ist nicht der Markt, sondern die eigene spätere Mehrheit._ In vierzig Jahren sitzen dort Menschen, die die Gründung nicht erlebt haben, in einer abbezahlten Immobilie mit erheblichem Marktwert, und irgendwann rechnet jemand vor, was ein Verkauf pro Kopf brächte. Eine Satzung schützt davor nicht, denn dieselbe Versammlung kann sie ändern. Es braucht eine Sicherung außerhalb der Reichweite der eigenen Mitgliederversammlung (→ 9.1).

**Queer als Zweck, Poly und Kink als Kultur, Beziehung nie als Zugang.** Der _Zweck_ des Hauses ist queer und kinky, steht in Satzung und Charta und ist die Sicherung, die es über Generationen queer hält; die einzelne Person wird trotzdem nicht auf Identität geprüft (→ 3.6). Unabhängig davon gilt: Ein Projekt, dessen Zugehörigkeit faktisch über Beziehungen läuft, kann Generationen nicht überdauern, denn Generation 2 kommt zwangsläufig über ein _Verfahren_ ins Haus und nicht über Freundschaft oder Liebe. Wer das ernst nimmt, baut das Verfahren jetzt, solange es niemandem wehtut (→ 7.1).

**Zwei parallele Stränge statt Reihenfolge.** Ein gemieteter Zwischenschritt testet die Kernannahme, bevor Millionen im Spiel sind. Allein gelassen wird der Zwischenschritt gemütlich und das Zielprojekt „irgendwann", deshalb läuft der Strukturaufbau von Anfang an mit eigenen Terminen mit (→ 5.3).

**Das Haus ist nicht das Projekt.** Ein Haus für dreißig Menschen unter einem Dach braucht 1.150 bis 1.740 m², bei vierzig sind es 1.460 bis 2.190 m². Solche Objekte gibt es im Raum Köln praktisch nicht zu kaufen, außer als Kloster oder Heim (→ 10.2), und daran scheitern Projekte häufiger als am Geld. **Zwanzig Menschen im Haupthaus machen die Suche real**, und die eigentlich gewollte soziale Dichte entsteht über **Einzugsgebiet** und **Trägerkreis** (→ 2.1). Der Tausch ist nicht gratis: Die Schwierigkeit wandert von der Immobiliensuche in die Governance, denn wer nicht im Haus schläft, verpasst die informellen Entscheidungen, und aus „wohnt nebenan" wird über Jahre „gehört nicht ganz dazu" (→ 2.2).

---

## 2 Die Form: drei Kreise, drei Ebenen

Zwei verschiedene Fragen brauchen zwei verschiedene Antworten. **Wer gehört dazu?** beantworten die drei Kreise in 2.1. **Wer entscheidet was?** beantworten die drei Ebenen in 2.3.

### 2.1 Drei Kreise der Zugehörigkeit

```mermaid
flowchart LR
    K["<b>Trägerkreis</b><br/>gehört dazu, wohnt woanders<br/><i>nutzt das Haus</i>"]
    S["<b>Einzugsgebiet</b><br/>angebundene Wohnungen<br/><i>Geh- oder Radweite</i>"]
    H["<b>Haupthaus</b><br/>20 bis 40 Menschen<br/>gerechnet mit 20<br/><i>Küche, Sozialräume, Gästezimmer</i>"]

    K --> S --> H
```

**Haupthaus.** Rund zwanzig Erwachsene, die dort wohnen. Gemeinsame Küche, Sozialräume, Gästezimmer, Veranstaltungsraum.

**Einzugsgebiet.** Wohnungen in Geh- oder Radweite, angebunden an das Projekt. Wer dort wohnt, ist vollwertiges Mitglied mit gleichen Ämtern, gleichem Zugang, gleichem Stimmrecht bei Objekt, Kredit und Finanzrahmen als **Nachbarschaftskammer** (→ 6.2) und Vorrang, wenn im Haupthaus ein Platz frei wird. Keine Warteliste, sondern eine eigene Wohnform: für Menschen, die Nähe wollen und eine eigene Tür brauchen, für Familien, für Paare mit anderen Rhythmen, und als Ventil nach einer Trennung (→ 7.4).

**Trägerkreis.** Menschen, die zum Projekt gehören und es nutzen, ohne in seiner Nähe zu wohnen. Hier unterscheidet sich das Modell von den meisten Wohnprojekten: **Der Trägerkreis ist keine Finanzierungsquelle mit Vereinsmitgliedschaft, sondern ein Nutzungskreis.** Wer dazugehört, kommt regelmäßig, schläft im Gästezimmer, kocht mit, feiert mit, nutzt Werkstatt, Sauna und Veranstaltungsraum, und stimmt ab, mit eigenem Ressort beim Programm und einem Veto beim Bewahren (→ 6.2, 3.5). Geld ist möglich, aber nicht der Grund. Ein Kreis, der nur zahlt, verliert nach zwei Jahren das Interesse; ein Kreis, der das Haus benutzt, bleibt.

|                           | **Haupthaus**                                     | **Einzugsgebiet**                                                       | **Trägerkreis**                                                      |
| ------------------------- | ------------------------------------------------- | ----------------------------------------------------------------------- | -------------------------------------------------------------------- |
| Größenordnung             | ca. 20                                            | offen, wächst mit                                                       | 40 bis 100+                                                          |
| Wohnt                     | im Objekt                                         | in angebundenen Wohnungen                                               | überall                                                              |
| Stimmrecht                | **Hauskammer**, zusätzlich der Wohnalltag (→ 6.2) | **Nachbarschaftskammer**, beim Handeln mit Zustimmungsvorbehalt (→ 6.2) | **Trägerkammer** ab Kerngruppe: Bewahren, Aufnahme, Programm (→ 6.2) |
| Zugang zum Haus           | selbstverständlich                                | selbstverständlich                                                      | eigene Zugangsberechtigung, nicht Klingeln (→ A.2)                   |
| Gästezimmer               |                                                   |                                                                         | **regelmäßige Nutzung ausdrücklich vorgesehen**                      |
| Dienste und Ämter         | volle Beteiligung                                 | volle Beteiligung                                                       | nach Möglichkeit, ausdrücklich erwünscht                             |
| Kapital                   | Einlage, ggf. Direktkredit                        | wie Haupthaus, wenn die Wohnung dem Projekt gehört                      | Direktkredit möglich, **freiwillig, kein Zugangspreis**              |
| Warteliste fürs Haupthaus |                                                   | Kennenlernvorsprung, kein Anspruch (→ 6.6)                              | nach Verfahren                                                       |

**Charta.** Alle drei Kreise unterschreiben sie (→ 3.6). Zugehörigkeit ohne Verpflichtung gibt es in keinem der drei Kreise.

**Was diese Konstruktion leistet:**

- **Sie macht das Objekt findbar:** 850 bis 1.300 m² statt 1.150 bis 1.740 m² (→ 4.1, 10.2).
- **Sie drückt den Kapitalbedarf** von rund 4 bis 7,5 auf 3 bis 5,5 Mio. € und verteilt ihn auf mehr Schultern, weil auch Einzugsgebiet und Trägerkreis Direktkredite geben können (→ 4.5).
- **Sie gibt Abschnitt 7 seinen Puffer zurück:** Umzug ins Einzugsgebiet statt Projektaustritt nach einer Trennung (→ 7.4).
- **Sie macht Wachstum möglich, ohne umzuziehen.** Der Kreis kann wachsen, das Haus muss nicht.
- **Sie entschärft die Standortfrage**, weil ein Objekt im Umland tragbar wird, wenn ein Teil der Gruppe in der Stadt wohnt (→ 4.3).
- **Sie hält das Haus lebendig.** Zwanzig Menschen allein füllen eine Großküche und einen Veranstaltungsraum nicht.

### 2.2 Der Preis dieser Konstruktion

> **Zugehörigkeit ohne tägliche Anwesenheit ist fragil.** Das Haupthaus produziert unvermeidlich informelle Entscheidungen: am Küchentisch, um 23 Uhr, ohne Protokoll. Ohne Gegenmaßnahmen entsteht binnen weniger Jahre eine Zwei-Klassen-Struktur, in der Einzugsgebiet und Trägerkreis formal gleichberechtigt und faktisch außen vor sind.

Das ist kein Restrisiko, sondern der wahrscheinlichste Verlaufstyp. Deshalb gehören die folgenden Punkte in die Ordnungen, nicht in die Etikette:

- **Kein Beschluss ohne Ladung.** Was am Küchentisch besprochen wird, ist keine Entscheidung (→ 6.3).
- **Hybride Teilnahme als Standard und geklärte Zuständigkeiten**, wer worüber abstimmt (→ 6.2, 6.3).
- **Feste Termine statt spontaner Runden** für alles Verbindliche. Spontaneität bevorzugt strukturell die, die schon da sind.
- **Ämter bewusst nach außen vergeben**, nicht nur die Mitarbeit.
- **Eigene Zugangsberechtigung für alle drei Kreise.** Wer klingeln muss, ist Gast (→ A.2).
- **Ein eigenes Fach im Haus** für alle, die regelmäßig da sind. Symbolisch, aber wirksam.
- **Feste Übernachtungsrechte** statt Anfragen. Ein Gästezimmer, das man buchen kann, ist etwas anderes als eines, um das man bittet.
- **Regelmäßige Erhebung**, wie zugehörig sich die Kreise tatsächlich fühlen, und zwar bevor jemand geht, nicht danach.

### 2.3 Drei Ebenen der Entscheidung

Die drei Ebenen bestehen bewusst **nicht aus denselben Menschen**.

```mermaid
flowchart TD
    T["<b>Trägerverein e.V.</b><br/>alle, die das Projekt tragen<br/>unabhängig vom Wohnort<br/><i>läuft durchgehend</i>"]
    Z["<b>Zwischenschritt</b><br/>gemietetes Objekt, 6 bis 12 Personen<br/><i>befristet, mit Ablaufdatum</i>"]
    E["<b>Eigentumsebene</b><br/>Haus-GmbH + Syndikat<br/><i>erst wenn ein Objekt konkret ist</i>"]

    T -->|"beauftragt, befristet"| Z
    Z -->|"Erkenntnisse, protokolliert"| T
    T -->|"gründet später"| E
```

**Trägerverein (e.V.).** Die Projektebene und die einzige, die von Anfang bis Ende durchläuft. Hier werden Selbstverständnis, Suchprofil, Finanzrahmen und später die Rechtsform beschlossen. Der Verein hält die Beiträge und beauftragt externe Beratung.

**Zwischenschritt (gemietete Wohngemeinschaft).** _Ein Projekt des Trägervereins, nicht der Trägerverein selbst._ Volle Autonomie im Alltag, **keine Entscheidungsmacht über das Zielprojekt**.

**Eigentumsebene.** Wird erst gegründet, wenn ein Objekt konkret verhandelt wird. Vorher wäre sie leere Form mit laufenden Kosten.

### 2.4 Warum die Trennung von Träger und Zwischenschritt die wichtigste Strukturentscheidung ist

Wer im Zwischenschritt wohnt, entwickelt zwangsläufig mehr Bindung, mehr Detailwissen und mehr informelle Autorität als alle anderen. Das ist unvermeidlich und auch gut. Gefährlich wird es erst, wenn dieselben acht Menschen gleichzeitig das Entscheidungsgremium für die spätere ganze Gruppe sind: Dann entsteht eine Gründungselite mit einem Erfahrungsvorsprung, den niemand mehr aufholt, und wer später dazukommt, betritt eine fertige Kultur und bleibt Gast im eigenen Zuhause. Das ist exakt derselbe Mechanismus, an dem in vierzig Jahren Generation 2 scheitern würde, nur früher und in klein.

**Praktisch heißt das:**

- Stimmrecht im Trägerverein hängt an der **Verbindlichkeitsstufe, nicht am Wohnort**. Wer Beitrag zahlt und in der Kerngruppe ist, stimmt gleichberechtigt mit, auch aus Hamburg. Das gilt uneingeschränkt bis zum Erstbezug; danach greift die Aufteilung aus 6.2.
- Der Zwischenschritt bekommt ein **befristetes Mandat mit Ablaufdatum**. Unbefristet wird erst das Projekt.
- **Protokollpflicht nach außen.** Was im Zwischenschritt an Erkenntnis entsteht, gehört dem Trägerverein. Sonst entsteht Wissen, das nur im Wohnzimmer existiert.

---

# Teil II: Wie es getragen wird

---

## 3 Rechts- und Eigentumsform

### 3.1 Optionsvergleich

| Form                          | Stimmrecht                                        | Haftung                             | Kapital der Mitglieder                     | Schutz vor Verkauf                | Urteil                                                                                         |
| ----------------------------- | ------------------------------------------------- | ----------------------------------- | ------------------------------------------ | --------------------------------- | ---------------------------------------------------------------------------------------------- |
| **GbR**                       | frei regelbar                                     | **persönlich, gesamtschuldnerisch** | Anteile                                    | keiner                            | ✗ bei einer Gruppe dieser Größe und Millionenkredit untragbar                                  |
| **e.V. allein**               | 1 Kopf = 1 Stimme                                 | beschränkt                          | kein Rückzahlungsanspruch                  | mittel                            | ✗ Nebenzweckprivileg §§ 21/22 BGB, Immobilienbetrieb als Hauptzweck kostet die Rechtsfähigkeit |
| **eG**                        | **1 Kopf = 1 Stimme, unabhängig von der Einlage** | beschränkt                          | Geschäftsanteile, Rückzahlung zum Nennwert | schwach, ¾-Mehrheit kann auflösen | ○ solide, aber nicht generationenfest                                                          |
| **GmbH / GmbH & Co. KG**      | i.d.R. nach Kapital                               | beschränkt                          | Geschäftsanteile                           | keiner                            | ○ nur als Baustein                                                                             |
| **WEG**                       | nach Miteigentumsanteil                           | je einzeln                          | Eigentum, mit Wertsteigerung               | keiner                            | ✗ Anteile frei verkäuflich, ihr könnt nicht steuern, wer einzieht                              |
| **Mietshäuser Syndikat**      | 1 Kopf = 1 Stimme im Hausverein                   | beschränkt                          | Direktkredite, rückzahlbar                 | **strukturell**                   | ✓**Empfehlung**                                                                                |
| **Erbbaurecht über Stiftung** |                                                   |                                     |                                            | **sehr stark**                    | ✓**als Ergänzung**                                                                             |

### 3.2 Empfehlung: Mietshäuser Syndikat, möglichst mit Erbbaurecht

Von allen Modellen löst das Syndikat als einziges _genau_ das Problem, das durch Grundentscheidung 2 entsteht: dauerhafte Unverkäuflichkeit gegen den Willen einer künftigen Mehrheit.

Der Unterschied zur Genossenschaft in einem Satz: **In einer eG kann eine Dreiviertelmehrheit auflösen und verteilen. Im Syndikat kann eine Hundertprozentmehrheit der Bewohner:innen es nicht.**

### 3.3 Wie das Syndikat mechanisch funktioniert

Pro Haus entstehen zwei Körperschaften:

- **Hausverein e.V.**, die Bewohner:innen, ein Mensch eine Stimme. Er bildet die **Hauskammer** und entscheidet im Hausplenum über den Wohnalltag, die Nutzungsgebühr und darüber, wer ins Haupthaus einzieht. Über Kreditaufnahme, Sanierung und Umbau entscheiden Haus- und Nachbarschaftskammer gemeinsam (→ 6.2).
- **Haus-GmbH**, besitzt die Immobilie und trägt den Kredit. Zwei Gesellschafter: der Hausverein mit der Kapitalmehrheit und die **Mietshäuser Syndikat GmbH** mit einem kleinen Anteil.

Der Kern steckt im Gesellschaftsvertrag der Haus-GmbH: Für **Verkauf, Umwandlung in Einzeleigentum, Änderung des Gesellschaftsvertrags und Auflösung** braucht es **Einstimmigkeit beider Gesellschafter**. Für alles andere hat das Syndikat **null Mitsprache**. Ihr gebt keine Autonomie ab, ihr gebt eine **Option** ab, und genau diese Option würde die Enkelgeneration sonst ziehen.

**Was es kostet**

- **Solidarbeitrag** in den Fonds, aus dem das Startkapital der nächsten Projekte kommt. Die Sätze stehen öffentlich (→ 14.4) und sind seit 2012 beschlossen: Nach Kauf und Einzug beginnt jedes Projekt mit **10 Cent je m² Nutzfläche und Monat** an die Mietshäuser Syndikat GmbH, abgerechnet für Beratung und Werbung. Dazu kommt eine **stille Beteiligung an der Solidarfonds GmbH von 0 bis 80 Cent je m² und Monat**, die jährlich um **0,5 % der Jahresnettokaltmiete des Vorjahres** wächst, bis der Deckel erreicht ist. Übersteigt die Miete 80 % der ortsüblichen Vergleichsmiete, kann die Steigerung auf Antrag ausgesetzt werden. Was das für dieses Haus heißt, steht in **4.7**.
- **Direktkredite** statt klassischem Eigenkapital: Nachrangdarlehen aus dem Umfeld, häufig 0 bis 2 % Zins, von Banken als quasi-Eigenkapital akzeptiert. Bei einem Objekt dieser Größe reden wir über **grob 1,5 bis 2,5 Mio. €**, die im Bekanntenkreis eingeworben werden müssen: über Jahre die härteste Arbeit und die größte Abhängigkeit des Modells. **Diese Summe passt nicht zu 35 Schultern:** Auf die 35 Kapitalgeber:innen aus 4.1 verteilt wären es 43.000 bis 71.000 € pro Kopf, also das Zwei- bis Vierfache der 10.000 bis 22.000 €, die 4.2 für realistisch hält. Beides zugleich geht nur, wenn der Kreis der Kreditgebenden weit über die 35 hinauswächst, oder wenn ein erheblicher Teil aus wenigen großen Bändern kommt (→ 4.5). Die Auflösung steht in **4.7**: Die Pro-Kopf-Zahlen aus 4.2 setzen einen Kreis von 70 bis 150 Kapitalgeber:innen voraus, die 35 Schultern aus 4.1 dagegen nicht. Wie breit der Kreis wirklich wird, gehört vor die erste Kapitalabfrage (→ 13, Schritt 3). Reales Beispiel: [Wohnsinn Aachen](https://www.wohnsinn-aachen.org/dk/) wirbt öffentlich mit **bis zu 3 %**, also oberhalb des eben genannten Korridors: Der Satz ist frei verhandelbar und muss mit dem allgemeinen Zinsniveau mitgehen, sonst verliert ein Direktkredit gegen Tagesgeld. Angeboten wird er dort als qualifiziertes Nachrangdarlehen mit Rangrücktritt, mit einsehbarer Jahresbilanz und **öffentlich herunterladbarem Mustervertrag** (→ 14.4).
- **Zeit.** Aufnahme über halbjährliche Syndikatstreffen, ein Patenprojekt und einen Konsensbeschluss aller Projekte. Ein bis zwei Jahre Vorlauf.

**Ein oft übersehener Zusatznutzen:** Nachrangdarlehen öffentlich einzuwerben kollidiert schnell mit der **Prospektpflicht nach dem Vermögensanlagengesetz**. Das Syndikat hat dafür erprobte Muster. Im Alleingang ist das ein reales Haftungsrisiko.

**Der Reibungspunkt, der früh angesprochen gehört:** Der Solidarbeitrag folgt der Idee, dass die Überschüsse eines entschuldeten Hauses die nächsten Projekte finanzieren. Der Kapitalstock aus 4.6 legt Überschüsse dagegen im eigenen Haus an. Mit den bekannten Sätzen ist der Konflikt allerdings kleiner, als er zunächst klingt: Der Beitrag ist bei **90 Cent je m² und Monat gedeckelt** und erreicht diesen Deckel nach acht bis zehn Jahren, also rund zwanzig Jahre vor der Entschuldung (→ 4.7). Er ist damit ein laufender Posten der Nutzungsgebühr und kein Zugriff auf die Summe, die in Jahr 30 frei wird. Zwei Reibungen bleiben trotzdem. Erstens kann das Syndikat **mehr erwarten als den vertraglichen Satz**, sobald ein Haus entschuldet ist; freiwillige Aufstockungen und Direktkredite an andere Projekte sind im Verbund üblich. Zweitens lässt sich ein wachsender Hausstock als Rückzug aus der Solidarität lesen. Die Reihenfolge gehört deshalb vorher verabredet: **erst der vertragliche Beitrag, dann der Stock aus dem, was übrig bleibt** (→ 4.6). Das gehört ins Aufnahmegespräch mit dem Syndikat und nicht in Jahr acht.

### 3.4 Passung des Profils

Das Syndikat versteht sich als Beitrag zu bezahlbarem, dem Markt entzogenem Wohnraum, nicht als Immobilienlösung für einen Freundeskreis. Ein **explizit queeres Wohnprojekt ist ein Auftrag** und damit im Aufnahmeverfahren genau die Art von Vorhaben, für die das Modell gemacht wurde.

Zu klärende Reibungspunkte:

- **Neubau** ist nicht die Stärke des Syndikats, Bestandserwerb schon.
- Das Modell ist explizit links und selbstorganisiert. Wenn das für Teile des Kreises fremd ist, sollte das jetzt auffallen und nicht im Beitrittsverfahren.
- **Kombinierbar mit Erbbaurecht**, etwa über die [Stiftung trias](https://www.stiftung-trias.de/) in Hattingen: Boden bei der Stiftung, Gebäude in der Haus-GmbH. Doppelte Sicherung und deutlich weniger Kapitalbedarf.
- **Die Kink-Offenheit gehört nicht in die Bewerbungsmappe, aber auch nicht verschwiegen.** Wie das Haus lebt, ist Sache des Hausvereins (→ 7.7).

### 3.5 Gemeinnützigkeit, ein unterschätzter Hebel

**§ 52 Abs. 2 AO** nennt ausdrücklich die Förderung der Hilfe für Menschen, die aufgrund ihrer geschlechtlichen Identität oder sexuellen Orientierung diskriminiert werden. Ein queerer Zweck ist also ein anerkannter gemeinnütziger Zweck. **Aber:** Das Wohnen der eigenen Mitglieder ist _nicht_ gemeinnützig, und wer beides in eine Körperschaft packt, riskiert die Aberkennung samt Nachversteuerung.

**Vorschlag: zwei getrennte Vereine.**

|              | **Hausverein**                                         | **Community-Verein**                                                |
| ------------ | ------------------------------------------------------ | ------------------------------------------------------------------- |
| Zweck        | Wohnen, Selbstverwaltung, Gesellschafter der Haus-GmbH | queere Community-Arbeit, Bildung, Beratung, Veranstaltungen         |
| Gemeinnützig | nein                                                   | ja                                                                  |
| Nutzt        | Wohnräume                                              | Veranstaltungsraum, Gästezimmer als Schutz- und Begegnungsraum      |
| Ermöglicht   | Wohnsicherheit                                         | **Spendenbescheinigungen**, Zugang zu Fördertöpfen, Stiftungsmittel |

Der Community-Verein kann Räume von der Haus-GmbH anmieten, sauber getrennt und sauber bilanziert. Bei einem Kapitalbedarf in Millionenhöhe ist die Spendenfähigkeit kein Detail. Später denkbar wären darüber Workshops und Fortbildungen zu Konsens, Awareness, Poly-Kompetenz, Schutzkonzepten und Selbstorganisation, auch als Weg, Fördermittel für die eigene Awareness-Fortbildung zu nutzen.

**Der Community-Verein ist zugleich der Ort, an dem die Trägerkammer entscheidet.** Nach 6.2 liegt bei ihr das Ressort Programm, Bildung, Veranstaltungen, Fördermittel und Vernetzung, mit eigenem Haushalt. Das ist die Gegenleistung dafür, dass sie über Objekt und Kredit nicht mitentscheidet. Der Verein bleibt trotzdem eine Option und keine Voraussetzung: Die Zuständigkeit steht ab Gründung fest, ausgefüllt wird sie erst nach dem Einzug.

> **Als Programm ausdrücklich kein Fokus der aktuellen Planung.** Eine Option für die Zeit nach dem Einzug, jetzt ausgearbeitet kostet sie Energie ohne Ertrag (→ 12.4). Wichtig ist nur, den Verein von Anfang an so zuzuschneiden, dass es später möglich bleibt.

Zu prüfen: strikte Sphärentrennung zwischen ideellem Bereich, Zweckbetrieb, wirtschaftlichem Geschäftsbetrieb und Vermögensverwaltung, zeitnahe Mittelverwendung, Selbstlosigkeitsgebot. **Das gehört in die Hände einer auf Gemeinnützigkeitsrecht spezialisierten Kanzlei und nicht in Eigenregie.**

### 3.6 Wer darf einziehen?

Drei Fragen werden hier ständig vermischt, die getrennt gehören:

| Frage                                | Antwort                                                                                                                          |
| ------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------- |
| Was ist der **Zweck** des Hauses?    | queer. Steht in Satzung und Charta, trägt die Gemeinnützigkeit (→ 3.5) und die Syndikatspassung (→ 3.4)                          |
| Wer darf **einziehen**?              | wer die Charta mittragen will und vom Hausplenum aufgenommen wird (→ 6.2). **Keine Identitätsprüfung, keine Quote, keine Daten** |
| Wie bleibt es dann ein queeres Haus? | über die Charta, über das Aufnahmeverfahren und über die Zusammensetzung der Hauskammer, die entscheidet                         |

Die Charta unterschreiben **alle drei Kreise**, nicht nur das Haupthaus (→ 2.1). Was bei offensichtlichen, wiederholten Verstößen passiert, steht in 3.7.

#### Warum keine Identitätsprüfung und keine Quote

Ein Kriterium „queer" zwingt den Aufnahmekreis zu entscheiden, wer queer _genug_ ist, erzeugt Outing-Druck gegenüber einem Gremium und wird im Konfliktfall gegen Leute verwendet. Eine Zusammensetzungsquote hilft nicht weiter:

- **Zählen heißt zuordnen**, und bei zwanzig Menschen ist „aggregiert" eine Fiktion.
- **Angaben zur sexuellen Orientierung sind besonders geschützte Daten** nach Art. 9 DSGVO.
- **Sie misst das Falsche.** Ein Haus kann seine Quote erfüllen und sein Profil trotzdem verlieren.

#### Was das Haus stattdessen queer hält

Fünf Mechanismen, keiner davon braucht Daten über irgendwen.

1. **Der Zweck steht in der Satzung**, mit demselben Änderungsschutz wie die Verkaufsfrage (→ 9.1). Eine Aussage über die Institution, nicht über Personen.
2. **Die Charta wird unterschrieben, von allen drei Kreisen.** Sie wirkt an zwei Stellen: beim Unterschreiben als Filter, später im Konflikt als Bezugspunkt. „Das hast du unterschrieben" ist ein anderes Gespräch als „das finden wir hier aber nicht gut".
3. **Das Hausplenum entscheidet, wer einzieht** (→ 6.2). Eine sehr queere Hauskammer nimmt überwiegend queere Menschen auf.
4. **Die Selbstbeschreibung nach außen filtert härter als jedes Kriterium** (→ 1.2). Der wirksamste Filter im ganzen Modell, und niemand muss dafür jemanden ablehnen.
5. **Der Vorrang-Gedanke bleibt, ohne Zahl.** Wird ein Platz frei, fragt der Aufnahmekreis auch „was fehlt dem Haus gerade", wie beim Altersmix (→ 9.2). Pflichtfrage in der Aufnahmeordnung, **ausdrücklich keine Schattenquote**: nichts wird gezählt, notiert oder fortgeschrieben. Der Altersmix ist davon der einzige Sonderfall, weil das Geburtsjahr ohnehin bekannt ist und deshalb offen ausgewiesen statt heimlich mitgeführt wird (→ 9.2). Der vollständige Weg steht in 6.6.

#### Der ehrliche Teil

Was hier stattfindet, ist eine **Auswahl nach Haltung**: Das Haus wählt Menschen, die zu Diskriminierung eine klare Position haben und queere Lebensweisen nicht tolerieren, sondern teilen, und es sagt Nein, wenn Werte nicht passen. Das aufzuschreiben ist besser, als Neutralität zu behaupten, weil es die Kriterien diskutierbar macht und Abgelehnte vor der Unterstellung schützt, sie seien als Person nicht gut genug gewesen.

**Abgesagt wird im Gespräch, nicht per Formular**, mündlich und ohne schriftliche Begründung. Ein Ablehnungsschreiben ist im Streitfall ein Beweisstück und wird deshalb defensiv formuliert, ein Gespräch kann ehrlich sein. Es ist keine Verhandlung und eröffnet kein Verfahren, es ist eine Antwort.

#### Offenheit ist Kultur, kein Kriterium

Konsens, Zonen, Awareness und Konfliktverfahren setzen alle voraus, dass Dinge ausgesprochen werden, bevor sie eskalieren, und in einer Konstellation dieser Dichte sind Fremde ein strukturelles Risiko. Daraus wird trotzdem **kein formales Kriterium**: Niemand wird geprüft oder zu Auskünften verpflichtet. Das Aufnahmeverfahren ist lang, persönlich und beinhaltet Probewohnen; wer sich darin nicht öffnen mag, merkt selbst, dass es nicht passt.

#### Poly und Kink sind nicht dieselbe Frage

Dass dieses Haus kinky und poly-affirmativ ist, steht in 1.2 und wird hier nicht noch einmal begründet. Für die **Aufnahme** folgt daraus nur ein Unterschied.

**Poly braucht vom Haus nichts.** Monogam lebende Menschen sind uneingeschränkt willkommen, und es gibt keine Erwartung, in keine Richtung.

**Kink braucht gemeinsame Infrastruktur:** Play-Räume, Zonenordnung, abgestufte Zugangsberechtigungen, Awareness, Lärm und Sichtbarkeit (→ 7.6, 8.2, A.2). Darüber entscheidet das Plenum, und wer ohne eigenen Bezug mitentscheidet, entscheidet dauerhaft über etwas Fremdes. Deshalb gilt hier eine Erwartung, wo bei Poly keine gilt: **Nähe zum Thema, nicht Praxis.** Niemand muss spielen, niemand wird gefragt, es gibt keinen Nachweis und keine Akte. Wer zu Kink aber nur „finde ich völlig okay" sagen kann, wird hier nicht glücklich, und die Gruppe mit ihm auch nicht.

Das ist eine **Erwartung, kein Kriterium**, und sie wird im Aufnahmegespräch ausgesprochen statt angedeutet. Sie gilt **vor** dem Einzug und ist danach kein Maßstab mehr (→ 3.7), denn Unschärfe lässt sich im Streit gegen Leute wenden. Im Alltag gibt es keine Teilnahmepflicht: „Nein danke" bleibt eine vollständige Antwort (→ 7.2). Aromantische, asexuelle und monogam lebende queere Menschen sind genauso zugehörig.

> **In einem Satz:** Nicht „nur queere Menschen", sondern _ein Haus, das strukturell queer bleibt_, in dem man poly- und kink-affirmativ sein muss, aber weder poly leben noch kinky sein.

#### Das Restrisiko, benannt

Ohne Zahl fällt eine Verschiebung erst auf, wenn jemand sie ausspricht, und wem sie zuerst auffällt, hat oft am wenigsten Standing. Das Gegenmittel ist keine Quote, sondern ein **Termin**: Der Selbstverständnisprozess wird regelmäßig wiederholt, extern moderiert, und „ist dieses Haus noch das, was in der Satzung steht" ist ein fester Tagesordnungspunkt.

#### Rechtlich

Vereinsautonomie erlaubt einem Verein grundsätzlich, seine Mitglieder selbst zu wählen, und das AGG nimmt Wohnverhältnisse mit besonderem Nähe- und Vertrauensverhältnis weitgehend aus. Eine Auswahl nach Haltung knüpft an Verhalten an und nicht an eine geschützte Eigenschaft, ist also **leichter zu tragen als jedes identitätsbezogene Kriterium**. Trotzdem **einmal anwaltlich absichern**, insbesondere die Verzahnung von Vereinsmitgliedschaft und Nutzungsvertrag (→ 12.3).

### 3.7 Wenn jemand gegen die Charta handelt

Eine Charta ohne Konsequenz ist Dekoration. Die Antwort ist zweigeteilt, weil das deutsche Recht hier zwei völlig getrennte Ebenen kennt. Wer das vermischt, plant ein Verfahren, das im Ernstfall nicht funktioniert.

**Was funktioniert: Vereinsausschluss und Hausrecht.** Ein Verein darf Mitglieder ausschließen, wenn die **Satzung** es vorsieht, mit Ausschlussgründen, zuständigem Organ und Verfahren, zwingend mit Anhörung, schriftlicher Begründung und sinnvollerweise einer internen Berufungsinstanz. Gerichte prüfen nur eingeschränkt nach: Satzungsgrundlage, ordnungsgemäßes Verfahren, zutreffende Tatsachen, Willkürfreiheit. Die Folge ist der Verlust von Mitgliedsrechten, also Stimmrecht, Ämter, Gremienzugang. **Für Trägerkreis und Gäste greift der Mechanismus vollständig**, dazu das Hausrecht mit einem sofort wirksamen Hausverbot.

**Was nicht schnell funktioniert, und zwar mit Absicht: die Wohnung.** Wer im Haus wohnt, hat ein **Wohnraummietverhältnis**, egal wie der Vertrag heißt. Der Kündigungsschutz ist zwingend und lässt sich nicht durch Satzung, Charta oder Plenumsbeschluss abbedingen.

- Kündigung kommt praktisch nur über **§ 543 Abs. 1 BGB** (wichtiger Grund), **§ 569 Abs. 2 BGB** (nachhaltige Störung des Hausfriedens) oder **§ 573 Abs. 2 Nr. 1 BGB** (erhebliche schuldhafte Pflichtverletzung) in Betracht, in aller Regel nach vorheriger **Abmahnung** (§ 543 Abs. 3 BGB).
- Die **Kopplung von Mitgliedschaft und Nutzungsvertrag** (→ 6.5) hilft, hebelt den Kündigungsschutz aber nicht aus. Der Wegfall der Mitgliedschaft allein beendet kein Wohnverhältnis.
- **Ein Verstoß gegen eine Wertecharta ist für sich genommen kein Kündigungsgrund.** Damit Verhalten vertragsrechtlich fassbar wird, müssen die harten Punkte in eine **Gemeinschafts- oder Hausordnung, die Bestandteil des Nutzungsvertrags ist**. Charta ist Haltung, Hausordnung ist Vertrag. Beides braucht es.

> **Und das ist gut so.** Derselbe Schutz, der es schwer macht, jemanden loszuwerden, verhindert, dass eine Mehrheit jemanden hinauswirft, der bloß unbequem ist. Ein Haus, in dem ein Plenumsbeschluss die Wohnung kostet, ist kein Zuhause, sondern ein Abhängigkeitsverhältnis (→ 7.4, A.2).

#### Die Eskalationsleiter

| Stufe | Was passiert                                                                                                                                     | Wer entscheidet                     |
| ----- | ------------------------------------------------------------------------------------------------------------------------------------------------ | ----------------------------------- |
| 1     | **Direkte Ansprache**, informell, undokumentiert                                                                                                 | die Beteiligten                     |
| 2     | **Moderiertes Klärungsgespräch**, bei Bedarf extern                                                                                              | AK Konflikt oder externe Moderation |
| 3     | **Formelle Abmahnung**, schriftlich und dokumentiert, mit konkreter Benennung dessen, was aufhören muss                                          | Vorstand                            |
| 4     | **Entzug von Ämtern und von Nutzungsrechten, die nicht Teil des Mietvertrags sind**, etwa Veranstaltungsraum-Buchung oder Gästezimmer-Kontingent | Plenum                              |
| 5     | **Vereinsausschluss** nach dem Satzungsverfahren, mit Anhörung und Berufungsmöglichkeit                                                          | zuständiges Organ laut Satzung      |
| 6     | **Mietrechtliche Kündigung**, anwaltlich begleitet, letzte Stufe                                                                                 | Vorstand                            |

#### Drei Grenzen, ohne die das Instrument gefährlich wird

- **Gewalt und Übergriffe laufen nicht über diese Leiter**, sondern sofort über 7.9. Die Leiter ist für Haltung zuständig, nicht für Sicherheit, und sie ist zu langsam für den Fall, in dem jemand geschützt werden muss.
- **Wer das Verfahren betreibt, darf nicht befangen sein** (→ 7.8). Ausschluss ist das Instrument mit dem größten Missbrauchspotenzial im ganzen Modell, gerade in einem Haus mit überlappenden Beziehungen.
- **Die Schwelle gehört hoch und wörtlich in die Satzung:** _offensichtlich und wiederholt_, nach vorheriger Abmahnung. Nicht „passt uns nicht". Ohne diese Formulierung wird der Ausschluss über kurz oder lang zum Mehrheitswerkzeug gegen Minderheitenpositionen, und dann trifft er genau die Menschen, für die dieses Haus gebaut wurde.

**Anwaltlich prüfen lassen** (→ 12.3): die Ausschlussklausel, die Kopplung von Mitgliedschaft und Nutzungsvertrag, und die Frage, welche Teile der Gemeinschaftsordnung wirksam Vertragsbestandteil werden können.

---

## 4 Finanzierung

> **Alle Zahlen sind grobe Größenordnungen zum Nachrechnen, Stand 2026, keine Angebote.** Der Rechenweg ist absichtlich offengelegt, damit ihr ihn mit eigenen Annahmen wiederholen könnt.

### 4.1 Raum- und Kapitalbedarf

| Position                                | Annahme                                                                         | Ergebnis                   |
| --------------------------------------- | ------------------------------------------------------------------------------- | -------------------------- |
| Privatfläche                            | 25 bis 35 m² je Person × 20                                                     | 500 bis 700 m²             |
| Gemeinschaftsfläche                     | 12 bis 22 m² je Person, steigt bei kleinerer Gruppe                             | 250 bis 450 m²             |
| Gästezimmer + Veranstaltung             | pauschal, **unabhängig von der Gruppengröße**                                   | 100 bis 150 m²             |
| **Gesamt**                              |                                                                                 | **ca. 850 bis 1.300 m²**   |
| Bestandskauf + Sanierung                | 2.500 bis 4.000 €/m²                                                            | 2,1 bis 5,2 Mio. €         |
| Neubau inkl. Baunebenkosten             | 4.000 bis 5.000 €/m² zzgl. Grundstück                                           | 3,4 bis 6,5 Mio. € + Boden |
| **Realistischer Korridor**              | ohne die günstigste Kombination aus Kleinstobjekt und Minimalsanierung          | **3 bis 5,5 Mio. €**       |
| Nachrangkapital, das die Bank verlangt  | 20 bis 30 %, **Mindestanforderung**; im Syndikat über Direktkredite dargestellt | **0,6 bis 1,65 Mio. €**    |
| Je Bewohner:in, ungemildert             | ÷ 20                                                                            | 30.000 bis 82.000 €        |
| **Je Kapitalgeber:in bei 35 Schultern** | konservativ, weil längst nicht alle aus den drei Kreisen Kapital geben (→ 2.1)  | **17.000 bis 47.000 €**    |

**Die letzten drei Zeilen sind die Untergrenze, nicht das Ziel.** Sie rechnen mit der Mindestquote der Bank. Geplant wird mit einer **Nachrangquote von 50 %**, weil jeder Euro Direktkredit den Kapitaldienst senkt; bei 35 Schultern sind das dann 43.000 bis 79.000 € statt 17.000 bis 47.000 €. Wie sich diese Summe auf mehr Schultern verteilt und was daraus monatlich folgt, steht vollständig in **4.7**.

**Was in der Gemeinschaftsfläche steckt:** Küche, Essraum, zwei Wohnzimmer, Cozy-Raum, Workshopraum, Sauna, Werkstatt, Lager, Flure und Sanitär. Am unteren Rand des Korridors geht das nur auf, wenn der Veranstaltungsraum teilbar ist und den Workshopraum mit übernimmt (→ 10.4).

Derselbe Rechenweg für die anderen beiden Punkte des Korridors 20 bis 40 (→ 2.1):

| Menschen im Haupthaus | Privatfläche       | Gemeinschaft   | Gäste + Veranstaltung | Gesamt               | pro Kopf     |
| --------------------- | ------------------ | -------------- | --------------------- | -------------------- | ------------ |
| **20**                | 500 bis 700 m²     | 250 bis 450 m² | 100 bis 150 m²        | **850 bis 1.300 m²** | 43 bis 65 m² |
| 30                    | 750 bis 1.050 m²   | 300 bis 540 m² | 100 bis 150 m²        | 1.150 bis 1.740 m²   | 38 bis 58 m² |
| 40                    | 1.000 bis 1.400 m² | 360 bis 640 m² | 100 bis 150 m²        | 1.460 bis 2.190 m²   | 37 bis 55 m² |

Pro Kopf wird es nach oben also **billiger**, weil sich Küche, Veranstaltungsraum und Gästetrakt auf mehr Schultern verteilen. Der Haken steht nicht in der Tabelle: Ab etwa 1.400 m² schrumpft der Kölner Objektmarkt auf Klöster, Heime und ehemalige Kliniken zusammen (→ 10.2), und die Governance wird bei vierzig Menschen spürbar schwerer als bei zwanzig (→ 6.1). **Deshalb 20 als Planungszahl und 40 als offener Deckel, nicht umgekehrt.**

Zwei Dinge, die leicht übersehen werden:

1. **Halbe Gruppe heißt nicht halbe Kosten.** Küche, Speisesaal, Veranstaltungsraum, Gästezimmer, Technik und Erschließung sind weitgehend fix, deshalb steigt die Gemeinschaftsfläche _pro Person_ bei kleinerer Gruppe, und der Gesamtbedarf sinkt um etwa ein Viertel statt um ein Drittel.
2. **Der eigentliche Hebel ist die breitere Basis.** Direktkredite aus Einzugsgebiet und Trägerkreis lassen deutlich mehr Schultern dieselbe Summe tragen, ohne dass mehr Menschen im Haus wohnen. Dieses Kapital ist **freiwillig und kein Preis für die Zugehörigkeit** (→ 2.1).

### 4.2 Was diese Zahl drückt

- **Erbbaurecht** statt Grundstückskauf nimmt den Bodenanteil vollständig aus der Finanzierung. In Köln der größte Einzelhebel.
- **Direktkredite** aus dem erweiterten Umfeld stellen das Nachrangkapital dar und ersetzen darüber hinaus einen Teil des Bankdarlehens. Deshalb liegen die 1,5 bis 2,5 Mio. € aus 3.3 über den 0,6 bis 1,65 Mio. €, die eine Bank mindestens verlangt (→ 4.1). Sie kosten 0 bis 2 % statt 4 bis 5 %: Jeder Euro, der von der Bank zu den Direktkrediten wandert, senkt den Kapitaldienst. Bei hälftiger Aufteilung liegt er gerechnet bei **5,15 %** statt bei **6,1 %** für ein reines Bankdarlehen (→ 4.7).
- **NRW-Wohnraumförderung**, also öffentliche Baudarlehen mit Tilgungsnachlässen. Preis: Einkommensgrenzen und Mietobergrenzen für die geförderten Einheiten.
- **Spenden** über den gemeinnützigen Community-Verein (→ 3.5).
- **Konzeptvergabe** statt Höchstgebot. Dort zählt das Konzept, nicht der Preis.

Kombiniert lässt sich der Bedarf je Kapitalgeber:in realistisch in Richtung **10.000 bis 22.000 €** bewegen. Das setzt allerdings einen Kreis von rund **70 bis 150 Menschen** voraus, die Kapital geben; die Rechnung dazu steht in 4.7. Und es bleibt für viele Menschen viel Geld (→ 4.5).

### 4.3 Was der Standort mit der Zahl macht

> **Die Stadtfrage ist offen und wird jetzt nicht entschieden.** Köln ist die klare Präferenz, Bonn eine ernsthafte Alternative und keine Verlegenheitslösung. Sich früh auf eine Stadt festzulegen, halbiert die Objektsuche ohne Gegenwert.

Größenordnungen, keine Marktdaten. Belastbare Zahlen liefern der Gutachterausschuss der jeweiligen Stadt und das Bodenrichtwertportal **BORIS.NRW**, beides kostenlos. Der Bodenanteil ist der einzige Kostenblock, den der Standort wirklich bewegt: Bauen und Sanieren kostet in Lindlar ungefähr dasselbe wie in Ehrenfeld.

| Korridor                                                                                                         | Boden                                   | Objektverfügbarkeit für 850 bis 1.300 m²      | Erreichbarkeit                    | Wirkung aufs Pro-Kopf-Kapital                                             |
| ---------------------------------------------------------------------------------------------------------------- | --------------------------------------- | --------------------------------------------- | --------------------------------- | ------------------------------------------------------------------------- |
| **Köln innerhalb des Gürtels**                                                                                   | sehr hoch                               | praktisch null im freien Verkauf              | ideal                             | Kauf unrealistisch. **Nur über Konzeptvergabe oder Erbbaurecht** (→ 10.1) |
| **Köln Randlagen** (Porz, Chorweiler, Ostheim, Bocklemünd)                                                       | hoch, aber Faktor 2 bis 3 unter zentral | gelegentlich: Gewerbe, Schulen, Kirchenbauten | KVB/S-Bahn, 20 bis 40 min         | spürbar niedriger, Profil bleibt städtisch                                |
| **Speckgürtel mit Schienenanschluss** (Leverkusen, Bergisch Gladbach, Frechen, Hürth, Brühl, Pulheim, Troisdorf) | deutlich niedriger                      | brauchbar                                     | 20 bis 40 min, meist umsteigefrei | **das beste Verhältnis** aus Preis und Anbindung                          |
| **Bonn und rechtsrheinisches Umland** (inkl. Königswinter, Bad Honnef)                                           | mittel                                  | brauchbar                                     | eigener Anker, nicht Köln-Pendel  | funktioniert gut, **wenn der soziale Schwerpunkt mitgeht**                |
| **30 bis 50 km** (Bergisches Land, Rhein-Erft-West, Euskirchen, Düren, Rhein-Sieg-Süd)                           | niedrig                                 | gut: Höfe, Klöster, Heime, Gasthöfe           | 45 bis 75 min, oft mit Umstieg    | größter Preishebel, **höchster sozialer Preis**                           |

**Warum Bonn ernst gemeint ist.** Im rechtsrheinischen Raum um Bonn, konkret **Vinxel bei Königswinter**, lebt bereits ein poly Umfeld, das zum Projekt gehören könnte. Räumliche Nähe zu bestehenden Beziehungen ist genau das, was das Einzugsgebiet aus 2.1 mit Leben füllt, und sie ist an einem neuen Ort nicht herstellbar. Bonn hat außerdem eine eigene queere Infrastruktur, eine Universität und mit **Amaryllis** ein großes gemeinschaftliches Wohnprojekt vor Ort (→ 14.4). Dagegen spricht: Die queere Community-Infrastruktur ist kleiner als in Köln, und die Kölner Anlaufstellen aus Abschnitt 14 sind dann eine Bahnstunde entfernt.

Drei Punkte, die bei der Umlandfrage meist übersehen werden:

1. **Der Sanierungsanteil frisst den Umlandvorteil.** Bau und Technik kosten überall gleich viel; der Vorteil liegt bei Boden und Kaufpreis. Wer 40 km rausgeht, halbiert nicht die Gesamtkosten.
2. **Anbindung ist hier kein Komfort, sondern Substanz.** Das Haus lebt von Gästezimmern, offenen Formaten und einem Trägerkreis, der ohne Auto nachts wieder wegkommt. Praktischer Prüfstein: **letzte Verbindung in die nächste Großstadt an einem Samstag um 1 Uhr.**
3. **Die Umlandvariante passt zur Drei-Kreise-Struktur**, also großes Objekt draußen plus Einzugsgebiet in der Stadt. Das entschärft die Erreichbarkeitsfrage und verkompliziert Governance und Mitgliedschaft erheblich (→ 12.2).

**Faustregel:** Innerhalb der Stadt lautet die Frage _„bekommen wir überhaupt ein Objekt?"_, draußen _„zieht die Gruppe wirklich mit?"_. Beides sind Machbarkeitsfragen, aber sie scheitern an verschiedenen Dingen.

### 4.4 Laufende Finanzen

| Topf                        | Zweck                                           | Größenordnung                                                                                                                                                                                             |
| --------------------------- | ----------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Nutzungsgebühr**          | Kapitaldienst + Betriebskosten + Rücklage       | **am unteren Rand des Korridors** (→ 4.1), also bei ca. 3 Mio. € Gesamtkapital und 6 % Kapitaldienst: **1.050 bis 1.400 € pro Person und Monat, warm**. Aufschlüsselung und oberes Ende unter der Tabelle |
| **Haushaltskasse**          | Gemeinschaftsküche, Lebensmittel                | Pro-Kopf-Umlage, erfahrungsgemäß **100 bis 160 € pro Person und Monat**                                                                                                                                   |
| **Solidarfonds**            | Ausfälle bei Jobverlust, Krankheit, Krise       | Umlage, Zielgröße mindestens 2 bis 3 volle Monatsgebühren je gleichzeitig getragenem Ausfall, also rund 2.100 bis 4.200 €                                                                                 |
| **Instandhaltungsrücklage** | Substanzerhalt über Jahrzehnte                  | **1,2 bis 1,5 % des Wiederbeschaffungswerts pro Jahr**, satzungsfest. Der langfristige Teil wird angelegt (→ 4.6)                                                                                         |
| **Projektbudget**           | Reparaturen, Anschaffungen, gemeinsame Vorhaben | jährlich beschlossen, an Arbeitskreise delegiert                                                                                                                                                          |
| **Konfliktbudget**          | externe Mediation, Awareness-Fortbildung        | jährlicher Posten, siehe 7.5                                                                                                                                                                              |
| **Solidarbeitrag Syndikat** | Startkapital künftiger Projekte                 | 10 bis 90 Cent je m² und Monat, steigend über rund zehn Jahre; hier **4 bis 7 €** je Person und Monat am Anfang, später **38 bis 59 €** (→ 3.3, 4.7)                                                      |

**Woraus sich die Nutzungsgebühr zusammensetzt**, damit die Zahl nachrechenbar bleibt und nicht geglaubt werden muss:

| Bestandteil             | Rechenweg                                                                         | pro Person und Monat  |
| ----------------------- | --------------------------------------------------------------------------------- | --------------------- |
| Kapitaldienst           | 3 Mio. × 6 % Annuität aus Zins und Tilgung (→ 4.7) = 180.000 € im Jahr, ÷ 20 ÷ 12 | **750 €**             |
| Betriebskosten, warm    | 3,50 bis 4,50 € je m² bei 43 bis 65 m² pro Kopf (→ 4.1)                           | 150 bis 290 €         |
| Instandhaltungsrücklage | 36.000 bis 80.000 € im Jahr (→ 4.6), ÷ 20 ÷ 12                                    | 150 bis 333 €         |
| **Summe**               |                                                                                   | **1.050 bis 1.400 €** |

**Das ist das untere Ende, nicht die Mitte.** Betriebskosten und Rücklage sind als Bandbreite geführt, der größte Posten dagegen nicht. Am oberen Rand des Korridors aus 4.1, also bei 5,5 Mio. €, steigt allein der Kapitaldienst rechnerisch auf rund **1.375 €** und die Summe auf knapp **2.000 €**. Welches Ende eintritt, entscheidet der Sanierungszustand des Objekts, und das ist beim Lesen der Zahl mitzudenken.

**Mit Erbbaurecht sieht es anders aus, aber weniger anders als erhofft.** Fällt der Bodenanteil aus der Finanzierung, sinkt das Gesamtkapital grob auf 2 Mio. €, dafür kommt ein Erbbauzins von 2 bis 4 % des Bodenwerts dazu:

| Bestandteil                 | mit Erbbaurecht        | pro Person und Monat |
| --------------------------- | ---------------------- | -------------------- |
| Kapitaldienst               | 2 Mio. × 6 %           | 500 €                |
| Erbbauzins                  | 1 Mio. Bodenwert × 3 % | 125 €                |
| Betriebskosten und Rücklage | unverändert            | 300 bis 623 €        |
| **Summe**                   |                        | **925 bis 1.250 €**  |

Der Erbbauzins ersetzt also einen Teil des Kapitaldienstes. **Erbbaurecht senkt vor allem den Kapitalbedarf**, also die Direktkredite, die die Gruppe vorher einwerben muss (→ 4.1, 4.7), und nur mäßig die laufende Belastung. Wer es als Hebel gegen die Monatsgebühr verkauft, enttäuscht später.

**Zusammengerechnet** liegt die monatliche Belastung pro erwachsene Person im Haupthaus am unteren Rand des Korridors damit bei **1.200 bis 1.600 €**, warm und inklusive Essen: Nutzungsgebühr, Haushaltskasse und die kleineren Töpfe aus der Tabelle. Was Einzugsgebiet und Trägerkreis beitragen, ist eine eigene Frage und noch offen (→ 12.2). **Diese Höhe macht die soziale Staffelung aus 4.5 von einer Nettigkeit zur Bedingung.**

**Ehrliche Einordnung:** Ein solches Projekt ist in den ersten Jahrzehnten **teurer als der Kölner Markt**, nicht billiger. Der Grund steht in der Tabelle: Ein erheblicher Teil der Gebühr ist **Tilgung und Rücklage**, also kein verlorener Aufwand, sondern Substanz, die im Haus bleibt. Der Vorteil ist zeitlich. Mit der letzten Kreditrate fällt der Kapitaldienst weg, am unteren Rand des Korridors rund 750 € pro Person und Monat, während der Markt weiterläuft. **Nicht auf einen Schlag:** Nach 4.6 soll ein Drittel bis die Hälfte davon acht bis elf Jahre lang in den Kapitalstock weiterlaufen. Danach liegt die Gesamtbelastung bei rund **450 bis 830 € warm und inklusive Essen**, in heutigem Geld gerechnet.

### 4.5 Ungleiches Vermögen und soziale Staffelung

In jeder Gruppe dieser Größe reicht die Spanne von „kann nichts einbringen" bis „kann sechsstellig einbringen". Wird das nicht _vorher_ geregelt, bekommt informell Gewicht, wer viel eingebracht hat, und dieses Gewicht steht in keiner Satzung.

**Der Grundsatz: starke Schultern tragen mehr und bekommen mehr zurück**, ausdrücklich gewollt und mit dem Nennwertprinzip vereinbar, solange drei Ströme getrennt bleiben:

| Strom                                | gestaffelt?                        | Rückfluss beim Auszug                             |
| ------------------------------------ | ---------------------------------- | ------------------------------------------------- |
| **Kapital** (Einlage + Direktkredit) | **ja, ausdrücklich**               | **ja, zum Nennwert, in voller eingezahlter Höhe** |
| **Laufende Nutzungsgebühr**          | ja, aber vorsichtig und freiwillig | nein, ist verbraucht                              |
| **Stimme und Rechte**                | **nie, ausnahmslos**               |                                                   |

„Nennwert" heißt dabei nicht „alle bekommen gleich viel": Wer 60.000 € eingebracht hat, bekommt 60.000 € zurück, wer 10.000 € eingebracht hat, 10.000 €. Ausgeschlossen ist allein die **Wertsteigerung**, damit ein Auszug in dreißig Jahren das Haus nicht sprengt (→ 1.3).

#### Wie die Mehrleistung technisch eingebracht wird

Nicht als größere Einlage, sondern als **Direktkredit**:

|                         | **Einlage / Pflichtanteil**                                                 | **Direktkredit**                                |
| ----------------------- | --------------------------------------------------------------------------- | ----------------------------------------------- |
| Höhe                    | für alle gleich und bewusst **niedrig**, angesetzt mit rund 1.000 € (→ 4.7) | frei, nach Kapazität                            |
| Rechtsnatur             | Mitgliedschaft                                                              | Nachrangdarlehen, eigener Vertrag               |
| Verzinsung              | keine                                                                       | 0 bis 2 %, frei vereinbart (→ 3.3)              |
| Rückzahlung             | bei Austritt, Nennwert                                                      | nach Kündigungsfrist, **unabhängig vom Wohnen** |
| Stimmrecht              | ja, eine Stimme                                                             | **keins**                                       |
| Übertragbar / vererbbar | nein                                                                        | ja                                              |

Vier Gründe: **niedrige Eintrittsschwelle**, weil Mitglied werden wenig kostet und Kapital eine zweite, freiwillige Ebene ist; **harte Rückzahlung**, weil ein Kreditvertrag einklagbar ist und eine Satzungsregel geändert werden kann; **Geld lässt sich nicht in Einfluss umtauschen**, weil Kredit und Stimme verschiedene Rechtsverhältnisse sind; und **erprobt**, weil es das Standardinstrument des Syndikats ist, mit Musterverträgen und Bankakzeptanz.

#### Bandbreitenmodell statt Einzelfallverhandlung

Selbsteinstufung in offene Bänder, orientiert am **Richtwert**: der einzuwerbenden **Direktkreditsumme** geteilt durch die Zahl der Kapitalgeber:innen, nicht dem Gesamtkapital, denn das Bankdarlehen bringt niemand persönlich auf. Im Referenzfall aus 4.7 sind das 1,5 Mio. € auf 35 bis 150 Menschen, je nach Breite des Kreises also **43.000 € bis 10.000 €**:

| Band  | Orientierung                             | Kapitalbeitrag                                                         |
| ----- | ---------------------------------------- | ---------------------------------------------------------------------- |
| **0** | kein verfügbares Vermögen                | 0 €, Platz über einen von der Gruppe vermittelten Direktkredit Dritter |
| **1** | begrenzte Rücklagen                      | ca. ½ Richtwert                                                        |
| **2** | Regelfall                                | Richtwert                                                              |
| **3** | Erbe, Immobilienverkauf, hohes Einkommen | 2 bis 3 × Richtwert                                                    |
| **4** | darüber                                  | nach Absprache, mit **Deckel** (siehe unten)                           |

Einstufung durch die Person selbst, gegenüber dem AK Finanzen, nicht im Plenum. **Transparenz über Bänder, nicht über Vermögen:** Öffentlich ist nur, dass die Bänder eingehalten wurden.

#### Klumpenrisiko und stille Vetomacht

Wer viel gibt, kann viel zurückfordern. Zwei Gefahren: der **Liquiditätsschock**, wenn eine Person mit 200.000 € auszieht und das Haus die Summe genau dann aufbringen muss, wenn ohnehin ein Platz neu zu besetzen ist, und das **faktische Vetorecht**, denn „wenn ihr so entscheidet, kündige ich meinen Kredit" ist der wirksamste Satz im Raum und steht in keiner Satzung. Sechs Sicherungen, die zusammen wirken müssen:

- **Kündigungsfristen nach Höhe gestaffelt**, kleine Beträge 6 bis 12 Monate, große 24 bis 36.
- **Jahresdeckel:** maximal ein festgelegter Prozentsatz des Direktkreditvolumens fließt pro Jahr ab.
- **Nachrücker-Prinzip:** Auszahlung, sobald ersetzt, aber mit **harter Außengrenze**.
- **Rückzahlungsreserve** als eigener Topf, nicht aus der Instandhaltungsrücklage.
- **Obergrenze je Person**, Größenordnung 10 % des Gesamtkapitals, Überschreitung nur mit qualifiziertem Beschluss.
- **Entkopplung von Kapital und Wohnrecht, in beide Richtungen.** Wer auszieht, verliert das Wohnrecht, nicht das Geld; wer den Kredit kündigt, verliert nicht das Wohnrecht. Eine angedrohte Kreditkündigung ist **kein zulässiges Argument** in einer Sachdebatte, und das gehört in die Geschäftsordnung.

#### Staffelung auch bei den laufenden Kosten?

Möglich, aber deutlich heikler als beim Kapital:

- **Sockelgebühr für alle gleich**, je m² und kostendeckend, plus **freiwilliger Solidaraufschlag** in Bändern, aus dem Nachlässe finanziert werden.
- **Kein Rechtsanspruch auf Nachlass**, sondern befristeter, wiederholbarer Beschluss einer kleinen, rotierenden Kommission auf Antrag, nicht im Plenum.
- **Rechtliche Fallstricke:** öffentliche Wohnraumförderung schreibt Miet- und Einkommensgrenzen vor (→ 4.2), unterschiedliche Entgelte für dieselbe Leistung brauchen eine Grundlage im Nutzungsvertrag, verbilligte Überlassung kann steuerlich relevant werden.
- **Der soziale Fallstrick ist der größere:** Ein Nachlass, der jedes Jahr vor der Gruppe erbeten werden muss, ist keine Solidarität, sondern eine Bittsteller-Position.

#### Was ausgeschlossen bleibt

Rendite über den Nennwert hinaus, Wertsteigerung, Stimmgewicht nach Kapital, bevorzugte Zimmerwahl, dauerhafte Sonderrechte für Gründer:innen.

> **Rechtlicher Hinweis:** Nachrangdarlehen von vielen Privatpersonen können unter das Vermögensanlagengesetz fallen, Stichwort Prospektpflicht. Es gibt Ausnahmen und Schwellenwerte, und das Syndikat hat dafür erprobte Muster. **Mit Musterverträgen arbeiten und einmal prüfen lassen.**

### 4.6 Der Kapitalstock: eine Rücklage, die arbeitet

> **Die Normen sind am Gesetzestext geprüft** (gesetze-im-internet.de, Stand August 2026), die **Anwendung auf diesen Fall** ist es nicht. Ob die erweiterte Kürzung hält und wo die Grenze zur verdeckten Gewinnausschüttung liegt, entscheidet eine Steuerkanzlei (→ 12.3).

**Eine Rücklage ist der gesetzliche Normalfall.** § 19 Abs. 2 Nr. 4 WEG zählt „die Ansammlung einer angemessenen Erhaltungsrücklage" zur ordnungsmäßigen Verwaltung, einklagbar nach § 44 Abs. 1 Satz 2 WEG. Sie gehört zum Gemeinschaftsvermögen (§ 9a Abs. 3 WEG), wer verkauft, bekommt seinen Anteil nicht ausgezahlt. Ungewöhnlich ist hier nur, dass das Geld **angelegt** wird statt auf dem Konto zu liegen: Bei 2 % Inflation verliert es in dreißig Jahren rund **45 % seiner Kaufkraft**.

#### Wie hoch, und woher die Zahl kommt

| Maßstab                | Ansatz                                                                                                                                                                 | Deckt                                                                                                                 |
| ---------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------- |
| **§ 28 Abs. 2 II. BV** | 7,10 € / 9,00 € / 11,50 € je m² und Jahr, gestaffelt nach Gebäudealter (unter 22, ab 22, ab 32 Jahre), plus 1 € mit Aufzug                                             | nur laufende Instandhaltung. **Ausdrücklich nicht** Modernisierung und nicht die Erneuerung von Anlagen (§ 28 Abs. 1) |
| **Peterssche Formel**  | Herstellungskosten × 1,5 / 80 Jahre, also 1,875 % pro Jahr. Bei Herstellungskosten von 1.500 €/m² sind das 28,13 € je m² und Jahr, bei 3.000 €/m² entsprechend 56,25 € | den vollen Lebenszyklus: Dach, Fenster, Heizung, Leitungen                                                            |

Nach Peters entfallen 65 bis 70 % auf das Gemeinschaftseigentum, bei 1.500 €/m² Herstellungskosten also rund 19,69 € je m². Mit den 2.500 bis 4.000 €/m² aus 4.1 gerechnet sind es 33 bis 52 € je m² und Jahr, und dort liegt auch die Rücklage aus 4.4: 36.000 bis 80.000 € auf 850 bis 1.300 m² sind 42 bis 62 € je m². **Genau dort liegen die 1,2 bis 1,5 % des Wiederbeschaffungswerts aus 4.4 und 9.3** (1,875 % × 70 % = 1,31 %), also der branchenübliche Wert. Die Prozentzahl ist von der Basis unabhängig, die Absolutwerte sind es nicht: **Welcher Wiederbeschaffungswert gilt, gehört ausdrücklich festgelegt**, sonst rechnen zwei Menschen mit derselben Formel um den Faktor zwei auseinander (→ 12.2, Frage 19).

> **Darin steckt eine offene Entscheidung.** Die 30 bis 35 %, die im Wohnungseigentum jede Eigentümerin selbst trägt, hat hier niemand, denn Sondereigentum gibt es nicht. Entweder der Satz steigt Richtung 1,9 %, oder es steht ausdrücklich hier, welchen Teil die Bewohner:innen selbst tragen (Schönheitsreparaturen, Geräte, Selbsthilfe). Bei 850 bis 1.300 m² sind das 7.000 bis 11.000 € im Jahr Unterschied (→ 12.2).

#### Warum der Stock in der Haus-GmbH liegt

- **Der gemeinnützige Verein darf die Wohnkosten seiner eigenen Mitglieder nicht senken.** Ein abgeschlossener Personenkreis ist keine Förderung der Allgemeinheit (§ 52 Abs. 1 Satz 2 AO), Mittel zugunsten eigener Mitglieder verstoßen gegen das Selbstlosigkeitsgebot (§ 55 AO). Ein Stock dort kostet die Gemeinnützigkeit (→ 3.5, Risiko 20).
- **Der gemeinnützige Zweig darf auch nicht still ansparen.** Mittel sind binnen zwei Jahren zu verwenden (§ 55 Abs. 1 Nr. 5 Satz 3 AO), ausgenommen Körperschaften bis 100.000 € Jahreseinnahmen. Dauerhaft frei bleiben nur die freie Rücklage nach § 62 Abs. 1 Nr. 3 AO und Zuwendungen zur Vermögensausstattung nach § 62 Abs. 3 AO.

Die **Haus-GmbH** ist zugleich der steuerlich günstigere Ort: Aktienteilfreistellung **80 %** (§ 20 Abs. 1 Satz 3 InvStG), für die Gewerbesteuer nur zur Hälfte (§ 20 Abs. 5 InvStG), also 40 %.

| Auf Fondserträge                   | Privatdepot       | Haus-GmbH (Hebesatz 475 %) |
| ---------------------------------- | ----------------- | -------------------------- |
| Körperschaft- bzw. Abgeltungsteuer | 26,375 % auf 70 % | 15,825 % auf 20 %          |
| Gewerbesteuer                      | keine             | 16,625 % auf 60 %          |
| **Effektive Belastung**            | **ca. 18,5 %**    | **ca. 13,1 %**             |

Der Preis: Aus der GmbH kommt das Geld nur mit einer zweiten Steuerebene wieder heraus. Für einen Stock, der das Haus nie verlassen soll, ist das richtig.

#### Zwei Fallen

- **Verwalten, nicht handeln.** § 9 Nr. 1 Satz 2 GewStG gewährt die erweiterte Kürzung Unternehmen, die _„ausschließlich eigenen Grundbesitz oder neben eigenem Grundbesitz eigenes Kapitalvermögen verwalten und nutzen"_. Ein Depot ist unschädlich, aktives Handeln kann in gewerblichen Wertpapierhandel kippen, und dann ist die Kürzung nicht nur fürs Depot weg, sondern **für die Mieten**.
- **Privates Geld geht nicht direkt in die GmbH.** § 7 Abs. 8 ErbStG greift nach dem Wortlaut vermutlich nicht, weil er die Werterhöhung von Anteilen einer beteiligten natürlichen Person oder Stiftung erfasst, Gesellschafter hier aber Hausverein und Syndikats-GmbH sind (→ 3.3). Gehört trotzdem der Kanzlei vorgelegt. Eine Einzahlung wäre ohnehin nicht rückzahlbar, erzeugt keine Spendenquittung und schafft die stille Vetomacht aus 4.5. Für Einzelpersonen also **Direktkredit** oder **Spende in den gemeinnützigen Zweig**.

#### Drei Stufen, und zwar in dieser Reihenfolge

| Stufe                | Ziel                                                      | Wann                             | Woraus gespeist                                                   |
| -------------------- | --------------------------------------------------------- | -------------------------------- | ----------------------------------------------------------------- |
| **1. Substanzstock** | die Kosten des nächsten vollständigen Sanierungszyklus    | ab Tag eins, parallel zum Kredit | Instandhaltungsrücklage aus 4.4                                   |
| **2. Ertragsstock**  | dauerhafte Senkung der Nutzungsgebühr aus Kapitalerträgen | **erst wenn Stufe 1 voll ist**   | überwiegend der nach der Entschuldung frei werdende Kapitaldienst |
| **3. Weitergabe**    | Erträge über dem Zielkorridor gehen an queere Projekte    | erst wenn Stufe 2 trägt          | Überschusserträge, nie Substanz                                   |

**Stufe 1 ist der eigentliche Zweck.** Nach dreißig bis vierzig Jahren steht ein vollständiger Zyklus an (Heizung, Dach, Fassade, Elektrik, Leitungen, zweite energetische Runde): grob 1.000 bis 1.500 € je m², bei 850 bis 1.300 m² (→ 4.1) also **0,85 bis 1,95 Mio. €**, fällig in wenigen Jahren. Daran sterben Projekte in Generation 2 (→ 9.3, Risiko 17). Bei 4 % Realrendite nach Steuern und dreißig Jahren sind dafür **15.000 bis 35.000 € pro Jahr** nötig, je nach Zielgröße; in der Mitte des Korridors rund **25.000 €**, also etwa 104 € pro Person und Monat bei zwanzig Bewohner:innen. Die Rücklage aus 4.4 liegt mit **36.000 bis 80.000 € pro Jahr** darüber, das sind 1,2 bis 1,5 % auf einen Wiederbeschaffungswert von 3 bis 5,3 Mio. €. Darin steckt bei einem Kauf allerdings der Bodenanteil, für den es keine Rücklage braucht; genau deshalb muss die Bezugsgröße festgelegt werden (→ 12.2, Frage 19). Der Stock ist also keine Zusatzleistung, sondern die **Langfristschicht** der ohnehin gebildeten Rücklage. **Wer über die Entnahme entscheidet:** Die Entnahmeregel selbst legt das Gesamtplenum fest, über die Verwendung des entnommenen Geldes entscheidet das Hausplenum (→ 6.2).

#### Stufe 2 beginnt erst nach der Entschuldung

Ein Depot neben laufender Hypothek ist ein kreditfinanziertes Investment: Solange 3,5 bis 4,5 % Zins laufen, ist Sondertilgung die risikofreie Alternative, und Aktiencrash, Zinssprung und fällige Anschlussfinanzierung sind **dasselbe Szenario**. Die größte Senkung kommt ohnehin aus der Entschuldung selbst. Bei rund 3 Mio. € Gesamtkapital und 6 % Kapitaldienst, also am unteren Rand des Korridors aus 4.1, fallen mit der letzten Rate etwa 180.000 € im Jahr weg, grob 750 € pro Person und Monat. Am oberen Rand ist es rund das Doppelte (→ 4.4). Was ein Ertragsstock daneben leistet, bei 3 % realer Entnahme und zwanzig Bewohner:innen:

| Dauerhafte Senkung je Person und Monat | Jährlicher Ertrag nötig | Kapital nötig  |
| -------------------------------------- | ----------------------- | -------------- |
| 50 €                                   | 12.000 €                | **400.000 €**  |
| 100 €                                  | 24.000 €                | **800.000 €**  |
| 200 €                                  | 48.000 €                | **1,6 Mio. €** |

Läuft nach der Entschuldung **ein Drittel** des frei werdenden Kapitaldienstes weiter, rund 60.000 € im Jahr, sind 800.000 € in etwa **elf Jahren** erreicht; bei **der Hälfte**, rund 90.000 €, in etwa **acht Jahren**.

> **Diese Entscheidung muss jetzt getroffen werden, nicht in Jahr 30.** In dem Jahr, in dem die letzte Rate abgebucht ist, wird kein Plenum freiwillig beschließen, ein Drittel davon weiterzuzahlen. Die Regel gehört in die Finanzordnung, bevor jemand das Geld in der Hand hatte.

#### Die Entnahmeregel

**3 % real, nicht 4 %**, denn die Vier-Prozent-Regel gilt für dreißig Jahre Ruhestand, nicht für die Ewigkeit. Drei Bedingungen gelten zusammen:

1. **Geglättet:** 3 % des durchschnittlichen Depotwerts der letzten drei Jahre.
2. **Nur oberhalb von Stufe 1**, deren Zielwert jährlich mit dem Baupreisindex fortgeschrieben wird, damit er nicht heimlich schrumpft.
3. **Nur solange die GmbH kostendeckend arbeitet**, sonst droht die Prüfung auf verdeckte Gewinnausschüttung (→ 12.3).

#### Was gesenkt werden darf, und was nicht

- **Nutzungsgebühr senken: sauber.** Ein anderer Einnahmemix derselben Gesellschaft für dieselben Kosten.
- **Betriebskosten gemeinschaftlicher Räume und Technik übernehmen: sauber.** Strom, Warmwasser, Lüftung, Wartung und Ersatz der Küchentechnik sind Hauskosten.
- **Essensgeld subventionieren: nicht sauber.** Die Haushaltskasse (→ 4.4) ist ein privater Topf von Privatpersonen; Geld aus der GmbH dorthin ist eine Zuwendung an nahestehende Personen.

Die Entlastung läuft also über **eine Zahl**, die Nutzungsgebühr. Das hebelt auch die soziale Staffelung aus 4.5 nicht aus.

#### Anlagerichtlinie

| Topf                                                         | Horizont       | Anlage                                                     |
| ------------------------------------------------------------ | -------------- | ---------------------------------------------------------- |
| Konkrete Maßnahmen und Rückzahlungsreserve für Direktkredite | 0 bis 5 Jahre  | Tagesgeld, kurze Anleihen. **Keine Aktien**                |
| Zinsänderungsrisiko der Anschlussfinanzierung                | 5 bis 15 Jahre | gemischt, Laufzeit auf das Ende der Zinsbindung abgestimmt |
| Substanz- und Ertragsstock                                   | über 15 Jahre  | breit gestreuter globaler Aktien-ETF, thesaurierend        |

Dazu vier Festlegungen, **einmal** getroffen und dann in Ruhe gelassen: **Aktienquote gekoppelt an die Restschuld** nach fester Staffel statt nach Marktlage; **Ausschlusskriterien vorab beschlossen**, Änderung nur mit qualifizierter Mehrheit; **keine Einzelwerte, keine aktive Steuerung, kein Timing**, weil aktives Handeln die erweiterte Kürzung gefährdet; **Rebalancing nach Kalender**, einmal jährlich.

#### Was den Stock überleben lässt

Das größte Risiko ist nicht die Börse, sondern das eigene Plenum:

- **Zugriff:** zweckgebunden, angreifbar nur mit **qualifizierter Mehrheit plus Sperrfrist**, wie die Rücklage in 9.3 und die Verkaufsfrage in 3.3.
- **Dauerdebatte:** Die Richtlinie gilt, bis sie mit qualifizierter Mehrheit geändert wird. Kursverläufe sind kein Änderungsgrund.
- **Macht:** Vier-Augen-Prinzip, keine Alleinvertretung, Rotation, jährlicher externer Blick auf den Abschluss (→ 7.8, A.2).

Falls Stufe 3 ernst wird, braucht es ein externes Gegengewicht wie das Syndikat beim Verkauf (→ 3.3, 9.1 Nr. 1): eine **Stiftung unter staatlicher Stiftungsaufsicht**, Einstieg über eine **Treuhandstiftung** unter fremdem Dach ohne Mindestkapital, eine eigene rechtsfähige Stiftung in der Praxis eher ab 50.000 bis 100.000 € Grundstock. Für Vermächtnisse zählt der Unterschied: an eine gemeinnützige Körperschaft erbschaftsteuerfrei (§ 13 Abs. 1 Nr. 16 lit. b ErbStG), an die nicht gemeinnützige Haus-GmbH Steuerklasse III. **Die Befreiung fällt rückwirkend weg, wenn die Gemeinnützigkeit binnen zehn Jahren nach der Zuwendung entfällt** (→ Risiko 20).

#### Der Stock ist eine Übergabe

Wer in den ersten dreißig Jahren einzahlt, ist nicht die Person, die in Jahr 45 günstiger wohnt (→ 9.1, 9.3). Das ist so gewollt, muss aber ausgesprochen werden, und gehört früh in die Finanzordnung:

> **Der Kapitalstock gehört dem Haus, nicht den Einzahlenden.** Wer auszieht, bekommt seinen Direktkredit zurück, aber keinen Anteil am Stock. Keine Quote, keine Anwartschaft, keine Abfindung.

### 4.7 Alles auf einen Blick: Kapitalstruktur, Kredite, Phasen

Dieser Abschnitt rechnet nichts Neues, er stellt zusammen, was in 3.3, 4.1 bis 4.6 verteilt steht, und legt die Parameter offen, die dort stillschweigend benutzt werden.

> **Alles hier ist Planungsannahme, kein Beschluss.** Die Zahlen sind so gewählt, dass sie zu den Angaben im übrigen Dokument passen. Sie ersetzen keine Bankanfrage und kein Gespräch mit dem Syndikat (→ 13, Schritt 5).

#### Der Referenzfall

**Im Syndikatsmodell gibt es fast kein echtes Eigenkapital.** Die Haus-GmbH finanziert sich aus Bankdarlehen und Direktkrediten; die Einlagen der Mitglieder sind bewusst niedrig (→ 4.5). Was eine Bank als Eigenkapitalquote verlangt, ist hier deshalb keine Summe, die jemand aufbringen muss, sondern die **Nachrangquote**: Kapital, das im Insolvenzfall hinter der Bank zurücktritt und das im Syndikat über Direktkredite dargestellt wird (→ 4.1). Genau deshalb wird der Kapitaldienst auf das **gesamte** Kapital gerechnet und nicht auf einen Rest nach Abzug von Eigenkapital.

| Baustein               | Referenzfall **3 Mio. €** | oberer Rand **5,5 Mio. €** | Eigenschaften                                                     |
| ---------------------- | ------------------------- | -------------------------- | ----------------------------------------------------------------- |
| Einlagen im Hausverein | rund 20.000 €             | rund 20.000 €              | für alle gleich, unverzinst, Rückzahlung zum Nennwert (→ 4.5)     |
| **Direktkredite**      | **1,5 Mio. €**            | **2,75 Mio. €**            | Nachrangdarlehen, 0 bis 2 % Zins, kündbar mit Frist (→ 3.3, 4.5)  |
| **Bankdarlehen**       | **1,5 Mio. €**            | **2,75 Mio. €**            | erstrangig im Grundbuch, Zinsbindung 10 bis 15 Jahre              |
| **Nachrangquote**      | **50 %**                  | **50 %**                   | Bank verlangt 20 bis 30 %, das Ziel liegt bewusst darüber (→ 4.1) |
| Erbbaurecht-Variante   | 2 Mio. € plus Erbbauzins  | entsprechend niedriger     | senkt den Kapitalbedarf, nicht die Monatsbelastung (→ 4.4)        |

Die 50 % sind der Grund, warum 3.3 von **1,5 bis 2,5 Mio. €** Direktkrediten spricht: Das ist die halbe Bausumme über den ganzen Korridor. Jeder Euro Direktkredit senkt den Kapitaldienst, weil er 0 bis 2 % statt 4 bis 5 % kostet. Deshalb wird mehr eingeworben, als die Bank verlangt.

#### Woher die 6 % kommen

Die 6 % aus 4.4 und 4.6 sind **kein Zinssatz, sondern eine Annuität**: Zins plus Tilgung, gerechnet auf vollständige Entschuldung in rund dreißig Jahren. Wer sie für einen Zins hält, hält die Gebühr für absurd hoch.

| Posten                               | Rechenweg                                 | pro Jahr           | Anteil an 3 Mio. |
| ------------------------------------ | ----------------------------------------- | ------------------ | ---------------- |
| Bankdarlehen                         | 1,5 Mio. €, 4,5 % Zins, 30 Jahre Annuität | rund **92.000 €**  | 3,07 %           |
| Direktkredite                        | 1,5 Mio. €, 1,5 % Zins, 30 Jahre Annuität | rund **62.000 €**  | 2,08 %           |
| **Gerechneter Kapitaldienst**        |                                           | **rund 154.000 €** | **5,15 %**       |
| Puffer für die Anschlussfinanzierung | Zinsbindung endet nach 10 bis 15 Jahren   | rund 26.000 €      | 0,85 %           |
| **Planungssatz im Dokument**         | 3 Mio. × 6 %                              | **180.000 €**      | **6,00 %**       |

Der Puffer ist kein Rechenfehler, sondern die Antwort auf das Risiko aus Register-Nr. 14: Die Zinsbindung läuft aus, das Darlehen läuft weiter. Wer mit 5,15 % plant und bei der Anschlussfinanzierung 7 % bekommt, hat kein Polster. Konkret: Nach fünfzehn Jahren stehen noch rund 990.000 € Restschuld, und der Puffer trägt einen Sprung des Bankzinses von 4,5 auf rund **8,5 %**. **Solange er nicht gebraucht wird, ist er Sondertilgung** und verkürzt die Laufzeit.

#### Was eine einzelne Person einbringt

Der **Richtwert** aus 4.5 ist die Direktkreditsumme geteilt durch die Zahl der Kapitalgeber:innen. Er hängt also nicht am Kapitalbedarf allein, sondern daran, wie breit der Kreis ist. Das ist der Hebel aus 4.2, hier ausgerechnet:

| Kapitalgeber:innen | Richtwert bei 1,5 Mio. € | Richtwert bei 2,75 Mio. € | entspricht                     |
| ------------------ | ------------------------ | ------------------------- | ------------------------------ |
| 35                 | **43.000 €**             | 79.000 €                  | nur Haupthaus plus enger Kreis |
| 50                 | 30.000 €                 | 55.000 €                  |                                |
| 70                 | 21.000 €                 | 39.000 €                  | Haupthaus, Einzugsgebiet, Kern |
| 100                | 15.000 €                 | 28.000 €                  |                                |
| 150                | **10.000 €**             | 18.000 €                  | breiter Trägerkreis (→ 2.1)    |

**Damit ist die Zahl aus 4.2 verortet.** Die dort genannten 10.000 bis 22.000 € je Kapitalgeber:in setzen einen Kreis von **rund 70 bis 150 Menschen** voraus, nicht die 35 Schultern aus 4.1. Die Bänder aus 4.5 legen sich darüber: Band 0 zahlt nichts, Band 1 die Hälfte des Richtwerts, Band 3 das Zwei- bis Dreifache, Band 4 mehr, gedeckelt bei 10 % des Gesamtkapitals, also 300.000 € im Referenzfall.

#### Was es in jeder Phase kostet

Alle Beträge pro erwachsene Person im Haupthaus, am unteren Rand des Korridors, in heutigem Geld. Das obere Ende steht jeweils daneben.

| Phase                                      | Einmalig                                                                                  | Monatlich                                | Wofür                                                                                      |
| ------------------------------------------ | ----------------------------------------------------------------------------------------- | ---------------------------------------- | ------------------------------------------------------------------------------------------ |
| **Vorlauf**, heute bis Kauf, 5 bis 8 Jahre | in Summe 1.500 bis 4.800 €                                                                | **25 bis 50 €** (→ 5.3)                  | Beratung, Moderation, Notar, Gutachten. Verbraucht, nicht angelegt                         |
| dazu optional der Zwischenschritt (→ 5.2)  | Kaution                                                                                   | Marktmiete, geteilt durch 6 bis 12       | gemietet, kein Kapital gebunden                                                            |
| **Kauf und Einzug**, Jahr 0                | Einlage rund 1.000 € **plus Direktkredit nach Band**, im Referenzfall 10.000 bis 43.000 € | Umzug und Einrichtung privat             | Einlage begründet die Mitgliedschaft, der Direktkredit finanziert das Haus                 |
| **Kreditlaufzeit**, Jahr 1 bis 30          |                                                                                           | **1.200 bis 1.600 €**, oben rund 2.150 € | Nutzungsgebühr, Haushaltskasse und die kleineren Töpfe, warm und inklusive Essen (→ 4.4)   |
| **Kapitalstockphase**, Jahr 30 bis 40      |                                                                                           | **700 bis 1.205 €**                      | die 450 bis 830 € von unten plus die 250 bis 375 €, die weiter in den Stock laufen (→ 4.6) |
| **Danach**, ab Jahr 40                     |                                                                                           | **450 bis 830 €**                        | nur noch Betriebskosten, Rücklage und Essen                                                |
| dazu die Entnahme aus dem Ertragsstock     |                                                                                           | **minus 50 bis 200 €**                   | 3 % real aus 0,4 bis 1,6 Mio. € Stock (→ 4.6)                                              |

**Die Phasenlogik in einem Satz:** In den ersten dreißig Jahren zahlt das Haus über dem Markt, weil ein erheblicher Teil der Gebühr Tilgung ist; danach zahlt es weit darunter, weil der Markt weiterläuft und das Haus abbezahlt ist.

**Der Sprung zwischen Jahr 30 und 40 ist eine Entscheidung, keine Automatik.** Mit der letzten Rate fallen rund 750 € pro Person und Monat frei. Darauf greifen zwei Ansprüche zu: zuerst der **Kapitalstock** (→ 4.6), erst dann die Senkung der eigenen Gebühr. Der **Solidarbeitrag ans Syndikat** steht dabei nicht mehr zur Debatte, weil er zu diesem Zeitpunkt längst am Deckel läuft; er gehört in die Jahre davor und ist im nächsten Absatz gerechnet.

**Was der Solidarbeitrag konkret kostet.** Die Sätze stehen in 3.3, hier die Umrechnung auf dieses Haus. Der erste Teil, 10 Cent je m² und Monat, ergibt auf 850 bis 1.300 m² Nutzfläche **85 bis 130 € im Monat für das ganze Haus**, bei zwanzig Bewohner:innen also **4 bis 7 € pro Person**. Am Deckel von 90 Cent sind es **765 bis 1.170 €** oder **38 bis 59 € pro Person und Monat**. Dazwischen liegen bei den Gebühren dieses Projekts **acht bis zehn Jahre**, denn die jährliche Stufe von 0,5 % der Jahresnettokaltmiete entspricht hier rund 8 bis 11 Cent je m². Der Beitrag ist also lange vor der Entschuldung ausgereizt und gehört in die Betriebsphase, nicht in die Verteilungsfrage von Jahr 30.

**Zwei Punkte dazu gehören ins Aufnahmegespräch.** Erstens begründet das Syndikat die jährliche Steigerung damit, dass sie zu keiner Mieterhöhung führt, weil die Gesamtbelastung der Haus-GmbH durch Entschuldung ohnehin sinkt. Bei einem **Annuitätendarlehen über dreißig Jahre trifft das nicht zu**: Die Rate bleibt bis zur letzten Zahlung konstant (→ 4.4). Der Solidarbeitrag kommt hier also **obendrauf** und nicht aus einer frei werdenden Summe. Zweitens liegt die Nettokaltmiete dieses Projekts mit rund **17 bis 21 € je m²** über dem Kölner Markt, weil ein teuer gekauftes Objekt auf wenig Fläche je Kopf finanziert wird. Damit dürfte die Klausel greifen, nach der die Steigerung **auf Antrag ausgesetzt** werden kann, sobald die Miete 80 % der ortsüblichen Vergleichsmiete übersteigt. Ob ein queeres Projekt diesen Antrag stellen will, ist eine politische Frage und keine rechnerische.

#### Was beim Auszug zurückkommt

| Fließt zurück                                         | Fließt nicht zurück                               |
| ----------------------------------------------------- | ------------------------------------------------- |
| **Direktkredit zum Nennwert, in voller Höhe** (→ 4.5) | Nutzungsgebühr und Haushaltskasse, verbraucht     |
| **Einlage zum Nennwert**                              | eingezahlte Instandhaltungsrücklage               |
|                                                       | jeder Anteil am Kapitalstock (→ 4.6)              |
|                                                       | **jede Wertsteigerung**, ausdrücklich und gewollt |

Die Rückzahlung ist kein Automatismus am Tag des Auszugs: Kündigungsfristen von 6 bis 36 Monaten nach Höhe, ein Jahresdeckel auf das insgesamt abfließende Volumen, Nachrücker-Prinzip mit harter Außengrenze und eine eigene Rückzahlungsreserve (→ 4.5). **Wohnrecht und Kapital sind in beide Richtungen entkoppelt:** Wer auszieht, verliert das Wohnrecht und nicht das Geld; wer den Kredit kündigt, verliert nicht das Wohnrecht.

#### Die drei Stellschrauben

Alles andere folgt aus diesen drei Zahlen. Sie gehören früh entschieden, weil jede Planungsrunde sonst neu rechnet:

1. **Der Kapitalbedarf**, 3 oder 5,5 Mio. €. Entscheidet den Sanierungszustand des Objekts und verdoppelt den Kapitaldienst.
2. **Die Zahl der Kapitalgeber:innen**, 35 oder 150. Entscheidet, ob der Richtwert 43.000 € oder 10.000 € beträgt, und damit, wer überhaupt mitmachen kann.
3. **Die Nachrangquote**, hier mit 50 % angesetzt. Entscheidet, wie viel des Kapitals zu 1,5 % statt zu 4,5 % läuft, und damit die Monatsgebühr.

## 5 Der Weg dorthin: Track A und Track B

### 5.1 Die Ausgangslage ehrlich

Aktuell: ein **loser Kreis von 10+ Interessierten**. Drei Dinge setzen den Maßstab.

**Die Schwundquote.** Erfahrungswert aus der Wohnprojekte-Szene: Von den Menschen, die anfangs Interesse zeigen, ziehen am Ende **20 bis 30 % wirklich ein**. Rückwärts gerechnet braucht es für 20 Plätze im Haupthaus im Verlauf also **70 bis 100 Interessierte**. Die ganze Drei-Kreise-Struktur umfasst im Zielzustand 20 Menschen im Haupthaus, ein offenes Einzugsgebiet und 40 bis 100+ im Trägerkreis (→ 2.1, 6.2); für Einzugsgebiet und Trägerkreis liegt die Schwelle niedriger als für den Einzug, die Quote dort also besser, aber der Kreis, der über die Jahre angesprochen werden muss, ist trotzdem **niedrig dreistellig**. Bei einem Profil wie diesem (→ 1.2) am pessimistischen Ende rechnen. „Kreis erweitern" ist Daueraufgabe, keine Phase.

**Was wir voneinander noch nicht wissen.** Alle bisherigen gemeinsamen Erfahrungen fanden unter kuratierten Bedingungen statt: begrenzte Zeit, gute Laune als Zweck, jederzeit gehen können. Der Alltag selektiert auf etwas anderes: Müll, Geld, Krankheit, Lärm, Putzplan, der immer gleiche Streit über die immer gleiche Kleinigkeit. Genau deshalb gibt es Track A.

**Geografische Streuung.** Interessierte an einem solchen Projekt sind meist über die Republik verteilt. Die Frage „wer würde tatsächlich in den Raum Köln oder Bonn ziehen" halbiert solche Listen häufig, bevor irgendetwas anderes passiert. Sie gehört früh gestellt (→ 12.1).

### 5.2 Track A: der Zwischenschritt

**Zweck:** die Kernannahme testen, bevor Millionen im Spiel sind, und einen Ort haben, an den man einladen kann, damit der Kreis organisch wächst statt über Powerpoint.

|                     |                                                                                 |
| ------------------- | ------------------------------------------------------------------------------- |
| Größe               | 6 bis 12 Personen                                                               |
| Form                | **gemietet**, nicht gekauft                                                     |
| Objekt              | Hof im Speckgürtel, altes Pfarrhaus, große Etage, ehemalige Praxis oder Kanzlei |
| Dauer               | **befristet, 2 bis 3 Jahre, mit hartem Enddatum**                               |
| Verhältnis zum Ziel | Projekt des Trägervereins, keine Entscheidungsmacht über das Zielprojekt        |
| Pflicht             | Gästezimmer ab Tag eins, regelmäßige offene Formate                             |

**Explizite Lernziele.** Nicht, ob es Spaß macht, das weiß man schon. Sondern diese Fragen, mit protokollierten Antworten:

1. Wie entscheiden wir, wenn wir _uneins_ sind, und nicht wenn wir uns einig sind?
2. Wer macht die unsichtbare Arbeit, und wie wird sie sichtbar? _(→ A.1)_
3. Was passiert, wenn jemand über Wochen depressiv, krank oder überlastet ist?
4. Wie fühlt sich Geld-Ungleichheit im Alltag an?
5. Wie geht die Gruppe mit einer Trennung im Haus um? _(→ Abschnitt 7)_
6. Wie funktioniert gelebte Kink-Kultur in gemeinsam genutzten Räumen, wenn nicht alle beteiligt sind? _(→ 7.6)_
7. Wie erleben Neue den Einstieg in ein bestehendes Beziehungsnetz?
8. Was passiert, wenn jemand ausziehen will?

Diese Erkenntnisse sind der eigentliche Rohstoff für Satzung und Ordnungen.

> **Achtung bei Track A:** Der Zwischenschritt ist _gemietet_. Es gibt eine Vermieterin, eine Nachbarschaft und einen Mietvertrag, und keines davon ist auf ein kink-offenes Haus eingestellt. Das gehört bei der Objektwahl berücksichtigt: freistehend, gute Schalldämmung, entspannte Eigentümerschaft. Nicht als Selbstzensur, sondern damit der Test nicht am falschen Punkt scheitert.

**Die Falle:** Der Zwischenschritt wird bequem. Deshalb Enddatum im Mietvertrag _und_ in der Selbstverpflichtung, und Track B mit eigenen Terminen daneben.

### 5.3 Track B: Struktur und Kapital, parallel

| Meilenstein                         | Ziel                                               |
| ----------------------------------- | -------------------------------------------------- |
| Auftaktwochenende, extern moderiert | breit einladen, aber gezielt ansprechen            |
| Selbstverständnisprozess            | **nicht** vom Initiator moderiert (→ 6.4)          |
| Trägerverein gegründet              | Konto, Beitrag, Beschlussfähigkeit                 |
| Erster Geldschritt aktiv            | 25 bis 50 € pro Monat, finanziert externe Beratung |
| Externe Beratung beauftragt         | Wohnprojekte-Beratung, nicht Makler                |
| Kontakt Syndikat aufgenommen        | Syndikatstreffen besuchen                          |
| Kapitalerhebung im Kreis            | anonyme Bandbreiten-Abfrage, kein Einzelbetrag     |
| Suchprofil beschlossen              | Ort, Größe, Objekttyp, Preisdeckel                 |
| Objektsuche aktiv                   | inkl. Konzeptvergaben und Erbbaurechtsangebote     |

**Der erste Geldschritt ist der schärfste Filter, den es gibt**, und der einzige, der niemandem die Existenz kostet. 25 bis 50 € im Monat trennen Interesse von Absicht zuverlässiger als jedes Gespräch, und sie finanzieren genau die Beratung, die den Unterschied macht.

**Woher die ersten Menschen kommen, entscheidet mehr als jede Satzung.** Die Gründungsgruppe wird gezielt in der **Kink-Community** angesprochen, offensiv und nicht nebenbei. Das folgt direkt aus 3.6: Wenn Kink zur Grundausstattung gehört, muss der Kreis, aus dem die ersten zwanzig Menschen kommen, das mitbringen. Danach übernimmt das Plenum, und ein Plenum nimmt auf, wer zu ihm passt.

Der Preis gehört danebengeschrieben. **Eine Gründungsgruppe aus einer einzigen Szene ist eine Monokultur** und vererbt sich über Jahrzehnte, weil dieselbe Mechanik, die das Profil sichert, auch Vielfalt verhindert. Zwei Gegengewichte von Anfang an: **Einzugsgebiet und Trägerkreis werden ausdrücklich breiter eingeladen** als das Haupthaus (→ 2.1), und die Pflichtfrage „was fehlt dem Haus gerade" aus 3.6 zielt genau hierauf. Wer bei der Gründung nur in einer Szene rekrutiert und nie gegensteuert, hat in zehn Jahren einen Freundeskreis mit Grundbuchauszug (→ Register-Nr. 28, 9.2).

### 5.4 Verbindlichkeitsstufen

Der häufigste Fehler ist ein binäres „dabei oder nicht". Niemand kann in einem Sprung auf vierzig Jahre zusagen. Stufen mit klaren Rechten:

| Stufe            | Verpflichtung                                                           | Rechte                                                                                                                                              |
| ---------------- | ----------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Interessiert** | keine                                                                   | Newsletter, offene Termine, Gast im Zwischenschritt                                                                                                 |
| **Mitdenkend**   | Anwesenheit bei Plena                                                   | Rederecht, Mitarbeit in Arbeitskreisen                                                                                                              |
| **Kerngruppe**   | Monatsbeitrag, verbindliche Mitarbeit                                   | **volles Stimmrecht** bis zum Erstbezug, danach Trägerkammer (→ 6.2)                                                                                |
| **Zeichnend**    | Kapitalzusage nach Band (→ 4.5), **Band 0 ausdrücklich eingeschlossen** | Rückzahlung bei Nichtaufnahme, **kein Anspruch auf einen Platz** (→ 6.6). Der Zugang zum Aufnahmeverfahren hängt an der Mitmachphase, nicht am Geld |

**Keine Stufe ist eine Geldstufe.** Auch Zeichnend beschreibt nur, dass die Kapitalseite geklärt ist, und geklärt heißt bei Band 0 eben null Euro plus ein von der Gruppe vermittelter Direktkredit Dritter (→ 4.5). Wer das Verfahren an eine Zusage knüpfte, hätte das Wohnrecht wieder ans Kapital gebunden.

Aufstieg jederzeit möglich, **Abstieg ohne Gesichtsverlust ausdrücklich vorgesehen**. Das muss kulturell verankert sein, sonst bleiben Leute aus Scham in einer Verbindlichkeit, die sie nicht tragen.

---

## 6 Governance

### 6.1 Entscheidungsverfahren

**Nicht reiner Konsens.** Schon bei zwanzig Menschen im Haus, und einem deutlich größeren stimmberechtigten Kreis (→ 2.1), führt Einstimmigkeit zu Blockade, Erschöpfung und paradoxerweise zu _mehr_ informeller Macht, weil sich Entscheidungen in Küchengespräche verlagern. Jo Freemans [The Tyranny of Structurelessness](https://www.jofreeman.com/joreen/tyranny.htm) beschreibt genau diesen Mechanismus und ist Pflichtlektüre für die Gründungsgruppe.

**Empfehlung: Konsent nach soziokratischem Muster.** Ein Vorschlag ist angenommen, wenn niemand einen _schwerwiegenden, begründeten_ Einwand hat. Es geht nicht um „bin ich dafür", sondern um „steht dem etwas Wichtiges entgegen". Einwände müssen begründet und bearbeitbar sein, Präferenzen sind keine Einwände.

**Delegation mit echtem Mandat.** Arbeitskreise für Haus, Garten, Küche, Finanzen, Aufnahme, Awareness, Kinder und Öffentlichkeit bekommen Budget und Entscheidungsbefugnis in ihrem Bereich. Das Plenum entscheidet über Grundsätze, nicht über Anschaffungen.

### 6.2 Wer entscheidet was: Zuständigkeit und Stimmrecht

Das Projekt hat drei Kreise (→ 2.1) und im Zielzustand drei Körperschaften: den **Hausverein**, dem die Haus-GmbH gehört, den **Trägerverein**, in dem alle Mitglied sind (→ 2.3, 3.3), und den gemeinnützigen **Community-Verein** für Programm und Bildung (→ 3.5). Daraus folgt eine Frage, die sonst im Alltag beantwortet wird und dann nicht mehr korrigierbar ist: **Wer stimmt worüber ab?**

Zwei Fehler sind möglich, und sie zeigen in entgegengesetzte Richtungen:

- **Außenlebende bestimmen die Lebensweise im Haus mit.** Zwanzig Bewohner:innen stehen 40 bis 100 Menschen im Trägerkreis gegenüber. Eine Mehrheit, die die Folgen nicht trägt, entschiede über Nachtruhe, Raumordnung (→ 7.6) oder die Höhe der eigenen Schulden.
- **Außenlebende werden entrechtet.** Genau davor warnt 2.2. Beim Einzugsgebiet wäre es zusätzlich fatal, weil der Umzug dorthin nach 7.4 das Ventil nach einer Trennung ist. Kostet er das Stimmrecht, nimmt ihn niemand freiwillig.

> **Der Maßstab ist Betroffenheit, nicht Wohnort.** Wer die Folgen einer Entscheidung im Alltag trägt, entscheidet sie. Wer das Projekt trägt, entscheidet über das Projekt. Und wer nur verhindern können muss, bekommt ein Veto statt einer Stimme.

#### Die drei Kammern

Jeder Kreis aus 2.1 bildet eine **Kammer**. Die Kammern sind keine eigenen Gremien mit eigenen Sitzungen, sondern die Art, wie im selben Plenum ausgezählt wird.

| Kammer                   | Wer darin ist                                                         | Größenordnung |
| ------------------------ | --------------------------------------------------------------------- | ------------- |
| **Hauskammer**           | Bewohner:innen des Haupthauses                                        | ca. 20        |
| **Nachbarschaftskammer** | Mitglieder im Einzugsgebiet                                           | offen         |
| **Trägerkammer**         | Trägerkreis ab Verbindlichkeitsstufe Kerngruppe (→ 5.4, 12.2 Frage 9) | 40 bis 100+   |

Daraus ergeben sich zwei Sitzungsformen: das **Gesamtplenum** mit allen drei Kammern als Regelfall, und das **Hausplenum**, in dem nur die Hauskammer abstimmt und die anderen beiden Rede- und Antragsrecht haben.

**Mehrfachzugehörigkeit ist möglich, die Stimme nicht.** Die Kreise aus 2.1 liegen ineinander: Wer im Haupthaus wohnt, ist in aller Regel auch Mitglied im Trägerverein. Gezählt wird deshalb pro Beschluss nur in der **innersten Kammer**, der eine Person angehört, also Haupthaus vor Einzugsgebiet vor Trägerkreis. Sonst hätten Bewohner:innen beim Bewahren zwei Stimmen, und der Satz _alle drei Kammern müssen zustimmen_ wäre keine Hürde, sondern eine Verdopplung.

```mermaid
flowchart TB
    subgraph GP["<b>Gesamtplenum</b>"]
        direction LR
        HK["<b>Hauskammer</b><br/>Haupthaus<br/><i>ca. 20</i>"]
        NK["<b>Nachbarschaftskammer</b><br/>Einzugsgebiet<br/><i>offen</i>"]
        TK["<b>Trägerkammer</b><br/>Trägerkreis<br/><i>40 bis 100+</i>"]
    end

    HK ==> HP["<b>Hausplenum</b><br/>Wohnalltag · Nutzungsgebühr<br/>Aufnahme ins Haupthaus"]
    HK ==> HA["<b>Handeln</b><br/>Objektkauf · Kredit<br/>Finanzrahmen · Sanierung"]
    NK ==> HA
    GP ==> BE["<b>Bewahren</b><br/>Zweck · Verkaufsschutz · Auflösung<br/><i>alle drei müssen zustimmen</i>"]
    TK ==> PR["<b>Programm</b><br/>Bildung · Veranstaltungen · Fördermittel<br/><i>Community-Verein</i>"]
```

#### Zuständigkeitsliste

| Gegenstand                                                                                                      | Wer stimmt ab                                                                                                    |
| --------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------- |
| **Wohnalltag im Haupthaus:** Nachtruhe, Küche, Putzplan, Tiere, Raumbelegung, Raumordnung nach 7.6, Gästeregeln | **Hausplenum**                                                                                                   |
| **Nutzungsgebühr**                                                                                              | **Hausplenum**, nicht unter der Mindesthöhe aus dem Finanzrahmen                                                 |
| **Aufnahme ins Haupthaus**                                                                                      | **Hausplenum**, nach der Aufnahmeordnung (→ 6.6)                                                                 |
| **Die Aufnahmeordnung selbst** (→ 6.5, 6.6)                                                                     | **Gesamtplenum**, Zustimmung der Hauskammer für die Teile, die nur das Haupthaus betreffen                       |
| **Handeln:** Objektkauf, Kreditaufnahme, Finanzrahmen, Kapitalstock (→ 4.6), Instandhaltung, Sanierung, Umbau   | **Hauskammer und Nachbarschaftskammer**, je mit eigener Mehrheit (Zustimmungsvorbehalt, siehe unten)             |
| **Entnahme aus dem Kapitalstock** (→ 4.6)                                                                       | **Gesamtplenum** legt die Entnahmeregel fest, das **Hausplenum** entscheidet über die Verwendung                 |
| **Bewahren:** Vereinszweck, Verkaufsschutz (→ 9.1), Reprivatisierung, Rechtsform, Auflösung, Gemeinnützigkeit   | **alle drei Kammern müssen zustimmen**                                                                           |
| **Aufnahme ins Einzugsgebiet und in den Trägerkreis**                                                           | **Gesamtplenum**                                                                                                 |
| **Awareness, Konfliktverfahren, Schutzkonzept**                                                                 | **Gesamtplenum**, Veto der Hauskammer bei Regeln, die nur im Haupthaus gelten                                    |
| **Programm, Bildung, Veranstaltungen, Fördermittel, Vernetzung**                                                | **Trägerkammer** im Community-Verein (→ 3.5), Veto der Hauskammer bei Adresse, Sichtbarkeit, Raumnutzung (→ 7.7) |

Satzungsänderungen folgen dem Gegenstand: Was das Handeln betrifft, wird wie Handeln beschlossen, was den Zweck betrifft, wie Bewahren.

**Warum das Handeln eng und das Bewahren breit ist.** Beim Handeln entstehen Schulden, Bauzeiten und Wohnrisiko, und die trägt, wer dort wohnt oder in Geh- und Radweite gebunden ist. Beim Bewahren ist es umgekehrt: Je mehr Menschen einen Verkauf verhindern können, desto sicherer ist das Haus. Das ist die Logik von 9.1. **Zustimmung ist dabei keine Gestaltungsmacht:** Die Trägerkammer kann den Ausverkauf verhindern, aber nichts erzwingen.

**Der billigste Teil dieses Schutzes steht schon im Gesetz.** Steht „das Haus dauerhaft dem Markt entziehen" im **Vereinszweck** und nicht nur in der Charta, braucht seine Änderung nach **§ 33 Abs. 1 Satz 2 BGB** die Zustimmung aller Mitglieder, sonstige Satzungsänderungen drei Viertel (§ 33 Abs. 1 Satz 1 BGB). Wichtig: § 33 ist über **§ 40 BGB** abdingbar, die Satzung darf also nicht versehentlich davon abweichen. Dazu kommt das Vetorecht der Syndikats-GmbH auf der Eigentumsebene (→ 3.3). Der Verkaufsschutz ruht damit auf drei Säulen und nicht auf einer Abstimmungsregel.

**Wie das rechtlich funktioniert.** Mitglied im Hausverein sind nur die Bewohner:innen (→ 3.3). Die Mitentscheidung der Nachbarschaftskammer läuft deshalb nicht über die Mitgliederversammlung, sondern über einen **Zustimmungsvorbehalt** in der Satzung des Hausvereins: Ein Beschluss zum Handeln wird erst wirksam, wenn die Nachbarschaftskammer zugestimmt hat. Für das Bewahren gilt derselbe Mechanismus zugunsten aller drei Kammern.

**Der Preis dieser Konstruktion, offen benannt.** Ein Zustimmungsvorbehalt ist ein Veto, keine Gestaltungsmacht. Die Nachbarschaftskammer kann einen Objektkauf verhindern, aber keinen anstoßen. Die Formel _je mit eigener Mehrheit_ beschreibt also die politische Absicht genau, die rechtliche Wirkung nur ungefähr. Ausgeglichen wird das durch das Antragsrecht in jedem Plenum und durch die Rechenschaftspflicht des Vorstands (→ 6.3), nicht vollständig. Die Alternative wäre, das Einzugsgebiet in den Hausverein aufzunehmen; das kollidiert mit dem Selbstverwaltungsprinzip des Syndikats, nach dem der Hausverein die Bewohner:innen abbildet (→ 3.3, 12.3, Frage 25).

**Der Umschaltpunkt.** Bis zum Einzug gibt es keine Hauskammer: In der gesamten Track-B-Phase (→ 5.3) existiert kein Haus, niemand wohnt irgendwo, und **der Trägerverein ist das Projekt**. Suchprofil, Finanzrahmen, der Objektkauf und die gesamte Bau- und Sanierungsphase fallen in diese Zeit. Solange entscheidet das **Gesamtplenum nach Köpfen**, sonst wäre die Regel leer. Erst mit dem **Erstbezug** greift die Aufteilung oben. Das heißt auch: Menschen, die jahrelang in der Kerngruppe getragen haben und dann nicht einziehen, verlieren in diesem Moment Stimmgewicht. Das ist der wunde Punkt des Modells und gehört vorher ausgesprochen, nicht wenn er eintritt. Die ehrliche Erzählung dazu ist nicht „ihr werdet herabgestuft", sondern „das Haus ist entstanden und übernimmt seine eigenen Angelegenheiten".

**Der Umschaltpunkt ist kein eigener Beschluss, und er liegt später als die Vereinsgründung.** Mit der **notariellen Beurkundung** des Kauf- oder Erbbaurechtsvertrags wird der Hausverein gegründet, weil ihm die Anteile an der Haus-GmbH gehören müssen. Die Kammeraufteilung greift aber erst mit dem **Erstbezug**, also an dem Tag, an dem die ersten Menschen tatsächlich einziehen. Der Abstand dazwischen ist beabsichtigt: Zwischen Beurkundung und Einzug fallen Umbau und Sanierung an, und in dieser Zeit gibt es weder Bewohner:innen noch ein Einzugsgebiet. Hauskammer und Nachbarschaftskammer wären leer, ausgerechnet bei den teuersten Beschlüssen des Projekts. Beide Ereignisse sind hart und liegen nicht im Ermessen der Trägerkammer, und das ist der Punkt: Vorher entscheidet das Gesamtplenum nach Köpfen, und dort hat die künftige Trägerkammer die Mehrheit. Läge der Zeitpunkt in ihrem Ermessen, beschlösse ausgerechnet sie den Moment, an dem sie Stimmgewicht abgibt, und könnte ihn beliebig aufschieben. Aus demselben Grund steht die **Satzung des Hausvereins samt Zuständigkeitsaufteilung fest, bevor die Objektsuche beginnt**, und wird nicht erst geschrieben, wenn feststeht, wer einzieht. Wer später dazukommt, tritt in eine bestehende Regel ein, statt über sie abzustimmen (→ 12.3, Frage 25).

**Kammermehrheit statt reiner Kopfzahl.** Bei Beschlüssen, die eine Kammer besonders treffen, zählt nicht nur die Gesamtmehrheit, sondern zusätzlich die Mehrheit in der betroffenen Kammer. So kann keine Gruppe eine andere überstimmen, und trotzdem verliert niemand die Stimme.

**Wenn die Kammern sich nicht einigen.** Gesamtmehrheit ja, Kammermehrheit nein: Dann ist der Beschluss nicht gefasst. Es folgt eine **Vermittlung**, moderiert von Menschen ohne eigenes Interesse an der Sache, notfalls von außen (→ 6.1). Bleibt die Einigung aus, **verfällt der Antrag**. Keine einfache Mehrheit rückt nach, und dieselbe Fassung kommt nicht wieder auf die Tagesordnung. Wer den Antrag erneut einbringen will, muss ihn verändert einbringen. Der Preis ist Stillstand im Streitfall, und der ist beabsichtigt: Er schützt davor, dass eine Kammer durch Wiedervorlage zermürbt wird.

**Eine Ausnahme braucht es dort, wo Nichtstun keine Option ist.** Bleibt ein Beschluss über die Nutzungsgebühr aus, während die Bank bedient werden muss, kostet der Verfall das Haus. Für solche Gegenstände gilt der zuletzt gefasste Beschluss fort, angepasst nach einem vorab festgelegten Index, bis eine Einigung steht. Welche Gegenstände das sind, gehört abschließend in die Geschäftsordnung.

**Bewohner:innen-Veto als Auffangregel.** Was nicht auf der Liste steht, aber das Wohnen im Haus berührt, kommt nicht gegen die Hauskammer zustande. Damit muss die Liste nicht vollständig sein, um zu funktionieren.

**Und ein zweites Veto beim Schutzkonzept.** Awareness und Schutzkonzept gehören ins Gesamtplenum, weil sie alle drei Kreise binden, dazu Gäste und Veranstaltungen. Regeln, die ausschließlich im Haupthaus gelten, etwa erweiterte Führungszeugnisse für Bewohner:innen (→ 8.3) oder Vorgaben zur Raumordnung (→ 7.6), kommen aber nicht gegen die Hauskammer zustande. Ohne diese Ausnahme beschlösse eine auswärtige Mehrheit über das Wohnen, und genau das soll die Kammeraufteilung verhindern.

**Konsent entschärft den Rest** (→ 6.1): Wer betroffen ist, erhebt einen schwerwiegenden Einwand, und der Vorschlag muss nachgebessert werden. In der Praxis greift das früher als jede Abstimmungsregel.

**Was die Trägerkammer dafür hat**, denn weniger Stimmrecht ohne Gegenstück ist genau das Szenario aus 2.2:

- **ein eigenes Ressort mit eigenem Haushalt:** Programm, Bildung, Veranstaltungen, Fördermittel und Vernetzung im Community-Verein (→ 3.5). Kein Trostpflaster, sondern der Bereich, in dem sie entscheidet und das Haus nur ein Veto hat
- **Rede- und Antragsrecht in jedem Plenum**, ohne Ausnahme, auch im Hausplenum
- **Stimme beim Bewahren, bei der Aufnahme in die eigenen Kreise und beim Awareness-Konzept**, an das sie als Gast im Haus selbst gebunden ist
- **Rechenschaft:** Der Vorstand berichtet ihr über Finanzen und Bauvorhaben, auch über die, bei denen sie nicht abstimmt. Ohne Information ist Antragsrecht wertlos
- **Ämter und AK-Mitarbeit**, ausdrücklich erwünscht
- **Zugang, Gästezimmer und Nutzung** unverändert (→ 2.1)
- **hybride Teilnahme als Standard** (→ 6.3)

**Ausgeschlossen bleibt Stimmgewicht nach Kapital.** Weder Einlage noch Direktkredit erzeugen Einfluss (→ 4.5). Ein Haus, in dem Geld mitstimmt, hätte die erste Grundentscheidung aus 1.3 aufgegeben.

**Präzisierung zu 2.1 und 3.3:** Haupthaus und Einzugsgebiet sind einander gleichgestellt, bis auf den Wohnalltag im Haus. Die Trägerkammer ist **Förderkreis mit eigenem Ressort**, nicht Mitentscheiderin über Objekt und Kredit. Wo 2.1 von gleichem Stimmrecht spricht, ist damit die Nachbarschaftskammer gemeint.

**Wo die Zuständigkeitsliste steht: in der Geschäftsordnung, nicht in der Satzung**, damit sie ohne Registergericht nachjustiert werden kann. Das hat einen Preis, der benannt gehört: Eine Geschäftsordnung ändert im Normalfall die einfache Mehrheit, und die liegt vor dem Umschaltpunkt bei der Trägerkammer, danach bei der zahlenmäßig größten Kammer. Deshalb bekommt genau diese Liste einen eigenen Änderungsschutz: **Änderungen brauchen eine qualifizierte Mehrheit im Gesamtplenum und zusätzlich die Zustimmung der Hauskammer.** Die Mehrheit in allen drei Kammern zu verlangen wäre naheliegend, aber zu scharf: Zusammen mit der Verfallsregel oben könnte eine einzige blockierende Kammer die Liste dauerhaft einfrieren. Die Hauskammer allein genügt, weil sie die kleinste ist und deshalb diejenige, die überstimmt würde. Ohne diesen Satz kann die Mehrheit, gegen die die Kammern schützen sollen, sie mit einem gewöhnlichen Beschluss wieder abräumen. Der Schutzsatz selbst gehört dagegen in die **Satzung**, sonst schützt er sich nicht selbst.

**Vier Punkte bleiben bewusst offen.** Die ersten drei gehören in die Geschäftsordnung und nicht in die Satzung, damit sie ohne Satzungsänderung nachjustiert werden können:

- **Quorum je Kammer.** Bei rund zwanzig Menschen in der Hauskammer ist Beschlussfähigkeit ein echtes Problem, sobald drei krank und zwei im Urlaub sind. Vertagt (→ 12.2).
- **Wer entscheidet über die Zuständigkeit selbst?** Ob ein Thema Handeln oder Bewahren ist, entscheidet faktisch darüber, wer abstimmt. Das ist der Punkt, an dem solche Modelle in der Praxis kippen (→ 12.2).
- **Kammerwechsel.** Wer aus dem Haupthaus ins Einzugsgebiet zieht, nach 7.4 der Regelfall nach einer Trennung: ab wann Nachbarschaftskammer? Die Frage ist heikel, weil sie das Stimmrecht in der verletzlichsten Phase verschiebt (→ 12.2).
- **Sollen Direktkreditgeber:innen beim Handeln mitstimmen?** Ein Teil der Trägerkammer wird dem Projekt fünfstellige Beträge leihen und trägt damit ein Risiko, das über den Mitgliedsbeitrag hinausgeht. **Bewusst ausgelassen**, weil jede Kopplung von Geld und Stimme gegen 1.3 und 4.5 läuft und Bewohner:innen ohne Einlage sonst schlechter stünden als Außenstehende mit. Als Zwischenform denkbar: ein **Anhörungsrecht mit Begründungspflicht**, die Hauskammer müsste eine abweichende Entscheidung also schriftlich begründen, ohne dass daraus eine Stimme wird (→ 12.2).

> **Was noch zu verankern ist.** Die Gründungssatzung des Hausvereins braucht **zwei Zustimmungsvorbehalte**: einen zugunsten der Nachbarschaftskammer für das Handeln, einen zugunsten aller drei Kammern für das Bewahren. Dazu den Änderungsschutz für die Zuständigkeitsliste. Ein Verein kann sich wirksam binden, etwas **nicht ohne Zustimmung** zu tun; ein Weisungsrecht wäre wegen der Vereinsautonomie (§ 25 BGB) deutlich schwieriger, und genau deshalb ist der Vorbehalt die rechtlich einfachere Variante. Beides gehört in die **Gründungssatzung** und nicht in eine spätere Änderung, denn nachträglich müsste ihm dieselbe Mehrheit zustimmen, die es begrenzen soll. **Vor der Gründung anwaltlich prüfen** (→ 12.3, Frage 25).

### 6.3 Das Plenum strukturell verankern

Damit Beschlüsse _bindend_ sind, braucht es formale Mindestbedingungen. Sonst ist jeder Beschluss später bestreitbar:

- **Ladung** mit Frist und Tagesordnung, schriftlich, dokumentiert
- **Beschlussfähigkeit** definiert, plus ein Verfahren für den Fall, dass das Quorum verfehlt wird
- **Protokoll** mit Beschlusstext im Wortlaut, verbindlich nach Einspruchsfrist
- **Beschlusssammlung**, durchsuchbar. Ohne sie weiß nach fünf Jahren niemand mehr, was gilt
- **Umlaufbeschlüsse** für Eiliges, mit engeren Regeln
- **Abwesende sind gebunden.** Ausdrücklich festhalten, sonst wird jedes Plenum durch Nichterscheinen entwertet
- **Hybride Teilnahme als Standard**, nicht als Ausnahme. Bei drei Kreisen die Bedingung für gleiches Stimmrecht (→ 2.2)
- **Änderungsregeln:** Was ist einfache Mehrheit, was Konsent, was qualifiziert?

### 6.4 Macht begrenzen, insbesondere Gründer:innenmacht

Der Initiator eines Projekts hat automatisch Deutungshoheit, Wissensvorsprung und Beziehungsnetz. Am Anfang nützlich, später ein Risiko: Projekte überdauern nur, wenn die Gründer:innen die Deutungshoheit **aktiv abgeben** und Generation 2 es anders machen darf. Eine Designentscheidung, keine Charakterfrage.

- **Amtszeitbegrenzung** für alle Ämter, mit Pflichtpause
- **Rotation** von Ämtern, inklusive der unattraktiven
- **Der Selbstverständnisprozess wird extern moderiert**, nicht vom Initiator
- **Wissensverteilung als Pflicht:** keine Zuständigkeit, die nur eine Person ausüben kann, ausdrücklich auch bei technischer Infrastruktur (→ A.1, A.2)
- **Befangenheitsregeln** (→ 7.8)

### 6.5 Dokumentenset

Faustregel: **In die Satzung nur, was gegen die eigene spätere Mehrheit geschützt werden muss.** Alles andere gehört in Ordnungen, die das Plenum ändern kann. Eine überladene Satzung macht das Projekt handlungsunfähig, eine zu dünne macht es angreifbar.

| Dokument                             | Rechtscharakter                   | Änderbar durch                                                                                                                         | Inhalt                                                                                                          |
| ------------------------------------ | --------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------- |
| **Satzung**                          | hart, Registergericht             | qualifizierte Mehrheit + ggf. Veto                                                                                                     | Zweck, Organe, Stimmrecht, Aufnahme, Ausschluss, Vermögensbindung, **Satz der Instandhaltungsrücklage** (→ 9.3) |
| **Gesellschaftsvertrag Haus-GmbH**   | hart, notariell                   | Einstimmigkeit beider Gesellschafter                                                                                                   | Verkaufsveto, Zweckbindung                                                                                      |
| **Nutzungsvertrag**                  | Zivilrecht, schärfstes Instrument | Vertragsparteien                                                                                                                       | Wohnrecht, Kopplung an Mitgliedschaft, Gebühr                                                                   |
| **Gemeinschaftsordnung**             | intern bindend                    | Plenum                                                                                                                                 | Alltag, Ämter, Küche, Lärm, Gäste, Tiere, Konsum, Raumordnung (→ 7.6)                                           |
| **Geschäftsordnung Plenum**          | intern bindend                    | Plenum, für die **Zuständigkeitsliste** qualifizierte Mehrheit plus Zustimmung der Hauskammer (→ 6.2)                                  | Ladung, Quorum, Konsent, Protokoll, Delegation, Zuständigkeiten (→ 6.2)                                         |
| **Aufnahmeordnung**                  | intern bindend                    | Gesamtplenum, Zustimmung der Hauskammer für die Teile, die nur das Haupthaus betreffen (→ 6.2)                                         | Mitmachphase, Probewohnen, Aufnahmekreis, Befangenheit, Vorrangfrage (→ 6.6)                                    |
| **Finanzordnung**                    | intern bindend                    | Plenum, für **Anlagerichtlinie und Entnahmeregel** qualifizierte Mehrheit (→ 4.6, 6.2), der Rücklagensatz steht in der Satzung (→ 9.3) | Einlagen, Bänder, Solidarfonds, Rücklage, Anlagerichtlinie und Entnahmeregel (→ 4.6), Auszahlung                |
| **Awareness- und Konfliktkonzept**   | intern bindend                    | Plenum                                                                                                                                 | Eskalationsleiter, Ombudsstelle, Verfahren, Konsenskultur                                                       |
| **Schutzkonzept (Kinder)**           | intern bindend, extern geprüft    | Plenum + Fachberatung                                                                                                                  | → Abschnitt 8                                                                                                   |
| **Datenschutz- und Zutrittsordnung** | intern bindend                    | Plenum                                                                                                                                 | Zutrittsrechte, Logging, Löschfristen (→ A.2)                                                                   |
| **Selbstverständnis / Charta**       | nicht justiziabel                 | Konsent                                                                                                                                | Werte, Haltung, Aufnahmefilter                                                                                  |

Die Charta ist rechtlich wertlos und praktisch das wichtigste Dokument: Sie ist das, was Menschen lesen, bevor sie sich bewerben. **Genau deshalb braucht sie eine harte Entsprechung:** Punkte, die im Ernstfall Konsequenzen haben sollen, müssen zusätzlich in der **Gemeinschaftsordnung** stehen, und diese muss **Bestandteil des Nutzungsvertrags** sein. Charta ist Haltung, Gemeinschaftsordnung ist Vertrag. Wer nur das eine hat, hat entweder keine Werte oder keine Handhabe (→ 3.7).

### 6.6 Der Aufnahmeweg, Schritt für Schritt

Das Aufnahmeverfahren stand bisher verteilt an neun Stellen: Kriterien in 3.6, Verbindlichkeitsstufen in 5.4, Stimmrecht in 6.2, das Dokument in 6.5, der Beziehungsfall in 7.1, das Probewohnen in 7.4, Befangenheit in 7.8, Altersmix in 9.2, Einzugsgebiet in 2.1. Hier stehen sie als ein Weg. Die Zahlen sind Vorschläge für die Aufnahmeordnung, nicht beschlossen.

```mermaid
flowchart LR
    K["<b>1 Kontakt</b><br/>offene Termine"] --> M["<b>2 Mitmachphase</b><br/>6 bis 12 Monate<br/><i>ohne Einzug</i>"]
    M --> C["<b>3 Charta-Gespräch</b><br/>Aufnahmekreis"]
    C --> P["<b>4 Probewohnen</b><br/>mehrere kurze Blöcke<br/><i>Gästezimmer</i>"]
    P --> E{"<b>5 Hausplenum</b><br/>Konsent"}
    E -->|"kein Einwand"| Z["<b>6 Einzug</b><br/>Mitgliedschaft<br/>+ Nutzungsvertrag"]
    E -.->|"Einwand"| A["<b>Absage</b><br/>mündlich, ohne Aktenlage"]
```

#### Die sechs Stufen

| Stufe                 | Was passiert                                                                                                                                                    | Größenordnung             |
| --------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------- |
| **1 Kontakt**         | Offene Termine, Hausführung, Charta lesen. Keine Bewerbung, keine Daten, keine Warteliste                                                                       | ein Abend                 |
| **2 Mitmachphase**    | Regelmäßig im Plenum (Rederecht, keine Stimme), Mitarbeit in einem AK, Alltagstermine, nicht nur Feste. **Kein Einzug**                                         | 6 bis 12 Monate           |
| **3 Charta-Gespräch** | Zwei bis drei Gespräche mit dem Aufnahmekreis über die unbequemen Teile: Raumordnung (→ 7.6), Awareness (→ 7.9), Eskalationsleiter (→ 3.7), Schutzkonzept (→ 8) | zwei bis drei Termine     |
| **4 Probewohnen**     | Mehrere kurze Blöcke im Gästezimmer, verteilt über Monate, mindestens einer im gewöhnlichen Alltag. Lebensmittelpunkt bleibt außerhalb                          | 3 Blöcke à 1 bis 2 Wochen |
| **5 Entscheidung**    | Der Aufnahmekreis legt eine Empfehlung vor, das **Hausplenum** entscheidet im Konsent (→ 6.1, 6.2)                                                              | ein Plenum                |
| **6 Einzug**          | Mitgliedschaft, Nutzungsvertrag mit der Gemeinschaftsordnung als Bestandteil (→ 6.5), Pat:in für das erste Jahr                                                 | ab dann dauerhaft         |

**Warum die lange Phase kein Wohnen ist.** Die eigentliche Kennenlernzeit sind die 6 bis 12 Monate der Mitmachphase, nicht das Probewohnen. Das hat einen rechtlichen Grund: **§ 575 BGB** lässt Zeitmietverträge nur bei Eigenbedarf, Abriss oder Werkswohnung zu, und fehlt der Grund, gilt der Vertrag nach § 575 Abs. 1 Satz 2 BGB als unbefristet. Ein Probewohnen, das nach zwölf Monaten automatisch endet, würde also schlicht nicht enden. Tragfähig ist der Weg über **§ 549 Abs. 2 Nr. 1 BGB**, der Wohnraum zum nur vorübergehenden Gebrauch vom Kündigungsschutz ausnimmt. Das setzt voraus, dass die Blöcke kurz sind und die Person ihre Wohnung behält. Deshalb kurze Blöcke statt eines langen. **Der Kanzlei vorlegen** (→ 12.3, Frage 25).

**Der Aufnahmekreis.** Drei bis fünf Menschen, **rotierend besetzt**, mindestens eine Person, die nicht zur Gründungsgeneration gehört (→ 6.4). Er bereitet vor, führt die Gespräche, organisiert das Probewohnen und legt eine Empfehlung vor. **Er entscheidet nicht.** Wer mit einer bewerbenden Person verbunden ist, ist befangen und tritt für diesen Fall aus dem Kreis zurück (→ 7.8). Fällt der Kreis dadurch unter drei Personen, wird er für diesen Fall ergänzt, nicht das Verfahren verkürzt.

**Die Entscheidung** fällt im Hausplenum im Konsent: aufgenommen ist, gegen wen kein schwerwiegender begründeter Einwand steht. „Begründet" heißt, dass der Einwand ausgesprochen und im Kreis besprochen wird, nicht dass er die Mehrheit überzeugen muss. Eine reine Antipathie trägt nicht, ein benanntes Sicherheitsbedenken trägt. Kommt eine Person aus einer Beziehung mit jemandem im Haus, gilt trotzdem der volle Weg, und **die betroffene Person stimmt nicht mit ab** (→ 7.1).

**Absagen sind mündlich und werden nicht dokumentiert.** Keine Gründeliste, keine Akte, kein Protokoll. Alles andere erzeugt genau den Outing- und Rechtfertigungsdruck, den 3.6 vermeiden will, und wird im Streit gegen das Haus verwendet.

**Wenn ein Platz frei wird**, gibt es keine Rangliste. Menschen aus dem Einzugsgebiet haben einen **Kennenlernvorsprung, keinen Anspruch**: Sie sind längst in der Mitmachphase und stehen dem Aufnahmekreis näher, aber sie rücken nicht automatisch nach (→ 2.1). Pflichtfrage bleibt „was fehlt dem Haus gerade", vor allem beim Altersmix. Für das Alter gibt es dazu eine **offen ausgewiesene Zielbandbreite** in der Aufnahmeordnung (→ 9.2), für die Frage aus 3.6 keine Zahl und auch keine verdeckte. Eingelegtes Kapital begründet nie einen Anspruch auf ein Zimmer (→ 4.5, 5.4).

**Der Weg ins Einzugsgebiet und in den Trägerkreis ist kürzer.** Er endet nicht in einem gemeinsamen Wohnraum, also braucht er kein Probewohnen: Kontakt, Charta, ein Gespräch, Beschluss im Gesamtplenum (→ 6.2). Das ist zugleich der übliche Einstieg. Wer ins Haupthaus will, geht in der Regel über diese Stufe.

---

# Teil III: Die unbequemen Teile

---

## 7 Beziehungen, Sexualität, Kink

> Dichte, Durchlässigkeit und Vertrauen sind das, was dieses Haus attraktiv macht. Dieselben drei Eigenschaften sind auch die Ausbreitungswege für Konflikte. Das Folgende ist keine moralische Bewertung, sondern Konstruktionslehre.

### 7.1 Das Grundprinzip

> **Queer ist der Zweck. Poly und Kink sind Kultur. Eine Beziehung ist niemals alleiniger Zugangsweg.**

Zwei Gründe, beide zwingend. **Generationenfestigkeit:** Läuft Zugehörigkeit faktisch über Beziehungen, ist das Haus in vierzig Jahren entweder leer oder eine Erbdynastie, und wer neu einzieht, ohne ins Netz verwoben zu sein, bliebe dauerhaft Gast im eigenen Zuhause. **Verfahrensintegrität:** Wer einzieht, _weil_ er mit jemandem zusammen ist, hat das Aufnahmeverfahren umgangen, und die Gruppe hat eine Entscheidung getroffen, die sie nie getroffen hat.

**Regel:** Wer mit einer Person aus dem Haus zusammenkommt, durchläuft dennoch das volle reguläre Verfahren inklusive Probewohnen. **Die betroffene Person stimmt nicht mit ab.**

### 7.2 Wer nicht mitspielt, gehört genauso dazu

Keine Höflichkeitsfloskel, sondern eine Konstruktionsanforderung: Ein Haus, in dem Poly und Kink normal sind, erzeugt automatisch einen unausgesprochenen Erwartungsdruck, den niemand je beschlossen hat. Aromantische, asexuelle und monogame queere Menschen müssen sich hier vollständig zu Hause fühlen können, ebenso Menschen, die selbst nicht spielen.

**Das steht nicht im Widerspruch zu der Erwartung aus 3.6.** Dort geht es um die **Auswahl**: Wer einzieht, sollte einen eigenen Bezug zum Thema mitbringen. Hier geht es um den **Alltag**: Wer eingezogen ist, schuldet niemandem Beteiligung. Nähe zum Thema und Lust auf eine konkrete Szene sind zwei verschiedene Dinge, und die zweite ist jederzeit widerrufbar.

- **In die Charta**, ausdrücklich und nicht als Nebensatz.
- **Keine Kultur, in der Nichtteilnahme erklärt werden muss.** Ein „nein danke" ohne Begründung ist eine vollständige Antwort.
- **Rückzugsräume, die immer neutral sind** (→ 7.6). Die Küche darf um Mitternacht nicht für manche kein Ort mehr sein.
- **Ämter und Ansehen dürfen nicht an Beteiligung hängen.** Wer die Buchhaltung macht und sonst nichts, hat dasselbe Gewicht.

### 7.3 Trennungen sind Systemereignisse, keine Privatsache

In einer gewöhnlichen WG betrifft eine Trennung zwei Menschen. In einem überlappenden Netz verschiebt sie den gesamten sozialen Graphen: Metamours, Freundschaften, Loyalitäten, wer noch mit wem am Tisch sitzt. **Die Lagerbildung nach einer schlecht verlaufenen Trennung ist der am besten dokumentierte Zerstörer von Poly-Gemeinschaften**, nicht Eifersucht im Alltag und nicht Geld.

Konsequenz für das Design: Regeln für diesen Fall müssen existieren, **solange sie abstrakt sind**. Jede Regel, die nach dem ersten Fall geschrieben wird, ist eine Parteinahme und wird auch so gelesen.

### 7.4 Verfahren: „Wer muss gehen?"

**Die Antwort lautet: niemand.** Das Wohnrecht hängt an der Mitgliedschaft, nie an einer Beziehung. Die Gruppe entscheidet nicht, wessen Beziehung wichtiger ist. Nie.

| Vorkehrung                | Was sie leistet                                                                      | Was sie voraussetzt                                                     |
| ------------------------- | ------------------------------------------------------------------------------------ | ----------------------------------------------------------------------- |
| **Umzugsrecht im Haus**   | betroffene Person hat Vorrang auf den nächsten freien Raum in einem anderen Hausteil | Räume werden _zugewiesen_, nicht besessen; mehrere getrennte Hausteile  |
| **Rotationszimmer**       | ein bis zwei Räume, die nie dauerhaft vergeben sind                                  | wird bei der Objektplanung eingepreist, nicht später gesucht            |
| **Krisenzimmer**          | kleiner Rückzugsraum für Trennung, Krankheit, Konflikt                               | dauerhaft freigehalten, Belegung durch Awareness-AK, nicht durch Plenum |
| **Auszeit-Regelung**      | befristetes Fernbleiben ohne Verlust von Mitgliedschaft und Einlage                  | Zwischenvermietungsregel, reduzierte Gebühr                             |
| **Kontaktvereinbarungen** | temporäre Absprachen: getrennte Kochtage, getrennte Räume zu bestimmten Zeiten       | ausdrücklich als _Vereinbarung_, nicht als Strafe                       |

> **Bei zwanzig Menschen im Haupthaus ist genau dieser Abschnitt der wundeste Punkt.** Ein Umzugsrecht in „einen anderen Hausteil" hat nur Substanz, wenn es andere Hausteile gibt, und ein Rotationszimmer bindet bei kleiner Gruppe anteilig mehr Fläche. Die baulichen Vorkehrungen allein reichen hier nicht.

**Deshalb ist das Einzugsgebiet aus 2.1 das eigentliche Ventil.** Ein Umzug in eine angebundene Wohnung ist nach einer Trennung die realistischste Form von Abstand: räumlich echt, sozial gesichtswahrend, und **ohne das Projekt zu verlassen**. Stimmrecht, Kapital, Ämter und Zugehörigkeit bleiben unangetastet. Zwei Voraussetzungen, vorher zu regeln:

- **Verfügbarkeit.** Mindestens eine Wohnung im Einzugsgebiet spielt dieselbe Rolle wie das Krisenzimmer im Haus: vorgehalten, nicht erst gesucht.
- **Freiwilligkeit.** Wer geht, geht **freiwillig und mit Vorrang auf Rückkehr**. Sobald die Gruppe entscheidet, _wer_ umzieht, ist der Satz „niemand muss gehen" gebrochen, nur mit mehr Schritten.

**Der einzige Fall, in dem jemand tatsächlich gehen muss, ist Gewalt oder Übergriff.** Dann greift 7.9, unabhängig von der Beziehungskonstellation.

**Realistische Erwartung an Sanktionen:** Ein Vereinsausschluss beendet in Deutschland **nicht automatisch** das Wohnrecht. Selbst bei vertraglicher Kopplung von Mitgliedschaft und Nutzungsvertrag prüfen Gerichte streng; eine Räumung dauert Jahre und kostet fünfstellig.

> **Die eigentliche Sicherung ist das Aufnahmeverfahren, nicht die Ausschlussklausel.** Eine Mitmachphase von 6 bis 12 Monaten mit anschließendem Probewohnen ist kein Misstrauen, sondern das einzige wirksame Instrument (→ 6.6).

### 7.5 Kanäle für Beziehungs- und Metamour-Konflikte

Konflikte zwischen Partner:innen von Partner:innen haben keinen natürlichen Austragungsort und werden deshalb sofort hausweit. Das braucht einen eigenen, vorab definierten Weg.

```mermaid
flowchart LR
    S1["1 · Direktes<br/>Gespräch"] --> S2["2 · Moderiert<br/>intern, unbeteiligt"]
    S2 --> S3["3 · Externe Mediation<br/>poly- und kink-kompetent"]
    S3 --> S4["4 · Schiedsstelle<br/>bindende Empfehlung"]
    S4 --> S5["5 · Ausschluss<br/>nur bei Gewalt/Übergriff"]
```

1. **Direktes Gespräch.** Erwartet, nicht erzwungen.
2. **Moderiertes Gespräch** mit einer intern benannten, _unbeteiligten_ Person. In einem dichten Netz ist „unbeteiligt" knapp, deshalb muss eine Liste geeigneter Personen vorab existieren.
3. **Externe Mediation** aus einem vorab bestimmten Pool, **zwingend poly- und kink-kompetent**. Klassisch ausgebildete Paartherapeut:innen scheitern an diesen Konstellationen regelmäßig, oft mit Schaden.
4. **Schiedsstelle** aus externen Personen mit bindender Empfehlung für _Maßnahmen im Haus_.
5. **Ausschlussverfahren**, nur bei Gewalt oder Übergriff.

> **Beziehungsthemen gehören nicht ins Plenum.** Das Plenum entscheidet über das Haus, nie über Beziehungen. Andernfalls wird jede Trennung zur Gemeinschaftsangelegenheit, die Gruppe wird zum Gericht, und ein Gericht mit Liebesbeziehungen zu beiden Parteien ist keines.

Ausnahme, eng gefasst: Wenn ein Beziehungskonflikt die _Funktionsfähigkeit des Hauses_ beeinträchtigt, entscheidet das Plenum über Raumnutzung, Ämter und Kochpläne. Niemals über die Beziehung selbst und niemals über Schuld.

**Budget einplanen.** Ein jährlicher Posten „Konfliktkosten" im Haushalt (→ 4.4) senkt die Hemmschwelle, Mediation zu nutzen. Ohne Budget wird sie erst geholt, wenn es zu spät ist.

### 7.6 Kink im gemeinsamen Raum

Dieses Haus ist ausdrücklich kink-offen. Gemeint ist damit nicht „wir haben nichts dagegen", sondern: Kink findet statt, sichtbar, im gemeinsamen Raum, und wird nicht ins Private abgeschoben. Ein Pet, das aus dem Napf gefüttert wird. Gear, Käfige und Bondage-Ausstattung, die stehen bleiben dürfen. D/s-Dynamiken, die im Alltag sichtbar sind, weil sie zum Alltag gehören. **Das ist eine Konstruktionsfrage, keine Stimmungsfrage:** Wer das ernst meint, muss es baulich und in Ordnungen lösen.

#### Räume statt Zeiten

Dasselbe Werkzeug wie beim Kinderschutz (→ 8.2): Verbote erzeugen Heimlichkeit, klare Räume erzeugen Verlässlichkeit. **Die Trennung läuft primär über Räume, nicht über Uhrzeiten.**

| Raum                        | Was gilt                                                                                                                                                                                  |
| --------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Privaträume**             | alles, was zwischen den Beteiligten vereinbart ist                                                                                                                                        |
| **Ausgewiesene Play-Räume** | Play, Gear, Szenen jederzeit. Wer eintritt, weiß, worauf                                                                                                                                  |
| **Play-Wohnzimmer**         | vollwertiger Wohnraum, in dem Play selbstverständlich dazugehört. Kein Sonderraum, sondern das eine der beiden Wohnzimmer. Ansprache, Protokolle, Halsbänder, Aufgaben, Fütterung ohnehin |
| **Nicht-Play-Wohnzimmer**   | grundsätzlich neutral. Play nur, wenn alle Anwesenden ausdrücklich einverstanden sind, und ein einziges Nein genügt                                                                       |
| **Cozy-Rückzugsraum**       | **hier wird nie gespielt.** Keine Aushandlung, keine Ausnahme, auch nicht bei Einigkeit aller Anwesenden                                                                                  |
| **Veranstaltungsraum**      | nach Format. Wer einlädt, sagt vorher, was für ein Abend es ist                                                                                                                           |

Verlässlichkeit muss in beide Richtungen gelten: Wer Kink lebt, muss wissen, wo er nicht erklären muss; wer gerade keine Lust darauf hat, muss wissen, wo er in Ruhe einen Tee trinken kann. **Der Cozy-Rückzugsraum ist deshalb keine Nettigkeit, sondern die Bedingung dafür, dass der Rest funktioniert.** Ohne ihn wird aus räumlicher Trennung ein Zwang zur Teilnahme.

Feste Schutzzeiten statt Schutzräume wären der falsche Weg: Sie machen Kink zur geduldeten Ausnahme im eigenen Haus, und ein Raum sagt sofort, was gilt, während ein Zeitplan nachgeschlagen werden muss. Zeitliche Ausnahmen gibt es trotzdem, aber als **Ausnahme mit Anlass**: angekündigter Besuch, Familie, Handwerker, Formate mit externem Publikum. Angekündigt, terminiert, begründet, nicht als Dauerregel.

Zwei Bedingungen, ohne die das Modell nicht trägt:

1. **Es wird vorher gesagt, deutlich und früh.** Vor dem Einzug, vor dem Beitritt zum Trägerkreis, vor jeder Einladung. Wer sich überrumpelt fühlt, wurde schlecht informiert, und das ist ein Fehler des Hauses und nicht des Menschen.
2. **Es gibt immer einen Weg, aus dem Weg zu gehen.** Der Cozy-Raum und das Nicht-Play-Wohnzimmer sind genau dafür da. Wer gerade nicht möchte, muss nicht diskutieren, sondern kann in einen anderen Raum gehen.

#### Der Konsens Dritter, die eigentliche Spannung

Konsens zwischen den Beteiligten ist der einfache Teil. Der schwierige ist, dass Anwesende Teil einer Szene werden, ohne zugestimmt zu haben. Eine saubere Lösung gibt es nicht, nur eine Balance:

- **Ein Unwohlsein von Mitbewohner:innen ist keine Kink-Shaming-Anklage.** Es darf geäußert werden, ohne dass daraus ein Vorwurf gegen jemandes Sexualität wird.
- **Ein einzelnes Unwohlsein ist umgekehrt kein Veto über die Kultur des Hauses.** Wer hier einzieht, weiß, worauf. Die Grundausrichtung wird nicht bei jedem Einzug neu verhandelt.
- **Der Ausgleich läuft über die Räume, nicht über den Einzelfall.** Wenn es an jedem Abend Aushandlung braucht, ist die Raumaufteilung falsch, nicht der Mensch.
- **Wiederholtes Unwohlsein ist ein Prüfauftrag, kein Urteil.** Es löst eine Überprüfung der Raumordnung aus, nicht eine Debatte über die Person, die es geäußert hat.
- **Das gehört in die Gemeinschaftsordnung** (→ 6.5), damit es besprechbar ist, ohne persönlich zu werden.

#### Wenn in einer Szene der Konsens gebrochen wird

Missachtetes Safeword, überschrittenes Limit, eine Zustimmung, die keine war: Das ist ein Übergriff und läuft über **7.9**, wie jeder andere auch. Nicht kink-intern, nicht unter Beteiligten, nicht „die wissen schon, was sie tun", denn genau diese Erwartung ist das Muster, an dem Communities scheitern: Sie schützt die Erfahrenen und lässt die Unerfahrenen allein.

Umgekehrt gilt genauso: **Der Awareness-AK braucht mindestens eine Person mit Kink-Kompetenz** (→ 7.9, 14.4). Sonst wird jede Szene, die von außen erschreckend aussieht, zum Verdachtsfall, und dann ist die Struktur, die schützen soll, selbst das Problem.

#### Gäste und der Trägerkreis

Mit Gästezimmern, offenen Formaten und einem Kreis, der regelmäßig kommt, ist die Grenze der informierten Einwilligung nicht mehr selbstverständlich.

- **Wer eingeladen wird, erfährt vorher, was für ein Haus das ist.** Nicht als Warnung, sondern als Information, und in der Einladung statt in einem peinlichen Gespräch an der Tür.
- **Offene Formate haben eine angekündigte Ausrichtung.** Ein Kochabend ist ein Kochabend.
- **Keine Fotos, keine Aufnahmen, keine Social-Media-Posts** ohne ausdrückliche Zustimmung aller Erkennbaren. Bei diesem Profil kein Höflichkeitsthema, sondern ein Outing-Risiko mit beruflichen und familiären Folgen.

#### Macht: D/s-Dynamiken und Hausgremien

> **Ausgehandelte Machtdynamiken enden an der Tür des Plenums.** Jedes Mitglied stimmt für sich. Das ist nicht verhandelbar, auch nicht durch eine Absprache zwischen den Beteiligten.

- **Befangenheit gilt für D/s-Dynamiken wie für Beziehungen** (→ 7.8). Wer einer Person im Alltag unterstellt ist, stimmt nicht über deren Aufnahme, Amt oder Raumvergabe ab.
- **Kein Gremium mehrheitlich aus einer Dynamik.** Sonst sieht nach außen ein Vorstand aus, was nach innen eine Entscheidung ist.
- **Der Zugang zur Awareness-Struktur ist unabbedingbar.** Niemand kann wirksam vereinbaren, sich nicht an den Awareness-AK oder die externe Ombudsstelle zu wenden.
- **Vereinbarungen zwischen zwei Menschen binden Dritte nicht.**

#### Was das für das Objekt heißt

Direkt in das Suchprofil (→ 10.4):

- **Zwei Wohnzimmer statt einem, plus ein kleiner Rückzugsraum.** Die Kernanforderung aus diesem Abschnitt, im Raumprogramm und nicht auf der Wunschliste (→ 4.1, 10.4)
- **Schallschutz**, in beide Richtungen, zwischen Hausteilen und nach außen
- **Mindestens ein Raum mit tragfähiger Deckenkonstruktion** für Suspension und Rigging. Eine statische Frage, die zum Bauantrag gehört und nicht zur Heimwerkerei
- **Abschließbarer Lagerraum** für Gear
- **Sanitär in der Nähe der ausgewiesenen Räume**
- **Nicht einsehbar von außen**, siehe unten
- **Getrennte Hausteile**, die dieselbe Anforderung erfüllen wie in 8.2

#### Rechtlich, kurz

Unter Erwachsenen in privaten Räumen ist das unproblematisch. Drei Grenzen:

- **Einsehbarkeit von außen.** Was von der Straße oder vom Nachbargrundstück sichtbar ist, kann als Erregung öffentlichen Ärgernisses gewertet werden. Sichtschutz ist deshalb Bauplanung, kein Schamthema.
- **Veranstaltungen mit Eintritt oder offener Ankündigung** können gewerbe-, ordnungs- und baurechtlich relevant werden.
- **Minderjährige.** Die harte Regel aus 8.4 gilt absolut und ohne Kontextualisierung. Ob Kink und Kinder im selben Haus zusammengehen, ist Gegenstand von 8.0.

### 7.7 Nach außen: Sichtbarkeit und Diskretion

Das Profil dieses Hauses ist nach innen der Sinn der Sache und nach außen ein Angriffspunkt. Beides ist wahr, und die Gruppe muss dazu bewusst entscheiden.

| Gegenüber                          | Was sinnvoll ist                                                                                                                         |
| ---------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------- |
| **Menschen, die einziehen wollen** | vollständige Offenheit, so früh wie möglich. Alles andere ist eine Falle für beide Seiten                                                |
| **Bank, Behörde, Konzeptvergabe**  | Wohnprojekt mit queerem Zweck und Sozialkonzept. Wie das Haus intern lebt, ist Sache des Hausvereins                                     |
| **Nachbarschaft**                  | freundlich, unaufdringlich, verlässlich. Gute Nachbarschaft ist bei diesem Profil eine Sicherheitsmaßnahme                               |
| **Presse und Öffentlichkeit**      | bewusst entscheiden (→ 12.2). Ein öffentlich auffindbares queeres Projekt ist politisch wirksam und erhöht das Risiko aus Register-Nr. 4 |
| **Mietshäuser Syndikat**           | ehrlich. Das Modell ist links und selbstorganisiert, dort ist das kein Problem                                                           |

Das ist keine Aufforderung zum Versteckspiel, sondern die Unterscheidung zwischen _sich nicht schämen_ und _alles überall erzählen_. Wer beides verwechselt, gefährdet die Menschen im Haus, die andere Berufe, andere Familien und andere Risiken haben.

### 7.8 Macht und Intimität: Befangenheit

Formale Macht und intime Beziehungen im selben Personenkreis erzeugen Abhängigkeiten, die niemand beschlossen hat. Unvermeidbar, aber sichtbar und begrenzt zu halten.

- **Befangenheit bei Personalentscheidungen.** Wer mit einer Person liiert ist oder war, oder in einer laufenden Machtdynamik mit ihr steht, stimmt nicht über deren Aufnahme, Ausschluss, Raumvergabe oder Amtsbesetzung ab.
- **Offenlegungspflicht für Amtsträger:innen**, und zwar nicht der Beziehungen, sondern der _Befangenheit_ im konkreten Fall. Das schützt Privatsphäre und Verfahren zugleich.
- **Kein Vorstand mehrheitlich aus einem Beziehungscluster.**
- **Amtszeitbegrenzung**, insbesondere für den Initiator.
- **Quorum-Problem beachten:** In dichten Netzen kann konsequente Befangenheit die Beschlussfähigkeit gefährden. Deshalb ein Ersatzverfahren: Der **Aufnahmekreis** aus 6.6 ist rotierend besetzt und wird bei Befangenheit ergänzt, nicht verkleinert.

### 7.9 Awareness, Konsens und Übergriffe

Ein Awareness-Konzept ist bei einem sexuell offenen Zusammenleben nicht optional. Es braucht mindestens:

- **Awareness-AK** mit geschulten Menschen, rotierend besetzt
- **Externe Ombuds- oder Vertrauensstelle außerhalb der Gruppe**, unverzichtbar, weil intern in einem dichten Netz niemand wirklich unbeteiligt ist
- **Kink-Kompetenz in beiden.** Ohne sie wird entweder jede Dynamik pathologisiert oder jede Grenzverletzung als „war doch eine Szene" abgetan. Beide Fehler sind schwer und beide sind häufig
- **Definiertes Verfahren bei Übergriffen**, schriftlich, vor dem ersten Fall
- **Sofortmaßnahmen** wie räumliche Trennung und temporäres Fernbleiben, unabhängig von der späteren Aufklärung
- **Konsenskultur explizit machen**, auch für scheinbar Kleines: Berührung, Nacktheit, Fotos, gemeinsame Räume, Türen, Zutritt

**Ein ungelöster Konflikt, der vorab entschieden werden muss:** In queeren und linken Kontexten ist **Definitionsmacht** der betroffenen Person ein verbreitetes Prinzip. In einem Wohnprojekt kollidiert es hart mit den Folgen, denn hier bedeutet ein Ausschluss den Verlust von Zuhause _und_ eingebrachtem Kapital. Reine Definitionsmacht und rechtsstaatliche Verfahrensgarantien lassen sich in dieser Situation nicht beide vollständig haben.

Die Spannung muss **vor der ersten Krise** entschieden werden, sonst entscheidet sie sich im Affekt und beide Seiten erleben das Ergebnis als Verrat. Ein gangbarer Mittelweg: Definitionsmacht gilt uneingeschränkt für **Sofortschutz**, also Glauben, Schutzmaßnahmen, räumliche Trennung und keine Rechtfertigungspflicht. **Existenzielle Maßnahmen** wie Ausschluss und Kündigung sind an ein Verfahren mit externer Beteiligung und Anhörung gebunden. Das gehört in die offenen Fragen (→ 12.2).

---

## 8 Kinder und Schutzkonzept

> Kinder kommen in Projekten dieser Größe fast immer, geplant oder nicht. Ein Haus, das erst reagiert, wenn das erste Kind da ist, trifft alle Grundsatzentscheidungen unter dem Druck konkreter Personen. Das geht schlecht aus.

### 8.0 Die Vorfrage: Wohnen Kinder dauerhaft im Haupthaus?

**Diese Entscheidung ist offen** und muss vor der Objektsuche fallen, weil sie eine Objektanforderung ist. Bis dahin ist der Rest dieses Abschnitts in der Fassung von **Variante A** geschrieben. Die Frage lautet nicht „Kinder ja oder nein", sondern: _Wo_ wohnen Kinder, und was folgt daraus für Haus, Kultur und Suche.

Zwei Dinge verschieben die Abwägung gegenüber anderen Wohnprojekten:

1. **Das Einzugsgebiet existiert ohnehin** (→ 2.1). Variante B kostet deshalb keinen zusätzlichen Suchauftrag, sondern nur eine Zweckbindung für einen Teil der Wohnungen.
2. **Die Kink-Offenheit aus 7.6 macht Variante A deutlich anspruchsvoller.** „Gemeinschaftsräume sind zu verlässlichen Zeiten kindersicher" ist eine Zeitfrage, ein Käfig im Wohnzimmer eine Raumfrage, und Räume lassen sich nicht stündlich umwidmen. Wer Variante A will, muss die Sphärentrennung baulich lösen und nicht über den Kalender.

|                                         | **A: Kinder im Haus**                                                                           | **B: Haupthaus kinderfrei, Familien im Einzugsgebiet**          | **C: vollständig kinderfrei**                                                                                                                     |
| --------------------------------------- | ----------------------------------------------------------------------------------------------- | --------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Schutzkonzept**                       | voll, alle 9 Bausteine (→ 8.3)                                                                  | voll für das Einzugsgebiet, schlank fürs Haupthaus              | schlank, nur Besuchskinder                                                                                                                        |
| **Objektanforderung**                   | Familienbereich mit eigenem Treppenhaus, Gästezimmer getrennt, **Kink-Zonen baulich abgesetzt** | Haupthaus frei planbar, dafür **Wohnungen in Reichweite nötig** | Haupthaus frei planbar                                                                                                                            |
| **Objektverfügbarkeit**                 | **deutlich eingeschränkt**, die härteste Zusatzanforderung im ganzen Dokument                   | gut, weil das Einzugsgebiet ohnehin existiert                   | am besten                                                                                                                                         |
| **Kink-Kultur im Haupthaus**            | dauerhaft eingeschränkt und ständig auszuhandeln                                                | **unverändert offen**                                           | unverändert offen                                                                                                                                 |
| **Standortlogik**                       | Schule, Kita und Spielraum werden Standortkriterien                                             | Schulfrage betrifft nur das Einzugsgebiet                       | Standort völlig frei (→ 4.3)                                                                                                                      |
| **Kultur im Haupthaus**                 | dauerhafte Sphärentrennung, zeitlich und räumlich                                               | Haupthaus braucht kaum Kompromisse                              | keine Kompromisse                                                                                                                                 |
| **Wenn jemand später ein Kind bekommt** | kein Problem                                                                                    | **Umzug ins Einzugsgebiet**, Mitgliedschaft bleibt voll         | **Kein Kündigungsgrund** (→ 3.7). Wirkt nur über die Aufnahme und über einen freiwilligen Umzug                                                   |
| **Generationenerneuerung**              | teilweise natürlich                                                                             | teilweise natürlich                                             | **nahezu null.** Ein Kind kann trotzdem entstehen, siehe Kasten unter der Tabelle. Planbar ist der Altersmix nur über die Aufnahmeordnung (→ 9.2) |
| **Recht**                               | § 72a, § 8a, Aufsichtspflicht, Sorgerechtsfragen voll relevant (→ 8.6)                          | im Haupthaus stark reduziert                                    | nur bei Veranstaltungen mit Minderjährigen                                                                                                        |
| **Förderung**                           | Wohnraumförderung ist familienfreundlich gewichtet                                              | teils                                                           | tendenziell schlechtere Ausgangslage                                                                                                              |
| **Schwierigster Punkt**                 | Sphärentrennung muss im Alltag wirklich halten, nicht nur auf dem Papier                        | das Einzugsgebiet darf keine zweite Klasse werden               | ein Aufnahmekriterium, das nach dem Einzug nicht mehr durchsetzbar ist                                                                            |

> **Variante C ist schwächer, als sie klingt.** Ein Nutzungsvertrag lässt sich wegen einer Schwangerschaft nicht kündigen; die Kündigungsgründe aus 3.7 sind abschließend und meinen Vertragsverletzungen, nicht Lebensentscheidungen. Wer C wählt, wählt also ein Kriterium für die **Aufnahme** und eine Erwartung, die im Konfliktfall nur trägt, wenn die betroffene Person freiwillig ins Einzugsgebiet wechselt. Das ist keine Kleinigkeit: Es heißt, dass C genau in dem Moment nachgibt, für den es gemacht wurde. Wer damit nicht leben will, muss A oder B nehmen. **Für Variante B gilt derselbe Vorbehalt, nur schwächer:** Auch dort ist der Umzug ins Einzugsgebiet keine Rechtsfolge, sondern eine Erwartung, die im Konfliktfall von der Freiwilligkeit lebt (→ 7.4).

**In allen drei Varianten gleich:** die harte Regel aus 8.4, wortgleich. Ein Schutzkonzept für Besuchskinder, also Enkel, Nichten und Kinder von Gästen, braucht es immer, nur in unterschiedlichem Umfang, ebenso erweiterte Führungszeugnisse bei Veranstaltungen mit Minderjährigen und die Anbindung an eine Fachberatungsstelle (→ 14.4).

**Was Variante B zusätzlich klären muss** (→ 12.2): die **Reichweite** (fußläufig oder 15 Minuten mit dem Rad entscheidet, ob es Alltag ist oder Besuch), das **Eigentum** (nur Wohnungen der Haus-GmbH sind gegen den Markt gesichert), die **Vollwertigkeit** (gleiches Stimmrecht ist die einfache Hälfte, gleiche _Anwesenheit_ die schwere, → 2.2), **Beziehungen über die Grenze hinweg** (die Vorkehrungen aus 7.4 greifen dann nur halb) und die **Kosten**, denn Wohnungen im Einzugsgebiet sind zusätzliche Fläche, nicht umgewidmete.

> **Nicht offenlassen.** Die Variante, die niemand wählt und die trotzdem am häufigsten eintritt, ist „wir entscheiden das, wenn es soweit ist". Dann entscheidet die erste Schwangerschaft, unter dem Druck konkreter Personen und mit einem konkreten Menschen als Streitgegenstand.

**Wie man es entscheidet:** nicht durch Abstimmung im luftleeren Raum. Die Frage gehört ins Auftaktwochenende (→ 13), und der Zwischenschritt liefert Empirie: wie die Gruppe Besuchskinder im Alltag erlebt, und wie ehrlich die Sphärentrennung hält, wenn niemand zusieht (→ 5.2).

### 8.1 Das Spannungsfeld, ehrlich benannt

Ein queeres, poly-affirmatives und kink-offenes Haus mit Veranstaltungen, Gästen und möglicherweise Substanzkonsum ist ein Ort, an dem Erwachsene bewusst wenige Grenzen setzen. Kinder brauchen das Gegenteil: verlässliche, vorhersagbare Grenzen und ein Zuhause, das nicht gleichzeitig Veranstaltungsort ist.

Beides ist vereinbar, aber nur **konstruktiv**, nicht durch Haltung. Die Lösung ist nicht, dass Erwachsene weniger leben. Sie ist, dass **Sphären räumlich getrennt** sind. Zeitliche Regeln kommen ergänzend dazu, tragen die Last aber nicht: Ein Raum sagt sofort, was gilt, ein Kalender muss nachgeschlagen werden (→ 7.6, 8.0).

Und eine unbequeme Feststellung, die dazugehört: **Gemeinschaften mit hohem Vertrauen, durchlässigen Grenzen und einem Selbstbild der Befreitheit sind für Täter:innen strukturell attraktiv.** Gerade weil dort Misstrauen als Verrat an den eigenen Werten gilt und Grenzsetzung schnell als Verklemmtheit gelesen wird. Die historischen Beispiele aus Reformpädagogik und alternativen Projekten sind zahlreich und gut dokumentiert.

Das ist ausdrücklich **keine** Aussage über queere oder poly lebende Menschen und keine über Kink. Das Risiko entsteht aus **strukturellen Eigenschaften**: Vertrauen, Informalität, das Tabu des Verdachts. Genau deshalb lässt es sich strukturell adressieren. Und genau deshalb muss man es aussprechen: Ein Projekt, das diese Frage als Unterstellung zurückweist, hat den ersten Schutzmechanismus bereits verloren.

### 8.2 Räumliche und zeitliche Trennung

Das ist die tragende Maßnahme, und sie ist eine **Objektanforderung**. Sie muss bei der Suche berücksichtigt werden, nicht nachträglich improvisiert.

- **Familienbereich als eigener Hausteil**, idealerweise mit eigenem Treppenhaus. Kein Durchgangsverkehr an Kinderzimmern vorbei.
- **Kink-Zonen und Veranstaltungsraum baulich abgesetzt**, mit separatem Zugang, möglichst eigenem Eingang. Wer zur Party kommt, betritt nicht den Wohnbereich der Kinder.
- **Gästezimmer nicht im Familienbereich.** Gäste sind die am wenigsten geprüfte Personengruppe im Haus.
- **Verlässliche Zeiten, aber nur ergänzend** (→ 7.6, 8.0). Gemeinschaftsräume sind zu definierten, vorhersagbaren Zeiten kindersicher, und das ersetzt die bauliche Trennung nicht. Nicht „meistens", sondern verlässlich und im Voraus einsehbar.
- **Immer mindestens eine nüchterne, verantwortliche erwachsene Person** im Haus, wenn Kinder da sind. Namentlich benannt, rotierend, kein Zufallsprinzip.

### 8.3 Das Schutzkonzept

Ein Schutzkonzept ist ein etabliertes Instrument mit erprobter Struktur. Die Elemente orientieren sich am Standard der Unabhängigen Beauftragten für Fragen des sexuellen Kindesmissbrauchs und sollten **mit einer Fachberatungsstelle** erarbeitet werden, nicht allein.

| #   | Baustein                     | Konkret für dieses Projekt                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| --- | ---------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 1   | **Risikoanalyse**            | Wo genau entstehen bei _uns_ Risiken? Viele Erwachsene mit Zugang, Gästezimmer, Übernachtungen, Nacktheitsnormen, sichtbare Sexualkultur, Feste, wechselnde Bezugspersonen, hohe Vertrauensvermutung                                                                                                                                                                                                                                                                               |
| 2   | **Verhaltenskodex**          | Nähe und Distanz, Umgang mit Nacktheit und Kink-Sichtbarkeit im Beisein von Kindern, Fotos und Social Media, Einzelsituationen, Übernachtungen, digitale Kommunikation mit Minderjährigen                                                                                                                                                                                                                                                                                          |
| 3   | **Beschwerdeweg für Kinder** | **muss an den Eltern vorbeiführen.** In einer Kommune sind die Eltern Teil des Netzes. Externe, den Kindern bekannte Ansprechperson                                                                                                                                                                                                                                                                                                                                                |
| 4   | **Externe Fachberatung**     | feste Anbindung an eine Fachberatungsstelle gegen sexualisierte Gewalt, in Köln etwa [**Zartbitter e. V.**](https://zartbitter.de/category/themen/schutzkonzepte/)                                                                                                                                                                                                                                                                                                                 |
| 5   | **Interventionsplan**        | Schritt für Schritt bei Verdacht: wer wird wann informiert, ab wann extern, Dokumentation, **keine eigenmächtige Aufklärung**                                                                                                                                                                                                                                                                                                                                                      |
| 6   | **Aufnahmeverfahren**        | **erweitertes Führungszeugnis für alle Erwachsenen im Haus**, sobald Kinder dort leben, regelmäßig erneuert. Billig, wirksam, starkes Signal                                                                                                                                                                                                                                                                                                                                       |
| 7   | **Partizipation der Kinder** | Kinderplenum mit echten Entscheidungen. **Wichtig, und gegen die verbreitete Intuition:** Fachstellen wie Zartbitter warnen ausdrücklich vor „Nein-Sage-Trainings", weil sie die Verantwortung auf das Kind verschieben und im Ernstfall zusätzlich Scham erzeugen. Schutz entsteht nicht dadurch, dass Kinder Nein sagen lernen, sondern dadurch, dass **Erwachsene Grenzen setzen, Kinder ernst genommen und geglaubt werden** und es einen Beschwerdeweg gibt, der funktioniert |
| 8   | **Fortbildung**              | verpflichtend bei Einzug, regelmäßig aufgefrischt                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| 9   | **Überprüfung**              | das Konzept wird jährlich überprüft und angepasst                                                                                                                                                                                                                                                                                                                                                                                                                                  |

### 8.4 Die harte Regel

> **Zwischen Erwachsenen im Haus und Minderjährigen findet kein romantischer oder sexueller Kontakt statt. Ausnahmslos, unabhängig vom gesetzlichen Schutzalter, unabhängig von der Konstellation. Verstoß bedeutet sofortige Trennung und Einschaltung externer Stellen.**

Diese Hausregel ist **strenger als das Strafrecht**, und das ist Absicht. Sie ist nicht verhandelbar, sie wird nicht kontextualisiert, und sie steht in der Charta, nicht im Kleingedruckten. Wer damit ein Problem hat, ist damit selbst das Ausschlusskriterium.

### 8.5 Jugendliche, der schwierigste Fall

13- bis 18-Jährige wachsen in einem Haus auf, in dem Sexualität und Beziehungsvielfalt sichtbar und normalisiert sind, während sie gerade ihre eigene entwickeln. Das kann außerordentlich befreiend sein und außerordentlich übergriffig, wenn es schlecht gemacht wird.

- **Sehr starke Privatsphäre:** abschließbare Zimmer, unbedingtes Anklopfen, kein Zugriff auf ihre Räume ohne Einverständnis
- **Das Recht, uninteressiert zu sein.** Kein Erwartungsdruck, an der Kultur des Hauses teilzunehmen, sich zu positionieren oder sich zu outen
- **Erwachsene sind keine Peers.** Sie ersetzen weder Gleichaltrige, noch werden sie Vertraute in Fragen, die zu Gleichaltrigen oder externen Fachpersonen gehören
- **Externe Ansprechperson** außerhalb des Hauses, die sie selbst kennen und erreichen
- **Anschluss nach außen aktiv fördern:** Schule, Sport, Freundeskreise ohne Bezug zum Haus. Jugendliche, deren gesamte soziale Welt im Haus liegt, sind strukturell abhängig

### 8.6 Rechtliche Punkte

- **§ 72a SGB VIII.** Bei Tätigkeiten mit Minderjährigen, auch ehrenamtlich und auch bei Veranstaltungen des Vereins, sind erweiterte Führungszeugnisse vorgeschrieben.
- **§ 8a SGB VIII.** Schutzauftrag bei Kindeswohlgefährdung. Auch wenn ihr formal kein Träger der Jugendhilfe seid: Die Struktur zu übernehmen ist schützend und wird von Fördergebern und Behörden erwartet.
- **Sorgerecht in Poly-Konstellationen.** Das deutsche Recht kennt **nur zwei rechtliche Elternteile**. Soziale Elternschaft weiterer Personen ist rechtlich weitgehend ungeschützt: keine Vertretungsbefugnis, keine Auskunftsrechte bei Ärzt:innen oder Schule, kein Erbrecht. Teilweise abfederbar über **Sorgerechtsvollmacht**, **Umgangsvereinbarung**, **Vormundbenennung im Testament** und **Notfallvollmacht**. Ein Lichtblick: **§ 1685 Abs. 2 BGB** gibt engen Bezugspersonen, die tatsächlich Verantwortung für das Kind getragen haben, ein **eigenes Umgangsrecht**. Ein Wohnprojekt ist für den Nachweis einer sozial-familiären Beziehung fast der Musterfall. **Das gehört früh zu einer Fachanwält:in für Familienrecht**, nicht in den Konfliktfall.
- **Aufsichtspflicht** in Gemeinschaftsräumen: klären, wer sie wann hat, und schriftlich festhalten. Im Schadensfall ist „das machen wir alle zusammen" keine Antwort.
- **Versicherung:** Betriebshaftpflicht des Vereins, Veranstaltungshaftpflicht, und die Frage, was bei Gästen und bei Veranstaltungen überhaupt gedeckt ist.

### 8.7 Exkurs: Verantwortungsgemeinschaft

Die geplante **Verantwortungsgemeinschaft** (Eckpunkte des Bundesjustizministeriums, 2024) sollte es zwei bis sechs Menschen ermöglichen, füreinander rechtlich einzustehen, ohne Paarbeziehung und ohne Ehe, modular aufgebaut mit Stufen für Auskunft und Vertretung in Gesundheitsfragen, Fürsorge und Pflege, Notvertretung und Zusammenleben.

> **Es gibt dieses Rechtsinstitut nicht.** Über die **Eckpunkte vom 2. Februar 2024** ist das Vorhaben nicht hinausgekommen: kein Referentenentwurf, kein Gesetz. Nachgeprüft am **26. August 2026** an drei unabhängigen Stellen: Im **BGB** kommt der Begriff im gesamten Inhaltsverzeichnis nicht vor, in der **amtlichen Gesetzessammlung des Bundes** existiert keine Norm dieses Namens, und die Änderungsdatenbank buzer.de, die den Bundesrechtsbestand seit 2006 tagaktuell führt, meldet ebenfalls keinen Treffer. Ein laufendes Gesetzgebungsverfahren war nicht auffindbar; die greifbaren Fachbeiträge beziehen sich sämtlich noch auf die Eckpunkte von 2024. **Plant nicht damit.** Der folgende Abschnitt beschreibt also einen Entwurf, keine geltende Rechtslage; er steht hier, weil das Vorhaben jederzeit wieder aufgegriffen werden kann und die Eckpunkte dann vermutlich die Grundlage bleiben. Prüft den Stand vor jeder Planung neu.

| Löst das Problem                                                         | Löst es nicht                                                          |
| ------------------------------------------------------------------------ | ---------------------------------------------------------------------- |
| Gesundheits- und Notvertretung **zwischen Erwachsenen**                  | **Abstammung und Sorgerecht.** Die Zwei-Eltern-Grenze bleibt unberührt |
| Auskunftsrechte, Fürsorge- und Pflegekonstellationen, gemeinsames Wohnen | Erbrecht, Steuerrecht, Unterhalt, ausdrücklich ausgenommen             |
| Rechtliche Anerkennung von Wahlfamilie jenseits von Paar und Ehe         | die Absicherung sozialer Eltern gegenüber dem Kind                     |

**Kurz:** Für die Kinderfrage ist sie nicht das gesuchte Werkzeug. Dafür wäre die Reform des **Abstammungsrechts** einschlägig, die ebenfalls über Eckpunkte nicht hinausgekommen ist. Für **Erwachsene untereinander** ist sie dagegen ziemlich genau das, was ein Haus wie dieses braucht: Krankenhaus, Intensivstation, Pflegeentscheidungen, Auskunft.

**Und bis dahin, der Punkt, der sofort umsetzbar ist:** **Vorsorgevollmacht, Patientenverfügung und Betreuungsverfügung** leisten zwischen Erwachsenen heute schon fast dasselbe. Sie kosten wenig, wirken sofort und sind frei wählbar, auch zugunsten von Metamours und Wahlfamilie. **Das sollte beim Einzug Standard sein**, nicht irgendwann: ein fester Programmpunkt im Aufnahmeverfahren, mit gesammeltem Notartermin und einem Ort im Haus, an dem hinterlegt ist, wer für wen sprechen darf.

---

## 9 Generationenfestigkeit

### 9.1 Die vier Sicherungen gegen die eigene spätere Mehrheit

| #   | Mechanismus                                            | Wirkung                                                                                  | Aufwand                                    |
| --- | ------------------------------------------------------ | ---------------------------------------------------------------------------------------- | ------------------------------------------ |
| 1   | **Externer Vetogeber** (Syndikat)                      | Verkauf braucht Zustimmung eines Gesellschafters ohne wirtschaftliches Eigeninteresse    | Beitrittsverfahren, Solidarbeitrag         |
| 2   | **Boden bei einer Stiftung, Erbbaurecht beim Projekt** | Gebäude ohne Boden zu verkaufen ist wirtschaftlich unattraktiv, der Anreiz verschwindet  | Erbbauzins, Zweckbindung, Heimfallregelung |
| 3   | **Anfallklausel**                                      | bei Auflösung fällt das Vermögen an eine gemeinnützige Stiftung, nicht an die Mitglieder | gering, nur Satzungsarbeit                 |
| 4   | **Eigene Stiftung als Anteilseignerin**                | härteste Bindung                                                                         | teuer, träge, Stiftungsaufsicht            |

**Empfehlung: 1 + 2 + 3 kombiniert.** Der Aufwand ist einmalig, die Wirkung dauerhaft. Mechanismus 3 ist der billigste und wird am häufigsten vergessen. Er nimmt einem Ausverkauf schlicht die finanzielle Pointe.

### 9.2 Altersmix ist eine Zahl, keine Stimmung

Ziehen zwanzig Gleichaltrige gleichzeitig ein, altern sie gleichzeitig. Nach 30 Jahren ist das Haus ein Pflegeheim ohne Pflegepersonal, nach 40 leer. Das ist der am zuverlässigsten eintretende Verlaufstyp bei Gründungsgruppen und der am leichtesten vermeidbare.

Anders als bei der Frage aus 3.6 ist eine offen ausgewiesene Zielbandbreite hier unproblematisch: Das Alter ist ohnehin bekannt, es ist keine besonders geschützte Angabe, und niemand muss sich dafür zu irgendetwas bekennen. Deshalb wird hier eine Zahl genannt und in 3.6 keine.

- **Altersbandbreiten in der Aufnahmeordnung**, offen ausgewiesen und bei jeder Nachbesetzung geprüft, statt starrer Quoten
- **Barrierefreiheit ab Tag eins:** Aufzug, schwellenlos, mindestens ein Bad rollstuhlgerecht. Nachrüsten ist im Bestand oft unmöglich und im Denkmal fast immer
- **Pflege im Haus vorausdenken.** Ihr seid keine Pflegeeinrichtung. Wo die Grenze verläuft, gehört ins Selbstverständnis, bevor der erste Fall eintritt
- **Aktive Nachbesetzung:** Wenn ein Platz frei wird, wird gefragt, welche Altersgruppe fehlt, und nicht nur, wer gerade sympathisch ist

### 9.3 Substanz: der häufigste stille Tod

Generation 2 erbt nicht nur ein Haus, sondern auch dessen Zustand. Ein Sanierungsstau von zwanzig Jahren ist nicht aufholbar und zwingt zu genau der Entscheidung, die verhindert werden sollte.

> **Instandhaltungsrücklage von 1,2 bis 1,5 % des Wiederbeschaffungswerts pro Jahr, satzungsfest und nicht durch einfachen Plenumsbeschluss absenkbar.**

Hier spart jede Gruppe zuerst, weil es unsichtbar ist und weil die Alternative, also eine niedrigere Nutzungsgebühr, jedem sofort nützt. Deshalb muss die Rücklage der Mehrheit entzogen sein, genau wie die Verkaufsfrage.

Und sie muss **angelegt** werden, nicht nur gebildet. Über dreißig Jahre verliert Geld auf dem Konto bei 2 % Inflation rund 45 % seiner Kaufkraft. Eine mustergültig angesparte Rücklage ist am Tag der Sanierung dann noch gut die Hälfte wert (→ 4.6).

### 9.4 Gründungsmythos und Rückzug

Generation 2 hat den Gründungsimpuls nie erlebt. Damit sie das Projekt trotzdem trägt:

- **Onboarding mit Erzählung:** nicht nur Regeln, sondern _warum_ sie so sind. Eine Regel, deren Grund niemand mehr kennt, wird bei der ersten Unbequemlichkeit gekippt
- **Beschlusssammlung mit Begründungen**, nicht nur mit Beschlusstexten
- **Bewusster Rückzug der Gründer:innen** aus Ämtern nach definierter Zeit
- **Das Recht von Generation 2, es anders zu machen**, ausdrücklich in der Charta. Alles außer den vier Sicherungen aus 9.1 und dem Zweck aus 3.6 muss veränderbar sein, sonst erstarrt das Projekt und stirbt an Irrelevanz statt an Verkauf

---

# Teil IV: Praktisches

---

## 10 Ort und Objekt

### 10.1 Das queere Profil verschiebt die Standortlogik

Ohne queeres Profil wäre der Rat: raus aus der Stadt, auf die Bahn-Achsen, Wuppertal ansehen. Mit queerem Profil kippt das. Community-Infrastruktur, Beratungsstellen, Szene und politische Rückendeckung von Stadt und Land sind **Standortfaktoren, die man nicht mitnehmen kann**.

Köln ist dafür einer der besten Orte in Deutschland und bleibt die Präferenz. Bonn ist die realistische Alternative: kleinere, aber vorhandene Szene, eigene Universität, und im rechtsrheinischen Umland ein bereits bestehendes soziales Netz (→ 4.3). **Die Entscheidung zwischen beiden fällt nicht jetzt**, sondern wenn ein konkretes Objekt auf dem Tisch liegt.

Zusätzlich: Bei **Konzeptvergaben** zählt das Konzept, nicht das Höchstgebot. Ein queeres Wohnprojekt mit ausgearbeitetem Sozial- und Schutzkonzept ist dort ein starker Bewerber, und Konzeptvergabe ist realistisch der einzige Weg, in Köln an bezahlbaren Boden zu kommen.

### 10.2 Objekttypen, der unterschätzte Hebel

Statt zu fragen „wo ist es bezahlbar", lohnt die Frage „welcher Gebäudetyp hat unser Raumprogramm schon eingebaut".

| Typ                                   | Passung                                                                                                                                     | Vorsicht                                           |
| ------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------- |
| **Ehemaliges Kloster**                | ✓✓✓ Großküche, Speisesaal, viele Einzelzimmer mit Bad, Gemeinschaftsräume, Gästetrakt, oft Aufzug. Kirchliche Träger stoßen derzeit viel ab | Denkmalschutz, Energetik, Sanierungskosten         |
| **Ehemaliges Alten- oder Pflegeheim** | ✓✓✓ barrierefrei, Aufzug, Großküche, Einzelzimmer mit Bad                                                                                   | wirkt institutionell, Umbau für Wohnlichkeit nötig |
| **Tagungshaus oder Bildungsstätte**   | ✓✓✓ Gästezimmer, Seminarräume, Küche                                                                                                        | oft abgelegen                                      |
| **Ehemaliges Hotel oder Pension**     | ✓✓ Zimmer mit Bad, Küche, Gemeinschaftsflächen                                                                                              | kleine Zimmer, Brandschutzauflagen                 |
| **Bürogebäude**                       | ✓✓ große Umnutzungswelle, zentrale Lagen                                                                                                    | Grundrisse, Nasszellen, Bauantrag Nutzungsänderung |
| **Schule oder Pfarrheim**             | ✓✓ große Räume, gute Lagen                                                                                                                  | wenig Sanitär, Wohnnutzung genehmigungspflichtig   |
| **Kaserne oder Krankenhaus**          | ✓ Größe passt                                                                                                                               | meist zu groß, hohe Kosten                         |
| **Mehrfamilienhaus im Bestand**       | ○                                                                                                                                           | Gemeinschaftsflächen fehlen fast immer             |

Ein aufgegebenes Kloster oder Altenheim bringt Großküche, Speisesaal, zwanzig bis dreißig Zimmer mit eigenem Bad, Aufzug, Gästetrakt und Veranstaltungsraum **bereits mit**, und lässt sich zugleich in getrennte Hausteile gliedern, wie es 7.4, 7.6 und 8.2 verlangen. Das ist näher am Zielprogramm als fast jeder Neubau. Überzählige Zimmer sind kein Problem, sondern Reserve für Gäste, Krisenzimmer und den Trägerkreis.

**Und es ist der einzige realistische Weg zur oberen Hälfte des Korridors.** Wer 30 oder 40 Menschen unter einem Dach will, braucht 1.150 bis 2.190 m² (→ 4.1). In dieser Größe existiert auf dem normalen Kölner Markt fast nichts, in den ersten drei Zeilen dieser Tabelle dagegen regelmäßig. Die Objektfrage entscheidet also die Gruppengröße mit, nicht umgekehrt.

**Zwei laufende Kölner Verfahren zeigen, dass der Weg über die Stadt kein Papierweg ist.** Am **Poller Damm** stellt das Amt für Liegenschaften städtische Grundstücke für ein gemeinschaftliches Wohnbauprojekt bereit, die Vergabe soll nach einem Konzeptverfahren **im Erbbaurecht an ein genossenschaftliches Projekt** gehen, eine Machbarkeitsstudie liegt vor. An der **Alpener Straße 4 bis 6** in Ehrenfeld entsteht auf dem Grundstück der alten Artilleriehalle, ebenfalls im Erbbaurecht, ein inklusives genossenschaftliches Wohnprojekt mit Clusterwohnungen, privaten Einheiten, Gemeinschaftsräumen und Wohngemeinschaften. Beides sind genau die Kombination aus Konzeptvergabe und Erbbaurecht, auf der 4.2 aufbaut, und beide Verfahren laufen über die Stellen in 14.4.

### 10.3 Standortkorridore

1. **Köln innerhalb der Stadtgrenze**, realistisch Mülheim, Kalk, Bilderstöckchen, Bickendorf, Teile von Nippes. Nur über Konzeptvergabe, Erbbaurecht oder Umnutzung.
2. **Umlandring mit Stadtbahn oder S-Bahn**, also Leverkusen, Hürth, Frechen, Pulheim, Brühl, Wesseling, Bergisch Gladbach. Deutlich günstiger, Erreichbarkeit erhalten.
3. **Bonn und rechtsrheinisches Umland**, also Bonn selbst, Königswinter, Bad Honnef, Sankt Augustin. Eigenständiger Anker mit bestehendem sozialem Netz (→ 4.3), keine reine Ausweichoption.
4. **Rheinschiene weiter außen**, also Dormagen, Neuss, Rhein-Sieg. Für Klöster und Tagungshäuser die realistischste Zone.
5. **Wuppertal**, echte Großstadt, sehr günstige Altbausubstanz, lebendige Szene, gute Verbindung. Nur wenn die Gruppe bereit ist, die Anbindung an Köln oder Bonn aufzugeben.

### 10.4 Objektanforderungen aus dem Sozialkonzept

Diese Punkte sind **keine Wünsche, sondern Ableitungen** aus den Abschnitten 7 und 8. Sie gehören ins Suchprofil, weil sie sich nachträglich kaum herstellen lassen:

- mehrere **getrennte Hausteile**, idealerweise mit eigenen Treppenhäusern
- **zwei Wohnzimmer plus ein kleiner Cozy-Rückzugsraum**, in dem nie gespielt wird (→ 7.6). Keine Raumreserve, sondern Bedingung
- **ein gemeinsamer Essraum**, groß genug, dass alle gleichzeitig an einem Tisch sitzen können. Nicht die Küche mit Esstisch, sondern ein eigener Raum. Das gemeinsame Essen ist der einzige Termin, der ohne Einladung funktioniert, und er braucht dafür einen Ort, der nicht gerade anders benutzt wird
- **mindestens ein Workshop- oder Seminarraum** für Formate, Gruppen, AKs und externe Angebote. Ein teilbarer Veranstaltungsraum erfüllt das mit, ein eigener Raum ist deutlich besser, kostet aber zusätzliche Fläche (→ 4.1)
- **Veranstaltungsraum mit separatem Zugang**, möglichst eigenem Eingang
- **ausgewiesene Räume für Play**, schallgedämmt, mit Sanitär in der Nähe und mindestens einer statisch tragfähigen Deckenkonstruktion (→ 7.6)
- **abschließbarer Lagerraum** für Gear und Ausstattung
- **kein Einblick von außen** in Gemeinschafts-, Veranstaltungs- und Play-Bereiche
- **Gästezimmer abseits des Familienbereichs**
- **ein bis zwei Rotationszimmer** plus ein **Krisenzimmer**, dauerhaft freigehalten
- **Barrierefreiheit:** Aufzug, schwellenlos, rollstuhlgerechtes Bad
- **Gemeinschaftsküche in Gewerbequalität.** Bei zwanzig Bewohner:innen plus Einzugsgebiet, Trägerkreis, Gästen und Veranstaltungen reicht keine Wohnküche
- **Zutritts- und Sicherheitskonzept** (→ 11, A.2): einsehbarer, beleuchteter Eingangsbereich, digital verwaltbare Schließanlage mit mechanischem Rückfallweg, keine uneinsehbaren Zugänge

---

## 11 Risikoregister

| #   | Risiko                                                         | Wirkung                                                                                               | Vorkehrung                                                                                                                                                                                 |
| --- | -------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| 1   | **Schlecht verlaufene Trennung polarisiert das Haus**          | Lagerbildung, Austritte, Projektende                                                                  | Verfahren vor dem ersten Fall (7.4), Beziehungsthemen nicht ins Plenum (7.5), poly- und kink-kompetente Mediation mit Budget                                                               |
| 2   | **Sexualisierte Gewalt oder Machtmissbrauch**                  | zerstört Projekte zuverlässiger als alles andere                                                      | Awareness-Konzept, externe Ombudsstelle, Definitionsmachtfrage vorab geklärt (7.9)                                                                                                         |
| 3   | **Kindeswohlgefährdung**                                       | irreversibel, existenziell                                                                            | Schutzkonzept mit Fachberatung, erweiterte Führungszeugnisse, kindereigener Beschwerdeweg (8.3)                                                                                            |
| 4   | **Rechte Anfeindungen und Angriffe**                           | reale Bedrohung für sichtbar queere Einrichtungen in Deutschland                                      | Sicherheitskonzept, Entscheidung über öffentliche Adresse (7.7), Kontakt zur Polizei-Ansprechstelle LSBTIQ, Vorfalldokumentation                                                           |
| 5   | **Beziehung wird faktisch zum Zugangsweg**                     | Verfahren ausgehebelt, Generation 2 unmöglich                                                         | 7.1 strikt, Befangenheitsregeln (7.8)                                                                                                                                                      |
| 6   | **Kink-Sichtbarkeit und Konsens Dritter kollidieren**          | dauerhafte Aushandlung, stille Rückzüge, am Ende Heimlichkeit                                         | Raumordnung statt Einzelfall (7.6), in die Gemeinschaftsordnung                                                                                                                            |
| 7   | **Machtdynamik wirkt in Gremien hinein**                       | Beschlüsse ohne freie Stimme, nach außen unsichtbar                                                   | Befangenheit auch für D/s (7.8), unabbedingbarer Awareness-Zugang                                                                                                                          |
| 8   | **Unfreiwillige Outings** durch Gäste, Fotos, Öffentlichkeit   | berufliche und familiäre Folgen für Einzelne, irreversibel                                            | Foto- und Medienregel, informierte Einladung, bewusste Sichtbarkeitsentscheidung (7.7)                                                                                                     |
| 9   | **Gründer:innen-Dominanz**                                     | Gruppe bleibt abhängig, Generation 2 trägt nicht                                                      | Amtszeitbegrenzung, externe Moderation, Wissensverteilung (6.4)                                                                                                                            |
| 10  | **Zwischenschritt frisst das Zielprojekt**                     | in fünf Jahren große WG statt Kommune                                                                 | hartes Enddatum, Track B mit eigenen Terminen (5.2)                                                                                                                                        |
| 11  | **Trägerkreis verliert das Interesse**                         | die Struktur, die das kleine Haupthaus trägt, bricht weg                                              | Nutzung statt Finanzierung als Grundlage (2.1), feste Übernachtungsrechte, Ämter nach außen (2.2)                                                                                          |
| 12  | **Kapitalungleichheit erzeugt informelle Macht**               | Satzung sagt eine Stimme, Realität nicht                                                              | Bänder, Solidarfonds, strikte Entkopplung, offen benennen (4.5)                                                                                                                            |
| 13  | **Direktkredite kommen nicht zusammen**                        | Finanzierung scheitert spät und teuer                                                                 | frühe realistische Erhebung, Kreis über den Freundeskreis hinaus erweitern                                                                                                                 |
| 14  | **Zins- und Baukostenänderung**                                | Finanzierungslücke                                                                                    | Puffer 20 bis 25 %, lange Zinsbindung, Förderung prüfen                                                                                                                                    |
| 15  | **Austrittswelle**                                             | Liquiditätscrash                                                                                      | gestaffelte Auszahlung, Kündigungsfristen, Auszahlung erst bei Nachbesetzung                                                                                                               |
| 16  | **Erbfall**                                                    | Anteile an projektfremde Erben                                                                        | Nennwertregelung, Anfallklausel, Satzungsregelung                                                                                                                                          |
| 17  | **Sanierungsstau**                                             | stiller Tod in Generation 2                                                                           | Rücklage satzungsfest (9.3)                                                                                                                                                                |
| 18  | **Demografische Monokultur**                                   | Haus altert und stirbt gemeinsam                                                                      | Altersbandbreiten, Barrierefreiheit (9.2)                                                                                                                                                  |
| 19  | **Ehrenamtsfalle und Burnout der Aktiven**                     | wenige tragen alles, dann niemand                                                                     | Pflichtstunden oder bezahlte Hausmeisterei, Ämterrotation                                                                                                                                  |
| 20  | **Gemeinnützigkeit aberkannt**                                 | Nachversteuerung, Spendenhaftung                                                                      | zwei getrennte Vereine, saubere Sphärentrennung, Fachkanzlei (3.5)                                                                                                                         |
| 21  | **Gästezimmer werden Dauerwohnraum oder Beherbergungsgewerbe** | Melderecht, Steuer, Brandschutz                                                                       | Nutzungsordnung mit Höchstdauer, klare Abgrenzung                                                                                                                                          |
| 22  | **Prospektpflicht bei Direktkrediten**                         | persönliche Haftung                                                                                   | Muster des Syndikats nutzen, anwaltlich prüfen (3.3)                                                                                                                                       |
| 23  | **Zutrittsdaten werden zum Überwachungswerkzeug**              | Bewegungsprofile im eigenen Zuhause, Beweismittel im Konflikt                                         | Datenschutz- und Zutrittsordnung, kurze Löschfristen, kein anlassloser Zugriff (A.2)                                                                                                       |
| 24  | **Zu enger Interessent:innenkreis**                            | Projekt findet nicht genug Menschen                                                                   | Kreis früh und breit erweitern, Schwundquote pessimistisch ansetzen (5.1)                                                                                                                  |
| 25  | **Kapitalstock wird angegriffen oder verwässert**              | Substanzstock steht bei der Sanierung nicht bereit                                                    | Zweckbindung, qualifizierte Mehrheit plus Sperrfrist, Zielwert mit dem Baupreisindex fortgeschrieben (4.6)                                                                                 |
| 26  | **Anlagerisiko und Zinsrisiko treffen gleichzeitig**           | Depot ist am kleinsten, wenn die Anschlussfinanzierung teuer wird                                     | Aktienquote an die Restschuld gekoppelt, kurzfristiger Topf ohne Aktien, Tilgung vor Depot (4.6)                                                                                           |
| 27  | **Erweiterte Kürzung geht verloren**                           | Gewerbesteuer fällt dann auch auf die Mieten an, nicht nur auf das Depot                              | passive Anlagerichtlinie, kein aktiver Handel, jährliche steuerliche Kontrolle (4.6)                                                                                                       |
| 28  | **Szene-Monokultur der Gründungsgruppe**                       | das Haus reproduziert dauerhaft eine einzige Community; Generation 2 findet niemanden mehr, der passt | Einzugsgebiet und Trägerkreis bewusst breiter einladen, Pflichtfrage „was fehlt dem Haus gerade" bei jeder Aufnahme, nach der Gründung nicht in derselben Szene nachrekrutieren (5.3, 3.6) |

---

## 12 Offene Fragen, priorisiert

### 12.1 Zuerst, weil es die Machbarkeit selbst betrifft

1. **Wer würde tatsächlich in den Raum Köln oder Bonn ziehen?** Die wichtigste Zahl im ganzen Projekt und die am schnellsten zu erhebende. Solange sie unbekannt ist, ist alles andere Spekulation.
2. **Wie viel Kapital steckt realistisch im Kreis?** Anonyme Abfrage in Bandbreiten, nie in Einzelbeträgen. Das Ergebnis entscheidet zwischen Kauf, Erbbaurecht und Miete.
3. **Zeithorizont.** Realistisch sind von hier bis Einzug **fünf bis acht Jahre**. Wer mit zwei rechnet, verliert die Gruppe, wenn Jahr drei kommt. Trägt der Kreis das?
4. **Zeitbudget der treibenden Person.** Ein Projekt dieser Art bedeutet über Jahre eine Größenordnung von zehn bis zwanzig Wochenstunden. Neben einem Vollzeitjob ist das eine echte Entscheidung, keine Nebensache.
5. **Wohnen Kinder dauerhaft im Haupthaus?** Nicht „Kinder ja oder nein", sondern _wo_. Ändert Objektprofil, Standortlogik, Schutzkonzept und die Reichweite der Kink-Kultur grundlegend und muss **vor der Objektsuche** fallen. Drei ausgearbeitete Varianten in **8.0**.

### 12.2 Grundsatzfragen, die die Gruppe entscheiden muss

6. **Definitionsmacht versus Verfahrensgarantien** bei Übergriffen (→ 7.9). Die schwierigste Frage im Dokument. Muss vor der ersten Krise entschieden werden.
7. **Wie sichtbar wollt ihr sein?** (→ 7.7) Adresse öffentlich? Namen? Presse? Diese Entscheidung ist schwer rückgängig zu machen.
8. **Wie genau läuft das Einverständnis im Nicht-Play-Wohnzimmer?** (→ 7.6) Das Raummodell steht: Play-Wohnzimmer, Nicht-Play-Wohnzimmer, unverhandelbarer Cozy-Raum. Offen ist die Ausgestaltung. Wird gefragt, oder angekündigt? Gilt Schweigen als Zustimmung, und wenn nein, wie fragt man, ohne Druck zu erzeugen? Und wie viele zeitliche Ausnahmen verträgt das Haus, bevor aus der Ausnahme eine Regel wird?
9. **Was trägt der Trägerkreis bei?** (→ 2.1, 6.2) Wenn Nutzung und nicht Finanzierung die Grundlage ist, liegt ein **Mitgliedsbeitrag** nahe, wie in jedem Verein, an den Stimm- und Nutzungsrecht gekoppelt sind und der ab der Stufe Kerngruppe fällig wird (→ 5.4). Offen bleiben Höhe, Staffelung nach Einkommen (→ 4.5) und vor allem eine Ermäßigung bis auf null, die niemand begründen muss. Ohne sie hängt das Stimmrecht am Geld, und genau das schließt 1.3 aus, denn die Trägerkammer beginnt genau bei dieser Stufe (→ 6.2). Der zweite denkbare Ausweg ist eine Kerngruppe, die sich **allein über verbindliche Mitarbeit** definiert und den Beitrag davon trennt. Bis eines von beidem beschlossen ist, hängt die Stimme in der Trägerkammer mittelbar an Zahlungsfähigkeit, und der Widerspruch gehört so lange offen benannt. Die Antwort darf nicht lauten „regelt sich schon".
10. **Konsum.** Alkohol und Substanzen in Gemeinschaftsräumen, bei Veranstaltungen, in Anwesenheit von Kindern. Und die Grenze der Gruppe bei Sucht. Ihr seid keine Einrichtung.
11. **Wie offen sind die Gemeinschaftsräume für Gäste?** Zwischen „Schutzraum, in dem alle Anwesenden bekannt sind" und „lebendigem offenen Haus" liegt eine echte Zielspannung.
12. **Gemeinschaftsküche, Einzelküchen, oder beides?** Bewusst offen, weil es einer der größten Kosten- und Kulturhebel überhaupt ist. Nur eine Gemeinschaftsküche ist am günstigsten und sozial am dichtesten, aber der härteste Zwang für Menschen mit abweichenden Rhythmen, eigenem Essverhalten oder schlicht dem Bedürfnis, allein zu essen. Gemeinschaftsküche plus Teeküche je Einheit kostet wenig zusätzlich und erlaubt Rückzug. Vollwertige Einzelküchen kosten spürbar Fläche und Geld (→ 4.1) und riskieren, dass der Mittelpunkt verwaist. Davon unabhängig: Kochdienst, Einkauf, Ernährungsformen, Unverträglichkeiten, der häufigste Alltagskonflikt in Häusern dieser Größe.
13. **Pflichtstunden oder bezahlte Arbeit?** Wer Ehrenamt voraussetzt, produziert zuverlässig Ausbeutung der Gewissenhaften.
14. **Wie viel Privatfläche?** Der größte Kostenhebel überhaupt, und der Punkt, an dem Ideal und Budget aufeinandertreffen.
15. **Aromantische, asexuelle und monogam lebende Mitbewohner:innen** sowie Menschen, die selbst nicht spielen: Wie wird sichergestellt, dass sie vollwertig dazugehören und kein Erwartungsdruck entsteht (→ 7.2)?
16. **Was genau steht in der Charta?** (→ 3.6) Sie ist der eigentliche Aufnahmefilter. Welche Haltungen werden ausdrücklich verlangt, welche ausdrücklich ausgeschlossen, und wer schreibt sie?
17. **Ausgestaltung des Einzugsgebiets.** Wie nah ist „angebunden"? Gehören die Wohnungen der Haus-GmbH, werden sie angemietet, oder bleiben sie Privatsache? Wie wird verhindert, dass daraus eine zweite Klasse wird (→ 2.2)? **Seit 6.2 hängt daran zusätzlich eine Stimme beim Handeln**, also bei Objektkauf und Kreditaufnahme. Die Aufnahme ins Einzugsgebiet beschließt zwar das Gesamtplenum, sie ist also nicht durch einen Umzug zu erwerben. Aber der Radius ist damit keine Wohnfrage mehr, sondern eine Stimmrechtsfrage.
18. **Soll Hausarbeit überhaupt erfasst werden?** (→ A.1) Kulturentscheidung, keine Werkzeugfrage. Dieselbe Software wird als Entlastung oder als Kontrolle erlebt.
19. **Wie hoch genau ist die Instandhaltungsrücklage?** (→ 4.6) Die angesetzten 1,2 bis 1,5 % des Wiederbeschaffungswerts entsprechen dem, was im Wohnungseigentum die Gemeinschaft trägt. Ohne Sondereigentum trägt das Haus aber auch den Rest. Entweder der Satz steigt Richtung 1,9 %, oder es wird ausdrücklich festgelegt, welchen Teil die Bewohner:innen selbst übernehmen. **Und auf welchen Wiederbeschaffungswert sich der Prozentsatz bezieht, gehört mitentschieden:** Dieselben 1,3 % ergeben bei 3 Mio. € rund 39.000 € im Jahr und bei 5,3 Mio. € rund 69.000 €.

20. **Quorum je Kammer.** (→ 6.2) Ab wie vielen Anwesenden ist eine Kammer beschlussfähig, und was passiert, wenn die Hauskammer es dauerhaft nicht erreicht? Zu niedrig heißt Zufallsmehrheiten, zu hoch heißt Blockade durch Fernbleiben.
21. **Wer entscheidet über die Zuständigkeit selbst?** (→ 6.2) Ob ein Thema Wohnalltag oder Projektfrage ist, und ob eine Projektfrage unter **Handeln** oder unter **Bewahren** fällt, bestimmt, wer abstimmt, und ist damit die eigentliche Macht im Modell. Kandidaten: die Moderation, ein rotierendes Präsidium, oder das Gesamtplenum mit Widerspruchsrecht der betroffenen Kammer.
22. **Ab wann wechselt jemand die Kammer?** (→ 6.2, 7.4) Beim Umzug ins Einzugsgebiet sofort, mit Frist, oder erst auf eigenen Wunsch? Und gibt es eine Übergangszeit mit Stimmrecht in beiden Kammern?

23. **Sollen Direktkreditgeber:innen beim Handeln mitstimmen?** (→ 6.2, 4.5) Seit das Handeln bei Haus- und Nachbarschaftskammer liegt, entscheidet die Trägerkammer über Objekt und Kredit nicht mit. Ein Teil von ihr wird dem Projekt aber fünfstellige Beträge leihen. Bewusst ausgelassen, weil jede Kopplung von Geld und Stimme gegen 1.3 läuft und Bewohner:innen ohne Einlage sonst schlechter stünden als Außenstehende mit. Denkbar wäre ein **Anhörungsrecht mit Begründungspflicht** statt einer Stimme. **Gehört auf die Tagesordnung des ersten Gesprächs mit dem Syndikat.**

### 12.3 Fragen für externe Expertise

24. **Fachanwält:in Gemeinnützigkeitsrecht:** Zwei-Vereins-Modell tragfähig? Und wie verhält sich der **Trägerverein** aus 2.3 zum **Community-Verein** aus 3.5: geht er in ihm auf, besteht er daneben fort, oder wird er zu ihm? Das Dokument beantwortet das nicht, und das Ressort der Trägerkammer nach 6.2 setzt eine Antwort voraus (→ 2.3, 3.5, 6.2)
25. **Fachanwält:in Miet- und Vereinsrecht:** Kopplung von Mitgliedschaft und Nutzungsvertrag, Zulässigkeit einer Auswahl nach Charta-Zustimmung, Ausschlussklausel in der Satzung, welche Teile der Gemeinschaftsordnung wirksam Vertragsbestandteil werden können, und **wie ein Beschluss des Gesamtplenums den Hausverein bindet**, dem die Anteile an der Haus-GmbH gehören. Konkret zu prüfen sind die **zwei Zustimmungsvorbehalte** aus 6.2 (Nachbarschaftskammer beim Handeln, alle drei Kammern beim Bewahren), der Änderungsschutz für die Zuständigkeitsliste und die Kopplung der Vereinsgründung an die notarielle Beurkundung und des Umschaltpunkts an den Erstbezug (→ 3.6, 3.7, 6.2, 7.4)
26. **Fachanwält:in Familienrecht:** Absicherung sozialer Elternschaft in Poly-Konstellationen, Stand der Verantwortungsgemeinschaft (→ 8.6, 8.7)
27. **Fachanwält:in Kapitalmarkt- und Bankrecht:** Prospektpflicht bei Direktkrediten (→ 4.5)
28. **Steuerkanzlei mit Schwerpunkt Immobilien und Gemeinnützigkeit:** Hält die erweiterte Kürzung nach § 9 Nr. 1 Satz 2 GewStG bei einem gleichzeitig gehaltenen Wertpapierdepot? Wo liegt die Grenze zwischen Vermögensverwaltung und gewerblichem Wertpapierhandel? Ab wann ist die Senkung der Nutzungsgebühr aus Kapitalerträgen eine verdeckte Gewinnausschüttung? Greift § 7 Abs. 8 ErbStG bei Zuwendungen Dritter, obwohl Gesellschafter der GmbH keine natürlichen Personen sind (→ 4.6)? Und ist ein Mitgliedsbeitrag, an den Nutzungsrechte geknüpft sind, ein echter Mitgliedsbeitrag oder ein umsatzsteuerbares Entgelt für eine Leistung, mit den entsprechenden Folgen für den Zweckbetrieb (→ 3.5, Frage 9)?
29. **Fachberatungsstelle:** Erarbeitung des Schutzkonzepts (→ 8.3)
30. **Wohnprojekte-Beratung:** Finanzierungsmodell und Objektstrategie
31. **Mietshäuser Syndikat:** Passung, Verfahren, realistischer Zeitrahmen. Und: Ist ein **Zustimmungsvorbehalt** der Trägerkammer beim Bewahren mit dem Selbstverwaltungsprinzip vereinbar, und wie bewertet das Syndikat den Umschaltpunkt beim Erstbezug (→ 6.2)? Zum **Solidarbeitrag** sind die vertraglichen Sätze inzwischen bekannt (→ 3.3, 4.7); offen bleiben zwei Punkte: Wie hält es das Syndikat mit der **Aussetzung der Steigerung** bei Projekten, die über 80 % der ortsüblichen Miete liegen, und welche Erwartung besteht **über den vertraglichen Satz hinaus**, sobald ein Haus entschuldet ist?
32. **Stiftung trias:** Erbbaurecht im Raum Köln oder Bonn überhaupt verfügbar?
33. **Statiker:in:** Anforderungen an tragfähige Deckenkonstruktionen, sobald ein Objekt konkret ist (→ 7.6)

### 12.4 Bewusst zurückgestellt

Diese Fragen sind wichtig, aber erst später entscheidbar. Sie jetzt zu diskutieren kostet Energie ohne Ertrag:

Innenausbau und Ausstattung, Energiekonzept, Haustiere, konkrete Zimmerverteilung, Gestaltung des Außenbereichs, Name und Logo, und das **Bildungs- und Workshop-Programm des Community-Vereins** (→ 3.5).

---

## 13 Nächste Schritte: die ersten 90 Tage

Alles hier ist ohne Kapital, ohne Rechtsform und ohne Verpflichtung machbar.

| Schritt                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               | Warum jetzt                                                                                                                                                                                                                                                                                                                                                          |
| --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **1. Dieses Dokument teilen** und um ehrliche Reaktionen bitten, besonders zu Abschnitt 7 und 8                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       | Wer bei diesen Abschnitten abspringt, wäre später abgesprungen. Früh ist billiger                                                                                                                                                                                                                                                                                    |
| **2. Die Umzugsfrage stellen:** wer würde wirklich in den Raum Köln oder Bonn ziehen                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  | siehe 12.1                                                                                                                                                                                                                                                                                                                                                           |
| **3. Kapital-Bandbreiten anonym abfragen**                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            | entscheidet über die gesamte Strategie                                                                                                                                                                                                                                                                                                                               |
| **4. Bestehende Projekte besuchen:** [Villa Anders](https://www.villa-anders-koeln.de/) in Köln (Träger: Schwul-Lesbisches Wohnen e. V.), [Amaryllis](https://www.amaryllis-bonn.de/) in Bonn, [Wohnsinn](https://www.wohnsinn-aachen.org/ueber-uns/unsere-haeuser/) in Aachen, [Petershof](https://petershof.org/) in Köln, und ein Syndikatsprojekt: [DreiLessiDrei](https://www.syndikat.org/dreilessidrei/), [BG1006](https://www.syndikat.org/bg1006/) oder [Die Neuerburg](https://www.syndikat.org/die-neuerburg/) in Köln, [Krausfeld](https://www.syndikat.org/hausprojekt-krausfeld) oder [SieMensch](https://www.syndikat.org/siemensch/) in Bonn (→ 14.4) | Eine Stunde mit Menschen, die es hinter sich haben, schlägt zwanzig Stunden Recherche. **SieMensch** ist mit 20 Personen genau eure Größenordnung und noch in der Gründung, also mitten in denselben Fragen. **Wohnsinn** zeigt die andere Seite: 35 Menschen, Gästezimmer, Gemeinschaftsräume, Hof, und eine Direktkreditpraxis, die seit über zwanzig Jahren läuft |
| **5. Ein Syndikatstreffen besuchen**                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  | ohne Verpflichtung, klärt die Passung sofort                                                                                                                                                                                                                                                                                                                         |
| **6. Erstberatung holen:** die [MitStadtZentrale](https://mitstadtzentrale.de/) bietet **kostenlose Orientierungsberatung** zu Gruppenaufbau und Rechtsform, das [Büro für gemeinschaftliche Wohnbauprojekte](https://www.stadt-koeln.de/artikel/73785/index.html) der Stadt Köln begleitet Konzeptverfahren, die [Amaryllis eG](https://www.amaryllis-bonn.de/) berät Gruppen (→ 14.4)                                                                                                                                                                                                                                                                               | Kostenlos, unverbindlich, und die städtische Stelle ist zugleich der Zugang zu Konzeptvergaben und Erbbaurecht (→ 10.2)                                                                                                                                                                                                                                              |
| **7. Den Wohnprojektetag NRW am 19. September 2026** im Wissenschaftspark Gelsenkirchen besuchen, Motto _Vielfalt in gemeinschaftlichen Wohnprojekten_                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                | Der einzige feste Termin in dieser Liste, und er ist in gut drei Wochen. Ein Tag, an dem die halbe NRW-Szene an einem Ort steht                                                                                                                                                                                                                                      |
| **8. Auftaktwochenende planen**, extern moderiert                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     | nicht vom Initiator moderiert (→ 6.4)                                                                                                                                                                                                                                                                                                                                |
| **9. Einen ersten Charta-Entwurf schreiben** und im Kreis diskutieren                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 | Sie ist der eigentliche Aufnahmefilter (→ 3.6). Je früher sie existiert, desto weniger muss später einzeln ausgehandelt werden                                                                                                                                                                                                                                       |
| **10. Jo Freeman lesen und gemeinsam besprechen**                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     | verhindert die häufigste Governance-Falle, bevor sie entsteht                                                                                                                                                                                                                                                                                                        |
| **11. Objektsuche testweise starten:** Kloster- und Heimimmobilien im Rheinland                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       | zeigt binnen Wochen, ob der Objekttyp verfügbar ist                                                                                                                                                                                                                                                                                                                  |
| **12. Entscheiden, ob der Zwischenschritt kommt**, und wenn ja, mit Enddatum                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          | siehe 5.2                                                                                                                                                                                                                                                                                                                                                            |

---

## 14 Quellen und Anlaufstellen

### 14.0 Prüfstatus, bitte lesen

Diese Liste entstand aus einem Firmennetz heraus. Der erste Anlauf scheiterte am Proxy, der zweite lief über einen Weg, der die Windows-Anmeldung mitschickt, und hat funktioniert. Am 25.08.2026 wurde jede Adresse hier einzeln aufgerufen. Deshalb:

| Kennzeichnung  | Bedeutung                                                                                                                                             |
| -------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------- |
| **[geprüft]**  | Seite abgerufen **und** der Inhalt bestätigt, was hier über sie steht                                                                                 |
| [Adresse ok]   | Die Domain antwortet, die konkrete Abteilung oder das konkrete Angebot ist damit aber **nicht** bestätigt. Gilt vor allem für die großen Stadtportale |
| [ungeprüft]    | Nicht erreicht. Vor Kontaktaufnahme selbst prüfen                                                                                                     |
| [Seite defekt] | Der Server antwortet, die Seite ist aber technisch nicht nutzbar. Inhalte ungeprüft, Kontakt anders suchen                                            |

Wo eine Adresse nicht mehr stimmt, hilft 14.8: Dort stehen die Suchbegriffe, mit denen sich jede dieser Stellen wiederfinden lässt.

### 14.1 Trägermodelle und Rechtsformen

| Stelle                                         | Adresse                                                                                                     | Wofür konkret                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| ---------------------------------------------- | ----------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Mietshäuser Syndikat** **[geprüft]**         | [syndikat.org](https://www.syndikat.org/) · [Solidartransfer](https://www.syndikat.org/de/solidartransfer/) | Das empfohlene Modell (→ 3.2). Dort: Modellbeschreibung, Projektkarte, Termine der Syndikatstreffen, Regionalkontakte, Muster für Direktkreditverträge. Die Seite **Solidartransfer** nennt die Beitragssätze im Klartext und ist die Quelle der Zahlen in 3.3 und 4.7: 10 Cent je m² und Monat an die Syndikat GmbH, dazu 0 bis 80 Cent stille Beteiligung an der Solidarfonds GmbH, jährlich steigend um 0,5 % der Jahresnettokaltmiete. Zur Einordnung: 2022 kamen von 170 Projekten 450.000 €, 2023 rund 500.000 € zusammen |
| **gesetze-im-internet.de** **[geprüft]**       | [gesetze-im-internet.de](https://www.gesetze-im-internet.de/)                                               | Amtliche Volltexte. Die Normen in 4.6 sind dort im Wortlaut nachgelesen: § 9 Nr. 1 Satz 2 GewStG, § 20 Abs. 1 und Abs. 5 InvStG, §§ 52, 55, 62 AO sowie § 7 Abs. 8 und § 13 Abs. 1 Nr. 16 ErbStG                                                                                                                                                                                                                                                                                                                                |
| **Stiftung trias**, Hattingen **[geprüft]**    | [stiftung-trias.de](https://www.stiftung-trias.de/)                                                         | Erbbaurecht und Bodenfrage (→ 9.1). Rechtsfähige Stiftung bürgerlichen Rechts, Droste-Hülshoff-Str. 43, 45525 Hattingen (Ruhr), Tel. 02324 56970-0. Über 54 Projekte. Hat einen eigenen Bereich _Schenken, Stiften, Vererben_, der direkt zu 4.6 passt                                                                                                                                                                                                                                                                          |
| **Stiftung Edith Maryon**, Basel **[geprüft]** | [maryon.ch](https://www.maryon.ch/)                                                                         | Zweite Bodenstiftung, auch in Deutschland aktiv                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| **Wohnprojekte-Portal** **[geprüft]**          | [wohnprojekte-portal.de](https://www.wohnprojekte-portal.de/)                                               | Bundesweite Projektdatenbank, nach Ort filterbar. Wird von der Stiftung trias betrieben, ist also dieselbe Adresse eine Zeile höher. Der schnellste Weg zu Referenzprojekten im Rheinland                                                                                                                                                                                                                                                                                                                                       |

### 14.2 Beratung und Netzwerke

| Stelle                                                  | Adresse                                                         | Wofür konkret                                                                                                                                                                                                                                                                                                                                                                           |
| ------------------------------------------------------- | --------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **FORUM Gemeinschaftliches Wohnen e. V.** **[geprüft]** | [verein.fgw-ev.de](https://verein.fgw-ev.de/)                   | Bundesvereinigung mit Regionalstellen; Erstberatung, oft kostenlos oder gefördert. **Achtung, die naheliegende Adresse forum-gemeinschaftliches-wohnen.de existiert nicht mehr**, sie löst nicht einmal im DNS auf. Dort angekündigt: **23. Wohnprojektetag NRW am 19. September 2026** im Wissenschaftspark Gelsenkirchen, Motto _Vielfalt in gemeinschaftlichen Wohnprojekten_ (→ 13) |
| **wohnbund e. V.** **[geprüft]**                        | [wohnbund.de](https://www.wohnbund.de/)                         | Fachverband gemeinschaftliches Wohnen; Beratungsarm für Machbarkeit und Finanzierung                                                                                                                                                                                                                                                                                                    |
| **Netzwerk Immovielien** **[geprüft]**                  | [netzwerk-immovielien.de](https://www.netzwerk-immovielien.de/) | Umnutzung von Bestandsgebäuden, Konzeptvergaben, Kommunenkontakte. Relevant für die Kloster- und Heimschiene (→ 10.2)                                                                                                                                                                                                                                                                   |
| **Foundation for Intentional Community** **[geprüft]**  | [ic.org](https://www.ic.org/)                                   | International; viel Material zu Aufnahmeverfahren und dazu, woran Gemeinschaften scheitern. Heißt inzwischen _Foundation_, nicht mehr _Fellowship_                                                                                                                                                                                                                                      |

### 14.3 Finanzierung und Förderung

| Stelle                                             | Adresse                                       | Wofür konkret                                                                        |
| -------------------------------------------------- | --------------------------------------------- | ------------------------------------------------------------------------------------ |
| **GLS Bank** **[geprüft]**                         | [gls.de](https://www.gls.de/)                 | Finanziert Wohn- und Syndikatsprojekte routiniert, kennt das Modell                  |
| **UmweltBank** **[geprüft]**                       | [umweltbank.de](https://www.umweltbank.de/)   | Zweite einschlägige Adresse                                                          |
| **NRW.BANK** **[geprüft]**                         | [nrwbank.de](https://www.nrwbank.de/)         | Landeswohnraumförderung, öffentliche Baudarlehen mit Tilgungsnachlässen (→ 4.2)      |
| **Bundesstiftung Magnus Hirschfeld** **[geprüft]** | [mh-stiftung.de](https://www.mh-stiftung.de/) | Förderung queerer Projekte. Relevant für den gemeinnützigen Community-Verein (→ 3.5) |

### 14.4 Anlaufstellen in Köln, Bonn und Umgebung

> Der Teil, der am schnellsten konkret wird. **Vier bis fünf Gespräche hier ersetzen Monate an Recherche**, und sie kosten nichts außer Zeit.

| Stelle                                                                   | Adresse                                                                                                                                                                                                                                                                                                                                                                                                                                                                     | Warum genau die                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| ------------------------------------------------------------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Villa Anders**, Köln **[geprüft]**                                     | [villa-anders-koeln.de](https://www.villa-anders-koeln.de/)                                                                                                                                                                                                                                                                                                                                                                                                                 | Queeres Wohnprojekt direkt in Köln, getragen von **Schwul-Lesbisches Wohnen e. V.** – das ist die Stelle, bei der man anfragt. **Das wichtigste Referenzgespräch überhaupt.** Menschen, die diesen Weg gegangen sind, in derselben Stadt, mit denselben Behörden und demselben Bodenmarkt                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| **rubicon e. V.**, Köln **[geprüft]**                                    | [rubicon-koeln.de](https://www.rubicon-koeln.de/)                                                                                                                                                                                                                                                                                                                                                                                                                           | LSBTIQ-Beratungszentrum. Erste Adresse für Vernetzung, für die Erweiterung des Kreises über den Freundeskreis hinaus und für den Anschluss an die queere Infrastruktur der Stadt                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| **Zartbitter e. V.**, Köln **[geprüft]**                                 | [zartbitter.de](https://zartbitter.de/) · [Schutzkonzepte](https://zartbitter.de/category/themen/schutzkonzepte/) · [Beratung](https://zartbitter.de/beratung/) · [Termine](https://zartbitter.de/termine/)                                                                                                                                                                                                                                                                 | Kölner Fachberatungsstelle gegen sexualisierte Gewalt an Kindern, bundesweit für ihre Materialien bekannt. **Die fachliche Begleitung für Abschnitt 8**, vor Ort, mit eigenem Schwerpunkt auf Schutzkonzepten in Institutionen. Die Website ist im Umbau, die Unterseite zu den Fortbildungen lud am 26.08.2026 nicht, unter Termine steht _Keine Veranstaltungen_                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| **Fuchichos**, Köln [ungeprüft]                                          | über den persönlichen Kreis                                                                                                                                                                                                                                                                                                                                                                                                                                                 | Aus dem eigenen Umfeld eingebracht: Menschen mit Poly- und Awareness-Kompetenz in Köln. Relevant für den Pool poly- und kink-kompetenter Moderation (→ 7.5) und für den Aufbau der Awareness-Struktur (→ 7.9). Eine Websuche am 26. August 2026 hat **keinen öffentlichen Auftritt** gefunden, auch keinen Social-Media-Kanal; der Kontakt läuft ausschließlich über den persönlichen Kreis. **Rolle, Verfügbarkeit und Form der Zusammenarbeit sind noch zu klären**                                                                                                                                                                                                                                                                                                                                                            |
| **Stadt Köln, Büro für gemeinschaftliche Wohnbauprojekte** **[geprüft]** | [stadt-koeln.de/artikel/73785](https://www.stadt-koeln.de/artikel/73785/index.html)                                                                                                                                                                                                                                                                                                                                                                                         | **Der wichtigste Fund dieser Liste nach der Villa Anders.** Sitzt in der Stabstelle Wohnungsbauleitstelle im Dezernat für Planen und Bauen, arbeitet seit Anfang 2022, zwei Mitarbeiterinnen. Eigene Beschreibung: _Fürsprecherinnen für Baugemeinschaften_, Lotsenfunktion in der Verwaltung, aktiviert kommunale und private Flächen, begleitet Vergabeverfahren. Das ist genau die Stelle, die 10.1 braucht                                                                                                                                                                                                                                                                                                                                                                                                                   |
| **MitStadtZentrale**, Köln **[geprüft]**                                 | [mitstadtzentrale.de](https://mitstadtzentrale.de/)                                                                                                                                                                                                                                                                                                                                                                                                                         | Die zweite Säule desselben Angebots, extern und städtisch gefördert. Bietet **kostenlose Orientierungsberatung** über ein Formular auf der Seite, ausdrücklich zu Gruppenaufbau und Rechtsformwahl, und vermittelt Kontakte zu Wohnungsgenossenschaften und Anbietern von Mietmodellen. Der niedrigschwelligste Einstieg, den es in Köln gibt                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| **Stadt Köln, Vermarktung unbebauter Grundstücke** **[geprüft]**         | [stadt-koeln.de/artikel/00777](https://www.stadt-koeln.de/artikel/00777/index.html)                                                                                                                                                                                                                                                                                                                                                                                         | Der Einstieg beim Amt für Liegenschaften. Konzeptvergaben, Erbbaurechte, Kooperatives Baulandmodell. Realistisch der einzige Weg zu bezahlbarem Boden innerhalb der Stadtgrenze (→ 10.1)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| **WohnPortal Köln-Bonn** **[geprüft]**                                   | [wohnportal-koeln-bonn.de](https://wohnportal-koeln-bonn.de/)                                                                                                                                                                                                                                                                                                                                                                                                               | Regionales Portal für genau euren Korridor, von der Stadt Köln verlinkt. Deckt beide Standorte aus 4.3 in einer Datenbank ab                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| **Stadt Köln, Amt für Wohnungswesen** [Adresse ok]                       | [stadt-koeln.de](https://www.stadt-koeln.de/)                                                                                                                                                                                                                                                                                                                                                                                                                               | Wohnraumförderung (→ 4.2). Für Baugruppen läuft die Beratung praktisch über die beiden Stellen oben, nicht hier                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| **LSBTIQ-Koordination der Stadt Köln** [Adresse ok]                      | über [stadt-koeln.de](https://www.stadt-koeln.de/)                                                                                                                                                                                                                                                                                                                                                                                                                          | Politische Rückendeckung, Hinweise auf Fördertöpfe und auf laufende Vergabeverfahren, bevor sie öffentlich sind                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| **Stadt Bonn, Liegenschaften und Wohnungswesen** [Adresse ok]            | [bonn.de](https://www.bonn.de/)                                                                                                                                                                                                                                                                                                                                                                                                                                             | Dieselben Fragen für den zweiten Standortkorridor (→ 4.3, 10.3). **Hier bleibt es bei der Startseite:** bonn.de schließt KI-Agenten in seiner robots.txt ausdrücklich aus, deshalb wurde die Seite nicht weiter durchsucht. Diese Recherche muss ein Mensch machen                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| **Amaryllis eG**, Bonn **[geprüft]**                                     | [amaryllis-bonn.de](https://www.amaryllis-bonn.de/) · info@amaryllis-bonn.de                                                                                                                                                                                                                                                                                                                                                                                                | Genossenschaftlich organisiertes Mehrgenerationenprojekt, rund 70 Menschen zwischen null und neunzig, bewohnt seit 2007. Das beste Kontrastbeispiel zum Syndikatsmodell, eine halbe Bahnstunde entfernt. **Und mehr als ein Besuch:** Sie bieten regelmäßige Infocafés für Einzelpersonen und ausdrücklich **individuelle Beratung von Gruppen** zu Rechtsformen für gemeinschaftliches Wohnen, Finanzierung und dem Aufbau einer Gemeinschaft                                                                                                                                                                                                                                                                                                                                                                                   |
| **WohnWerk Cologne e. V.** **[geprüft]**                                 | [wohnwerk-cologne.de](https://wohnwerk-cologne.de/)                                                                                                                                                                                                                                                                                                                                                                                                                         | Kölner Baugruppen-Verein, von der Stadt als Praxisbeispiel verlinkt                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| **Machbarschaft Petershof**, Köln **[geprüft]**                          | [petershof.org](https://petershof.org/)                                                                                                                                                                                                                                                                                                                                                                                                                                     | Soziokulturelles Zentrum **und** gemeinschaftliches Wohnen in einem Objekt. Das nächstliegende Kölner Beispiel für die Kombination aus Wohnen und offenem Veranstaltungsbetrieb, die 3.5 und 10.4 beschreiben                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| **lila_bunt**, Zülpich **[geprüft]**                                     | [syndikat.org/lila_bunt](https://www.syndikat.org/lila_bunt/) · eigene Seite: [lilabunt.de](https://lilabunt.de)                                                                                                                                                                                                                                                                                                                                                            | Beim Durchgehen der Syndikatsliste aufgefallen und deshalb hier neu:_Feministische Bildung, Praxis & Utopie_, ein Tagungs- und Bildungshaus im Syndikat, 1652 m², seit 2018, gut 40 km von Köln. Das nächstgelegene Beispiel dafür, wie sich Veranstaltungs- und Workshopbetrieb mit dem Syndikatsmodell verträgt (→ 10.4, 3.5)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| **Polizei NRW, Ansprechpersonen für LSBTIQ** [Adresse ok]                | über [polizei.nrw](https://polizei.nrw/)                                                                                                                                                                                                                                                                                                                                                                                                                                    | Für das Sicherheitskonzept (→ Register-Nr. 4). Kontakt vor dem ersten Vorfall aufzubauen ist deutlich wirksamer als danach                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| **Queeres Netzwerk NRW** [Seite defekt]                                  | [queeres-netzwerk-nrw.de](https://www.queeres-netzwerk-nrw.de/)                                                                                                                                                                                                                                                                                                                                                                                                             | Landesvernetzung, Fördermittelwissen, Kontakt zu anderen queeren Projekten in NRW. **Die Seite ist über HTTPS für niemanden aufrufbar.** Der Server antwortet, liefert aber ein Zertifikat, das auf `queer-flucht-nrw.de` ausgestellt und **seit dem 14. Juni 2020 abgelaufen** ist. Jeder Browser zeigt darauf eine Sicherheitswarnung; das ist **kein Firmennetz-Effekt**, wie hier zunächst vermutet, sondern ein seit Jahren defektes Setup. Inhalte deshalb ungeprüft, Kontakt telefonisch oder per Mail über eine andere Quelle suchen. Das inhaltlich verwandte [schwules-netzwerk.de](https://schwules-netzwerk.de/) antwortet dagegen normal                                                                                                                                                                            |
| **Syndikatsprojekte im Rheinland** **[geprüft]**                         | [DreiLessiDrei](https://www.syndikat.org/dreilessidrei/) · [BG1006](https://www.syndikat.org/bg1006/) ([tausendsechs.de](http://www.tausendsechs.de)) · [Die Neuerburg](https://www.syndikat.org/die-neuerburg/) · [Krausfeld](https://www.syndikat.org/hausprojekt-krausfeld) · [SieMensch](https://www.syndikat.org/siemensch/) · [Oberstraße Aachen](https://www.syndikat.org/oberstrasse-aachen/) · alle über die [Projektliste](https://www.syndikat.org/de/projekte/) | **Köln** DreiLessiDrei (seit 2007), BG1006, Die Neuerburg. **Bonn** Krausfeld (2016) und SieMensch (2020, 506 m², 20 Personen, noch Initiative). **Aachen** Oberstraße, früher Gentristop (2019, 410 m², 11). **In Düsseldorf steht keins**, entgegen früherer Annahme. Ein Besuch klärt die Milieufrage aus 3.4 an einem Abend                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| **Wohnprojekt Wohnsinn**, Aachen **[geprüft]**                           | [wohnsinn-aachen.org](https://www.wohnsinn-aachen.org/) · [Unsere Häuser](https://www.wohnsinn-aachen.org/ueber-uns/unsere-haeuser/) · [Direktkredite](https://www.wohnsinn-aachen.org/dk/) · [syndikat.org](https://www.syndikat.org/wohnprojekt-wohnsinn/)                                                                                                                                                                                                                | **Das inhaltlich nächstliegende Vorbild in dieser Liste.** Seit 2002, 1400 m², rund 35 Menschen, also die obere Hälfte des Korridors aus 2.1. Zwei denkmalgeschützte Altbauten mit je 6 Wohneinheiten, **2 Gästezimmern**, 4 Anbauzimmern sowie Gemeinschafts- und Büroräumen, dazu ein Hinterhof-Neubau mit 12 barrierefreien Passivhauswohnungen, den die Landesregierung NRW als _experimentellen Wohnungsbau_ eingestuft hat. Toreinfahrt, Hof, Garten. Gemeinschaftsraum und Gästezimmer tragen Plenum, Feste und Besuch, exakt das Raumprogramm aus 4.1. Die **Direktkreditseite ist ein fertiges Muster zum Abschauen**: bis zu 3 % Zins, qualifizierter Rangrücktritt, einsehbare Jahresbilanz, Vertrag als PDF, FAQ und Formular (→ 4.5). Kombiniert außerdem sozial geförderten und frei finanzierten Wohnraum (→ 4.2) |
| **Kölner Wohnungsgenossenschaften** [Adresse ok]                         | über die [MitStadtZentrale](https://mitstadtzentrale.de/)                                                                                                                                                                                                                                                                                                                                                                                                                   | Mögliche Kooperationspartner bei Konzeptvergaben. Eine etablierte Genossenschaft im Boot erhöht die Chancen erheblich und bringt Bonität mit. Die MitStadtZentrale sagt von sich, genau diese Kontakte zu vermitteln, das ist der kürzere Weg als die Stadtverwaltung                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |

### 14.5 Queere Wohnprojekte als Referenz, bundesweit

| Projekt                                      | Adresse                                                         | Besonderheit                                                                                                                                                                     |
| -------------------------------------------- | --------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Lebensort Vielfalt**, Berlin **[geprüft]** | [schwulenberatungberlin.de](https://schwulenberatungberlin.de/) | Größtes queeres Wohnprojekt Deutschlands, mehrere Standorte, professionell aufgestellt. Viel übertragbares Wissen zum Zusammenspiel von Wohnen und gemeinnütziger Arbeit (→ 3.5) |
| **RuT, Rad und Tat**, Berlin **[geprüft]**   | [rut-berlin.de](https://www.rut-berlin.de/)                     | Vollständig:_Offene Initiative Lesbischer Frauen e. V._ Lesbisches Wohnprojekt; der lange und zähe Entstehungsweg ist gut dokumentiert und realistisch                           |
| **LSVD⁺** **[geprüft]**                      | [lsvd.de](https://www.lsvd.de/)                                 | Heißt inzwischen _LSVD⁺ – Verband Queere Vielfalt_. Rechtliche Fragen zu Diskriminierung, Regenbogenfamilien und sozialer Elternschaft (→ 8.6)                                   |

### 14.6 Kinderschutz

| Stelle                                     | Adresse                                                                                         | Wofür                                                                                                                                                                                                                                                                                 |
| ------------------------------------------ | ----------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Zartbitter e. V.**, Köln **[geprüft]**   | [zartbitter.de](https://zartbitter.de/)                                                         | siehe 14.4. Die Fachstelle vor Ort, mit der das Schutzkonzept erarbeitet werden sollte                                                                                                                                                                                                |
| **UBSKM** **[geprüft]**                    | [beauftragte-missbrauch.de](https://beauftragte-missbrauch.de/) · [ubskm.de](https://ubskm.de/) | Unabhängige Beauftragte für Fragen des sexuellen Kindesmissbrauchs; Standards und Materialien für Schutzkonzepte. **ubskm.de** leitet per 301 auf **beauftragte-missbrauch.de** um, geprüft am 26.08.2026. Die kurze Adresse funktioniert weiter als Einstieg, die lange ist das Ziel |
| **Kein Raum für Missbrauch** **[geprüft]** | [kein-raum-fuer-missbrauch.de](https://www.kein-raum-fuer-missbrauch.de/)                       | Praxisorientierte Handreichungen zur Erstellung von Schutzkonzepten in Institutionen                                                                                                                                                                                                  |

### 14.7 Lektüre

| Titel                                                        | Zugang                                                                           | Warum                                                                                                                                              |
| ------------------------------------------------------------ | -------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------- |
| Jo Freeman,_The Tyranny of Structurelessness_ **[geprüft]**  | [jofreeman.com/joreen/tyranny.htm](https://www.jofreeman.com/joreen/tyranny.htm) | Kurz, frei verfügbar, **Pflichtlektüre für die Gründungsgruppe**. Erklärt, warum Strukturlosigkeit Macht nicht abschafft, sondern unsichtbar macht |
| _Sociocracy 3.0_ **[geprüft]**                               | [sociocracy30.org](https://sociocracy30.org/)                                    | Frei verfügbares Praxishandbuch zu Konsent und Kreisstruktur (→ 6.1)                                                                               |
| Diana Leafe Christian,_Creating a Life Together_             | Buchhandel                                                                       | Standardwerk zur Gemeinschaftsgründung, besonders stark bei Aufnahmeverfahren und Scheiternsanalysen                                               |
| Jessica Fern,_Polysecure_                                    | Buchhandel                                                                       | Bindung und Sicherheit in polyamoren Konstellationen (→ 7)                                                                                         |
| Dossie Easton / Janet Hardy,_The Ethical Slut_               | Buchhandel                                                                       | Grundlagentext, brauchbar als gemeinsame Gesprächsbasis im Kreis                                                                                   |
| Lee Harrington / Mollena Williams,_Playing Well with Others_ | Buchhandel                                                                       | Kink im sozialen Raum: Community, Etikette, Konsens zwischen mehr als zwei Menschen. Die passende Grundlage für 7.6                                |

### 14.8 Wenn ein Link tot ist: Suchbegriffe

| Thema        | Suchbegriffe                                                                                                                                     |
| ------------ | ------------------------------------------------------------------------------------------------------------------------------------------------ |
| Trägermodell | `Mietshäuser Syndikat Beitritt` · `Hausprojekt Direktkredit Nachrangdarlehen`                                                                    |
| Boden        | `Stiftung Erbbaurecht Wohnprojekt` · `Bodenstiftung gemeinschaftliches Wohnen`                                                                   |
| Beratung     | `Wohnprojekt Beratung NRW` · `Baugruppe Beratung Köln` · `Baugruppe Beratung Bonn`                                                               |
| Vergabe      | `Konzeptvergabe Köln` · `Kooperatives Baulandmodell Köln` · `Erbbaurecht Stadt Köln`                                                             |
| Queer        | `queeres Wohnprojekt Köln` · `LSBTIQ Wohnen NRW Förderung`                                                                                       |
| Awareness    | `Awareness Konzept Veranstaltung Vorlage` · `poly kompetente Paarberatung NRW` · `kink aware professionals Deutschland`                          |
| Kinderschutz | `Schutzkonzept sexualisierte Gewalt Institution Muster` · `Fachberatungsstelle Köln`                                                             |
| Recht        | `Fachanwalt Gemeinnützigkeitsrecht Köln` · `Fachanwalt Vereinsrecht Wohnprojekt` · `soziale Elternschaft Sorgerechtsvollmacht Regenbogenfamilie` |

---

## Anhang A: Ideen und Werkzeuge

Sammelstelle für Dinge, die noch keine Entscheidung sind, aber nicht verloren gehen sollen.

### A.1 choreOPS: unsichtbare Arbeit sichtbar machen

**Was es ist.** Eine bereits im Eigenbetrieb laufende Home-Assistant-Integration zur Erfassung und Verteilung wiederkehrender Hausarbeit. Vorhanden und erprobt, also kein Neubau, sondern eine Mitgift.

**Warum es hier hingehört.** Lernziel 2 aus Track A (→ 5.2), also die Frage „wer macht die unsichtbare Arbeit, und wie wird sie sichtbar", ist in Gemeinschaften dieser Größe eine der häufigsten Bruchstellen überhaupt. Zwei bis vier Menschen tragen ein Vielfaches, merken es lange nicht, und wenn sie es merken, ist daraus schon Groll geworden. Ein Werkzeug, das Aufwand protokolliert, ersetzt das Gespräch nicht, aber es liefert **Zahlen statt Gefühlen**, und darüber lässt sich streiten, ohne sich gegenseitig den Charakter vorzuwerfen.

**Der Zwischenschritt ist der ideale Testlauf.** 6 bis 12 Personen, zwei bis drei Jahre, ausdrücklich als Experiment deklariert. Was dort trägt, geht ins große Haus; was nervt, fliegt raus, bevor das ganze Haus damit leben muss.

**Vier Fallstricke, die vorher benannt gehören:**

| Fallstrick                                | Warum er zählt                                                                                                                                                                        | Gegenmittel                                                                                                                       |
| ----------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------- |
| **Punkte werden zur Währung**             | Sobald ein Zähler öffentlich ist, taucht er im Konflikt als Argument auf: „ich habe mehr Punkte als du". Aus einem Hilfsmittel wird eine Rangliste                                    | Aggregiert auswerten, keine Dauerbestenliste. Die Zahlen gehören dem AK Haus, nicht dem Plenumsstreit                             |
| **Nur das Messbare zählt**                | Spülmaschine ausräumen wird gezählt, „merken, dass es jemandem schlecht geht" nicht. Wenn nur eines sichtbar wird, wandert Status dorthin, und Sorgearbeit wird **noch** unsichtbarer | Emotionale und organisatorische Arbeit ausdrücklich als Ämter mitführen, gerade weil sie nicht zählbar ist                        |
| **Datenschutz im eigenen Zuhause**        | Anwesenheit, Routinen und Verhalten von zwanzig Menschen plus Einzugsgebiet in einem System. Zweckbindung, Zugriff und Löschfristen sind hier keine Formalie                          | Schriftliche Regel: was erfasst wird, wer es sieht, wann es gelöscht wird. Opt-out muss möglich bleiben                           |
| **Die Infrastruktur gehört einer Person** | Wer das System gebaut hat und wartet, hat informelle Macht und hat eine Abhängigkeit erzeugt (→ 6.4)                                                                                  | Von Anfang an eine zweite Person einarbeiten, Doku im Haus, Betrieb beim AK Haus. Fällt die eine Person aus, muss es weiterlaufen |

**Offene Frage:** _Ob_ Hausarbeit überhaupt erfasst werden soll, ist eine **Kulturentscheidung**, keine Werkzeugfrage. Manche Gruppen erleben so ein System als Entlastung, andere als Kontrolle. Das entscheidet die Gruppe und nicht die Person mit dem Server (→ 12.2).

### A.2 Digitaler Zutritt statt Schlüsselbund

**Warum das mehr als Bequemlichkeit ist.** Die Drei-Kreise-Struktur aus 2.1 steht und fällt damit, dass Einzugsgebiet und Trägerkreis **eigenen Zugang** haben. Wer klingeln muss, ist Gast, egal was in der Satzung steht. Mit mechanischen Schlüsseln ist das nicht lösbar: Bei sechzig oder mehr zugangsberechtigten Menschen mit wechselndem Status wird jede Schließanlage entweder unsicher oder unbenutzbar.

**Was es kann, was ein Schlüssel nicht kann:**

- **Abgestufte Berechtigungen.** Haupthaus, Gemeinschaftsbereiche, Werkstatt, Gästezimmer, Play-Räume und Familienbereich können unterschiedliche Kreise haben. Das ist die technische Entsprechung der Zonenordnung aus 7.6 und 8.2.
- **Zeitfenster.** Gästezimmer nur für den gebuchten Zeitraum, Veranstaltungszugang nur am Veranstaltungsabend.
- **Sofortiges Ändern.** Kein Schließzylindertausch, wenn jemand geht.
- **Vertretbarer Aufwand** bei einem Kreis, der ständig wächst.

**Technisch** liegt eine Lösung nahe, die im Privatbetrieb bereits läuft: **Nuki-Schlösser über Matter, orchestriert in Home Assistant**, mit lokaler Steuerung statt Cloud-Abhängigkeit. Das ist erprobt, offen genug für eigene Automatisierung und nicht an einen Hersteller gebunden.

**Und jetzt die Punkte, die vor der ersten Installation geklärt sein müssen:**

| Fallstrick                              | Warum er zählt                                                                                                                                                                  | Gegenmittel                                                                                                                                                                                                                    |
| --------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| **Zutrittslog ist ein Bewegungsprofil** | Wer wann nach Hause kommt, wer bei wem übernachtet, wer nachts in welchem Raum war. In einem Haus mit überlappenden Beziehungen ist das die sensibelste Datenmenge, die es gibt | **Datenschutz- und Zutrittsordnung** (→ 6.5): möglichst kein personenbezogenes Logging, sonst kurze Löschfristen, kein anlassloser Zugriff, Auswertung nur bei konkretem Sicherheitsvorfall und nur durch mehr als eine Person |
| **Das Log taucht im Konflikt auf**      | „Ich habe gesehen, dass du um 3 Uhr bei ihr warst." Ein technisches System wird dann zum Beweismittel in Beziehungsstreitigkeiten                                               | Ausdrückliche Regel: Zutrittsdaten sind **kein zulässiges Argument** in Beziehungs- und Plenumskonflikten, analog zur Kreditkündigung in 4.5                                                                                   |
| **Zutrittsentzug als Druckmittel**      | Digital ist es sehr einfach, jemanden auszusperren. Das wäre **verbotene Eigenmacht nach § 858 BGB** und rechtswidrig, unabhängig davon, wie der Konflikt steht                 | Wohnzugang ist **nie** ein Sanktionsmittel. Änderungen an Wohnberechtigungen nur nach dem Verfahren aus 7.4 und 7.9, niemals durch die Person mit dem Adminzugang                                                              |
| **Single Point of Failure**             | Stromausfall, Netzausfall, Firmware-Update, kaputter Server. Zwanzig Menschen stehen vor der Tür                                                                                | **Mechanischer Rückfallweg zwingend**, mindestens für Haupteingang und Fluchtwege. Batteriegepufferte Schlösser, Notschlüssel an einem definierten Ort                                                                         |
| **Wer vergibt die Rechte?**             | Berechtigungsverwaltung ist Macht, und sie sieht harmlos aus (→ 6.4)                                                                                                            | Beim AK Haus, mindestens zwei Personen, dokumentiertes Verfahren. Nicht bei der Person, die es gebaut hat                                                                                                                      |
| **Angriffsfläche**                      | Ein sichtbar queeres Haus mit einer netzgebundenen Schließanlage (→ Register-Nr. 4)                                                                                             | Lokale Steuerung ohne Cloud-Zwang, getrenntes Netz, Updates als Amt und nicht als Hobby                                                                                                                                        |

**Und der Brandschutz nicht vergessen:** Flucht- und Rettungswege müssen ohne Technik und ohne Berechtigung von innen zu öffnen sein. Das ist keine Empfehlung, das ist Bauordnungsrecht.

---

## Glossar

| Begriff                    | Bedeutung                                                                                                                    |
| -------------------------- | ---------------------------------------------------------------------------------------------------------------------------- |
| **Anfallklausel**          | Satzungsregel, an wen das Vermögen bei Auflösung fällt                                                                       |
| **Awareness**              | Struktur und Haltung zum Umgang mit Grenzverletzungen und Übergriffen in einer Gruppe                                        |
| **Bewahren**               | Sammelbegriff für Zweck, Verkaufsschutz, Rechtsform und Auflösung. Alle drei Kammern müssen zustimmen (→ 6.2)                |
| **D/s-Dynamik**            | Beziehungsform mit ausgehandeltem Machtgefälle (Dominance/submission), oft dauerhaft und alltagsprägend                      |
| **Definitionsmacht**       | Prinzip, wonach die betroffene Person definiert, ob ein Übergriff stattgefunden hat                                          |
| **Direktkredit**           | Nachrangdarlehen von Privatpersonen, meist zinsgünstig, im Insolvenzfall nachrangig                                          |
| **eG**                     | eingetragene Genossenschaft; ein Mitglied, eine Stimme, unabhängig von der Einlage                                           |
| **Erbbaurecht**            | Recht, auf fremdem Grund zu bauen und zu nutzen, meist 99 Jahre gegen Erbbauzins                                             |
| **Gesamtplenum**           | Sitzung aller drei Kammern, der Regelfall (→ 6.2)                                                                            |
| **Handeln**                | Sammelbegriff für Objektkauf, Kredit, Finanzrahmen und Bauen. Haus- und Nachbarschaftskammer entscheiden (→ 6.2)             |
| **Hauskammer**             | die Bewohner:innen des Haupthauses als Abstimmungsgruppe (→ 6.2)                                                             |
| **Hausplenum**             | Sitzung, in der nur die Hauskammer abstimmt (→ 6.2)                                                                          |
| **Heimfall**               | Rückfall des Erbbaurechts an den Grundstückseigentümer bei Vertragsverstoß                                                   |
| **Kammer**                 | Abstimmungsgruppe im selben Plenum, kein eigenes Gremium (→ 6.2)                                                             |
| **Kink**                   | Sammelbegriff für Sexualitäts- und Beziehungspraktiken jenseits der Norm, hier insbesondere BDSM, Rollen- und Machtdynamiken |
| **Konsent**                | Beschluss gilt, wenn kein schwerwiegender begründeter Einwand vorliegt                                                       |
| **Metamour**               | Partner:in der eigenen Partner:in, ohne eigene Beziehung zueinander                                                          |
| **Nachbarschaftskammer**   | die Mitglieder im Einzugsgebiet als Abstimmungsgruppe (→ 6.2)                                                                |
| **Nebenzweckprivileg**     | Grenze, bis zu der ein e. V. wirtschaftlich tätig sein darf                                                                  |
| **Nutzungsgebühr**         | Miet-Äquivalent in Genossenschaften und Hausprojekten                                                                        |
| **Play**                   | konkrete, zeitlich begrenzte Kink-Interaktion, im Unterschied zur dauerhaften Dynamik                                        |
| **Prospektpflicht**        | Pflicht, bei öffentlichem Angebot von Vermögensanlagen einen geprüften Prospekt zu erstellen                                 |
| **Schutzkonzept**          | strukturiertes Maßnahmenpaket zur Prävention sexualisierter Gewalt                                                           |
| **Trägerkammer**           | der Trägerkreis ab Verbindlichkeitsstufe Kerngruppe als Abstimmungsgruppe (→ 6.2, 12.2 Frage 9)                              |
| **Umschaltpunkt**          | der Erstbezug, ab dem die Kammeraufteilung gilt (→ 6.2)                                                                      |
| **Wiederbeschaffungswert** | Kosten, das Gebäude heute neu zu errichten. Bezugsgröße für die Rücklage                                                     |
| **Zustimmungsvorbehalt**   | Satzungsregel, nach der ein Beschluss erst mit Zustimmung eines anderen Organs wirksam wird (→ 6.2)                          |

---

## Änderungshistorie

| Datum      | Änderung                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| ---------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 2026-08-25 | **Erstfassung.** Grundentscheidungen, Architektur, Syndikat-Empfehlung, Poly, Kinderschutz, Risikoregister. Ergänzt: 4.5 soziale Staffelung und Direktkredite, Standortkorridore, Verantwortungsgemeinschaft, Anhang A, § 1685 BGB in 8.6, **8.0** Varianten A/B/C (**noch nicht entschieden**, Rest von Abschnitt 8 in Fassung A), Korrektur in 8.3 nach Hinweis von Zartbitter                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| 2026-08-25 | **Große Überarbeitung.** Vier Teile, neue Einleitung, Lesewege. **Quote in 3.6 gestrichen**, stattdessen Charta für alle drei Kreise, Aufnahmeverfahren, qualitativer Vorrang. **Kink als eigene Säule.** Trägerkreis auf Nutzungslogik umgestellt. Neu: 3.7 Eskalationsleiter, 7.6 als Raummodell, A.2 digitaler Zutritt, Bonn als zweiter Korridor, Essraum und Workshopraum in den Objektanforderungen, mündliche Absagen im Aufnahmeverfahren. **Zielgröße 20 bis 40, gerechnet mit 20.** Em-Dashes entfernt                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| 2026-08-25 | Neu **4.6 Kapitalstock**: Rücklage wird angelegt statt geparkt, Stock in der Haus-GmbH, drei Stufen Substanz, Ertrag, Weitergabe, Entnahmeregel 3 % real, Risiken 25 bis 27, Prüffrage 23. Am Gesetzestext geprüft: § 20 **Abs. 5** InvStG statt Abs. 1, § 7 Abs. 8 ErbStG relativiert, § 62 Abs. 3 AO und Bagatellgrenze 100.000 € ergänzt                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| 2026-08-25 | **Quellen einzeln aufgerufen**, 27 von 29 bestätigt. Korrekturen und Neuzugänge in 14: fgw-ev.de, LSVD⁺, Foundation for Intentional Community, drei Syndikatsprojekte in Köln und je zwei in Bonn und Aachen, Wohnsinn Aachen mit Direktkreditpraxis, lila_bunt, Amaryllis, Villa Anders, Wohnprojektetag NRW am 19.09.2026. **Kernfund:** Büro für gemeinschaftliche Wohnbauprojekte und MitStadtZentrale der Stadt Köln, zwei laufende Konzeptvergaben im Erbbaurecht. **Bonn nicht vertieft**, weil bonn.de KI-Agenten per robots.txt ausschließt                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| 2026-08-26 | **Kink oben gesetzt** (1.2); 3.6 begründet ihn nicht mehr, sondern regelt den Alltag, Erwartung von Nähe statt von Praxis, Rekrutierung in der Szene (5.3), Risiko 28. **4.6 an § 19 Abs. 2 Nr. 4 WEG, § 28 Abs. 2 II. BV und Petersscher Formel geprüft**, daraus neue offene Frage 19. **Küchenfrage geöffnet** (1.1, 12.2). Dokument gekürzt: Begründungsprosa raus, Entscheidungen, Zahlen und Quellen bleiben                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| 2026-08-26 | **Governance geschärft.** 6.2: Die drei Kreise heißen jetzt **Hauskammer**, **Nachbarschaftskammer** und **Trägerkammer**, dazu **Hausplenum** und **Gesamtplenum**, mit Diagramm und umgestellter Zuständigkeitsliste. Verwiesen in 2.1, 3.3 und 3.6. Neu: **Patt-Regel** (Vermittlung, dann Verfall, mit Fortgeltung dort wo Nichtstun keine Option ist), **Nutzungsgebühr allein beim Hausplenum** mit rechnerischer Mindesthöhe aus dem Finanzrahmen, Instandhaltung und Sanierung bleiben Gesamtplenum. Vier Punkte ausdrücklich offen gehalten: Quorum, Zuständigkeitsstreit, Kammerwechsel und **die Projektfragen selbst**, dazu der Asymmetrie-Vorschlag Bewahren/Handeln. **Ungelöste rechtliche Verankerung** (Hausverein bindet sich nicht von selbst an Gesamtplenumsbeschlüsse) benannt. Mitgliedsbeitrag als Antwortrichtung in Frage 9, Steuerfalle unechter Mitgliedsbeitrag an Frage 27. Doppelte Nummer 19 in 12.2/12.3 behoben, Liste läuft jetzt bis 33                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| 2026-08-26 | Neu **6.6 Der Aufnahmeweg**: sechs Stufen von Kontakt bis Einzug, Aufnahmekreis bereitet vor, **Hausplenum entscheidet im Konsent**. **Probewohnen umgebaut** von 6 bis 12 Monaten Wohnen auf lange Mitmachphase plus kurze Blöcke im Gästezimmer, weil § 575 BGB Zeitmietverträge zum Probewohnen nicht deckt und nur § 549 Abs. 2 Nr. 1 BGB trägt. **Kapital begründet keinen Platzanspruch**: 5.4 Stufe Zeichnend korrigiert auf Zugang zum Verfahren und Rückzahlung bei Nichtaufnahme. Einzugsgebiet hat **Kennenlernvorsprung statt Vorrang** (2.1). 7.4, 6.5 und 3.6 nachgezogen                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| 2026-08-26 | **Asymmetrie beschlossen.** Die Projektfragen sind in **Handeln** und **Bewahren** geteilt. Objektkauf, Kredit, Finanzrahmen, Kapitalstock und Sanierung entscheiden **Haus- und Nachbarschaftskammer**; Zweck, Verkaufsschutz, Rechtsform und Auflösung brauchen die **Zustimmung aller drei Kammern**. Die **Trägerkammer ist Förderkreis** mit eigenem Ressort: Programm, Bildung, Veranstaltungen und Fördermittel im Community-Verein, mit eigenem Haushalt, Veto der Hauskammer nur bei Adresse, Sichtbarkeit und Raumnutzung. Neu der **Umschaltpunkt**: Bis zur Gründung des Hausvereins entscheidet das Gesamtplenum nach Köpfen, weil es vorher keine Hauskammer gibt. Verkaufsschutz zusätzlich über den Vereinszweck abgesichert (§ 33 Abs. 1 Satz 2 BGB, nicht über § 40 BGB abbedingen). Das frühere Verankerungsproblem schrumpft damit auf einen Zustimmungsvorbehalt. Nachgezogen: 2.1, 3.5, 5.4 sowie die Fragen 23, 24 und 31 (heute 25 und 32). **Mitsprache von Direktkreditgeber:innen beim Handeln bewusst ausgelassen** und als Diskussionspunkt vermerkt                                                                                                                                                                                                                                                                                                                                                        |
| 2026-08-26 | **Konsistenzdurchgang.** 4.4 korrigiert: Die Nutzungsgebühr lag mit 700 bis 850 € rechnerisch unter dem reinen Kapitaldienst, jetzt 1.050 bis 1.400 € mit offener Aufschlüsselung, dazu ein Erbbaurechtsszenario und die ehrliche Einordnung, dass das Projekt anfangs teurer ist als der Markt. 6.2 beantwortet vier bis dahin ungeklärte Fragen: **Mehrfachzugehörigkeit** zählt nur in der innersten Kammer, die Mitentscheidung der Nachbarschaftskammer läuft über einen **Zustimmungsvorbehalt** statt über die Mitgliedschaft im Hausverein, der **Umschaltpunkt** hängt an der notariellen Beurkundung statt an einem Beschluss, und die Zuständigkeitsliste bekommt einen **Änderungsschutz** mit qualifizierter Mehrheit plus Kammermehrheit. 5.4 entkoppelt die Stufe Zeichnend vom Aufnahmeverfahren, 8.0 Variante C sagt jetzt, dass sie nicht durchsetzbar ist. Dazu 3.3 nachgezogen, 2.4 um den Umschaltpunkt ergänzt, Quotenwiderspruch zwischen 9.2 und 6.6 aufgelöst, Verweisfehler in 4.6 und Risiko 9 korrigiert, **Aufnahmekreis** als einheitlicher Begriff, Rundungen an 4.1 angeglichen, Wiederbeschaffungswert-Basis in 4.6 offengelegt, elf Glossareinträge.                                                                                                                                                                                                                                                   |
| 2026-08-26 | **Zweiter Konsistenzdurchgang.** **Umschaltpunkt entkoppelt:** Der Hausverein entsteht weiter mit der notariellen Beurkundung, die Kammeraufteilung greift aber erst mit dem **Erstbezug**. Grund: Zwischen Beurkundung und Einzug wären Haus- und Nachbarschaftskammer leer, und genau dann fallen Umbau und Sanierung an. Nachgezogen in 2.4, 5.4, Glossar und den Fragen 26 und 32. **Schutzkonzept** bleibt beim Gesamtplenum, bekommt aber ein Veto der Hauskammer für Regeln, die nur im Haupthaus gelten. **Änderungsschutz der Zuständigkeitsliste entschärft** auf qualifizierte Mehrheit plus Zustimmung der Hauskammer, weil drei Kammern zusammen mit der Verfallsregel die Liste dauerhaft eingefroren hätten. **Entnahme aus dem Kapitalstock** geregelt: Regel ins Gesamtplenum, Verwendung ins Hausplenum. **Flächen vereinheitlicht** auf 850 bis 1.300 m², dadurch Sanierungszyklus 0,85 bis 1,95 Mio. € und Sparrate 25.000 € im Jahr. 3.5 sagt nicht mehr, der Community-Verein sei ein tragender Teil. Neue **Frage 24** zum Widerspruch zwischen Monatsbeitrag der Kerngruppe und Grundentscheidung 1; 12.3 läuft dadurch bis 34. Dazu 9.2 entdoppelt, 2.1 auf Zustimmungsvorbehalt korrigiert, Frage 19 um die Wertbasis erweitert, Glossar alphabetisch sortiert.                                                                                                                                                |
| 2026-08-26 | **Dritter Konsistenzdurchgang.** Die am Vortag eingefügte **Frage 24 wieder gestrichen**: Ihr Inhalt stand bereits vollständig in Frage 9, die dafür um den zweiten Ausweg ergänzt wurde. 12.3 läuft dadurch wieder bis **33**, die Verweise auf die Rechtsfrage sind entsprechend zurückgesetzt. **Frage 21** benutzt jetzt die Begriffe Handeln und Bewahren statt der alten Zweiteilung. **8.0 Variante C** sagt nicht mehr, die Generationenerneuerung sei null, weil der Kasten darunter genau das einschränkt. Der Ausgangswert des Kapitalbedarfs in **2.1** auf 4 bis 7,5 Mio. € korrigiert. Dazu eine **Korrekturrunde an den Zahlen**: 4.4 sagt jetzt, dass die Aufschlüsselung das untere Korridorende rechnet und am oberen Ende knapp 2.000 € stehen; der Entschuldungseffekt ist mit der Kapitalstock-Regel aus 4.6 verbunden und nennt die Belastung danach; der Solidarfonds hat eine eindeutige Bezugsgröße; 4.2 erklärt, warum die Direktkreditsumme aus 3.3 über dem Eigenkapitalbedarf aus 4.1 liegt. **6.5** trägt die Änderungsschutzregeln aus 4.6, 6.2 und 9.3 nach, und die Zuständigkeitsliste in **6.2** bekommt dafür eine eigene Zeile für die Aufnahmeordnung. **8.1 und 8.2** stellen die Sphärentrennung auf Räume um, weil 7.6 und 8.0 den Kalenderweg verwerfen. Der Vorbehalt unter der 8.0-Tabelle gilt jetzt ausdrücklich auch für Variante B.                                                      |
| 2026-08-26 | **Vierter Konsistenzdurchgang, Schwerpunkt Zahlen.** **5.1 korrigiert:** Bei einer Einzugsquote von 20 bis 30 % braucht es für 20 Plätze 70 bis 100 Interessierte, nicht 40 bis 70, und für die ganze Drei-Kreise-Struktur einen niedrig dreistelligen Kreis. **3.3 benennt die Lücke** zwischen 1,5 bis 2,5 Mio. € Direktkrediten und den 10.000 bis 22.000 € je Kopf aus 4.2 und ordnet den Aachener Zinssatz ein. **4.1** sagt jetzt, worauf sich die 35 Schultern beziehen und warum der Korridor erst bei 3 Mio. € beginnt. **4.5** gleicht den Direktkreditzins an 3.3 an. **4.6** nennt die Herstellungskosten-Basis der Petersschen Zahl, weist den Bodenanteil im Wiederbeschaffungswert aus und stellt den Entschuldungseffekt unter denselben Korridorvorbehalt wie 4.4. Rundungen in 1.3 und 2.1 an 4.1 angeglichen. Am Gesetzestext nachgeprüft und bestätigt: § 55 Abs. 1 Nr. 5 AO (100.000 €), § 20 Abs. 1 InvStG (80 %), § 28 Abs. 2 II. BV (7,10 / 9,00 / 11,50 €)                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| 2026-08-26 | **Neu 4.7 Alles auf einen Blick.** Bündelt Kapitalstruktur, Kreditrechnung, Pro-Kopf-Beträge, alle sechs Phasen und den Auszug in einem Abschnitt. Legt drei bis dahin stillschweigende Annahmen offen: Im Syndikatsmodell gibt es **kein nennenswertes Eigenkapital**, was 4.1 „Eigenkapitalquote" nannte, ist die über Direktkredite dargestellte **Nachrangquote**, hier mit **50 %** angesetzt; die **6 % sind kein Zinssatz, sondern eine Annuität** aus 4,5 % Bankzins, 1,5 % Direktkreditzins und dreißig Jahren Tilgung, plus 0,85 % Puffer für die Anschlussfinanzierung (Register-Nr. 14); und der **Richtwert je Kapitalgeber:in hängt an der Kreisgröße**, 43.000 € bei 35 Schultern gegenüber 10.000 € bei 150. Damit ist die in derselben Runde benannte Lücke zwischen 3.3 und 4.2 aufgelöst. 4.1, 4.2 und 4.4 entsprechend nachgezogen                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| 2026-08-26 | **Kapitel 4 als Einheit durchgesehen.** Vier Widersprüche behoben, die 4.7 sichtbar gemacht hat: Der **Richtwert** war in 4.5 als Gesamtkapital je Kopf definiert, in 4.7 als Direktkreditsumme je Kapitalgeber:in, ein Unterschied um den Faktor zwei; 4.5 folgt jetzt der zweiten Definition, weil niemand das Bankdarlehen persönlich aufbringt. 4.2 verglich den **6-Prozent-Kapitaldienst mit einem Bankzins**, also eine Annuität mit einem Zinssatz, und kam deshalb zum falschen Schluss, der Mischsatz liege unter dem Bankangebot; korrekt sind 5,15 % gegenüber 6,1 % für ein reines Bankdarlehen. 4.1 und 4.7 nannten **zwei verschiedene Beträge je Kapitalgeber:in bei 35 Schultern**, 17.000 bis 47.000 € gegenüber 43.000 €; 4.1 weist die drei betroffenen Zeilen jetzt ausdrücklich als Mindestquote der Bank aus. Der Begriff **Eigenkapital** ist aus 4.2, 4.4 und 4.5 verschwunden, weil es im Syndikatsmodell keins gibt; dieselbe Größe heißt jetzt durchgehend **Gesamtkapital**, der Syndikatstopf **Startkapital künftiger Projekte**. Dazu die Einlagenhöhe von rund 1.000 € auch in 4.5 und die kleineren Töpfe in der Phasentabelle                                                                                                                                                                                                                                                                         |
| 2026-08-26 | **Umbau und Schlussaudit.** Der Standortabschnitt stand zwischen sozialer Staffelung und Kapitalstock und unterbrach die Finanzkette; er steht jetzt als **4.3** direkt hinter „Was diese Zahl drückt", weil beide Abschnitte dieselbe Frage behandeln. Dadurch rotieren drei Nummern: aus 4.3 wird 4.4, aus 4.4 wird 4.5, aus 4.5 wird 4.3; alle **54 Querverweise** im Dokument wurden mitgezogen und einzeln geprüft. Der Kasten in 4.4, der die Korrektur der Nutzungsgebühr vom selben Tag im Fließtext erklärte, ist gestrichen, sein tragender Satz steht jetzt im Absatz darüber. Vier Zahlen nachgerechnet und korrigiert: Die **Kapitalstockphase in 4.7** endete bei 1.225 € statt bei **1.205 €** (450 bis 830 € plus 250 bis 375 €); der **Puffer von 0,85 %** ist jetzt hergeleitet, er trägt bei rund 990.000 € Restschuld nach fünfzehn Jahren einen Zinssprung von 4,5 auf rund 8,5 %; die **Sparrate für den Substanzstock** war mit 25.000 € nur die Mitte, der Korridor lautet 15.000 bis 35.000 € im Jahr; die Fläche in 10.2 folgt mit 2.190 m² jetzt der Tabelle in 4.1. Geprüft und unverändert: Risikoregister 1 bis 28 und offene Fragen 1 bis 33 sind lückenlos und ohne Dubletten                                                                                                                                                                                                                            |
| 2026-08-26 | **Rechercherunde.** Vier offene Punkte nachgeschlagen. **Der Solidarbeitrag ans Syndikat hat jetzt Zahlen**, sie stehen öffentlich auf der Seite Solidartransfer: 10 Cent je m² und Monat an die Syndikat GmbH plus 0 bis 80 Cent stille Beteiligung an der Solidarfonds GmbH, jährlich steigend um 0,5 % der Jahresnettokaltmiete. Für dieses Haus sind das **4 bis 7 € je Person und Monat am Anfang und 38 bis 59 € am Deckel**, erreicht nach acht bis zehn Jahren. Das **korrigiert den Reibungspunkt in 3.3**: Der Beitrag ist ein laufender Posten und kein Zugriff auf die Summe, die in Jahr 30 frei wird, die Konkurrenz zum Kapitalstock ist also deutlich kleiner als bisher beschrieben. Zwei Haken sind neu benannt: Die Syndikatsbegründung, die Steigerung tue nicht weh, weil die Belastung durch Entschuldung sinke, trifft auf eine dreißigjährige Annuität nicht zu, und die Klausel zur **Aussetzung der Steigerung** dürfte hier greifen. **Der Eintrag zum Queeren Netzwerk NRW war falsch:** Das Zertifikat ist auf `queer-flucht-nrw.de` ausgestellt und seit dem 14. Juni 2020 abgelaufen, die Seite ist also für alle unbrauchbar und nicht nur aus einem Firmennetz. Zur **Verantwortungsgemeinschaft** ist kein Fortschritt über die Eckpunkte von 2024 hinaus auffindbar; 8.7 trägt jetzt das Prüfdatum. Zu **Fuchichos** hat die Suche keinen öffentlichen Auftritt ergeben, der Eintrag bleibt ungeprüft |
| 2026-08-26 | **Linkprüfung.** Alle 54 Adressen im Dokument einzeln aufgerufen, 52 antworten mit Status 200. **Zwei inhaltliche Korrekturen in 14:** Die Aussage zur **UBSKM** stand verkehrt herum, ubskm.de leitet per 301 auf beauftragte-missbrauch.de um und nicht umgekehrt; der **Zartbitter**-Link auf die Fortbildungsseite lädt nicht, die Website ist im Umbau, er zeigt jetzt auf Termine. **Zwei Domainwechsel nachgezogen:** wohnwerk.cologne auf wohnwerk-cologne.de und fgw-ev.de auf verein.fgw-ev.de. Vierzehn weitere Weiterleitungen sind rein kosmetisch und wurden gelassen. **Nebenbefund:** An vier Stellen fehlte das Leerzeichen vor einem Link (8.2 Zartbitter sowie drei Einträge in 14.5), ein Schaden des Office Viewers, den die bisherige Prüfung nicht erfasst hat, weil sie nur Sternchen betrachtet. Bekannt und unverändert: queeres-netzwerk-nrw.de bleibt wegen des Zertifikats **[Seite defekt]**                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
